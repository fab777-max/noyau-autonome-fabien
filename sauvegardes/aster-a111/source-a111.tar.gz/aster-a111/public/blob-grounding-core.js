// Connections to existing evidence and private documents. No execution or remote generation.
const groundNorm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const terms=s=>new Set(groundNorm(s).split(/[^a-z0-9]+/).filter(x=>x.length>3&&!['dans','pour','avec','comment','quelle','quelles','faire','veux','cette','cela','plus'].includes(x)));
export function evidenceFromStatus(status,audit=null,at=Date.now()){
 if(!status?.ok||!status.run||!status.brain)return null;
 const r=status.run,b=status.brain,receipt=status.receipts?.reduce((best,r)=>!best||r.tick>best.tick?r:best,null),a=audit?.audit;
 return {readAt:at,runId:r.id,status:r.status,ticks:r.ticks,generationStart:r.generationStart,generation:b.generation,attempts:r.attempts,passes:r.passes,discoveries:r.discoveries,retention:b.retention?{exact:b.retention.exactCases,cases:b.retention.cases}:null,receipt:receipt?{tick:receipt.tick,hash:receipt.receipt_hash,at:receipt.created_at}:null,audit:a&&a.runId===r.id?{runId:a.runId,generation:a.generation,at:a.createdAt,hash:a.proofSha256,chainValid:a.packet?.chain?.valid,receipts:a.packet?.chain?.receipts,programUsefulRate:a.packet?.exactness?.programUsefulRate,structural:a.packet?.discoveries?.structural}:null};
}
export function evidenceAnswer(text,evidence,offline=false){
 const t=groundNorm(text),audit=/audit|preuve|recu|certifi/.test(t)&&!/audit(?:er)? (?:ce|mon|le) (?:code|texte|programme)|```/.test(t),tick=/\bt\d\b|tick|lot.*session|repart.*zero/.test(t);
 if(!audit&&!tick)return null;
 if(!evidence)return 'Je ne dispose pas de preuve serveur lisible pour cette demande. Je ne peux donc pas annoncer de résultat d’audit. La conversation et la mémoire locale restent disponibles.';
 const stamp=(offline?'Copie locale hors ligne':'Données serveur lues')+' le '+new Date(evidence.readAt).toLocaleString('fr-FR')+'. ';
 if(tick)return stamp+'Lot '+evidence.ticks+' de cette session ; génération cumulée G'+evidence.generationStart+' → G'+evidence.generation+'. Le numéro du lot recommence à chaque nouveau cycle ; les acquis du cerveau sont repris. '+evidence.passes+'/'+evidence.attempts+' réussites de session. Source : état du cycle '+evidence.runId+'.';
 const a=evidence.audit;
 if(!a)return stamp+'Aucun audit final trouvé pour le cycle '+evidence.runId+' ('+evidence.status+'). Le dernier lot connu est '+evidence.ticks+'. Je peux lire ses mesures, mais ce n’est pas un audit final exécuté par moi.';
 return stamp+'Audit du cycle '+a.runId+' à G'+a.generation+' : chaîne '+(a.chainValid?'valide':'à vérifier')+', '+a.receipts+' reçus, '+Math.round((a.programUsefulRate||0)*100)+' % de programmes utiles, '+a.structural+' découverte(s) structurelle(s). Empreinte du rapport : '+a.hash+'. Source : /api/blob/audit. Je consulte ce rapport existant ; je ne viens pas de lancer un audit.';
}
export function responseMode(text,requested='auto'){
 // Length or the word "code" alone does not justify three expensive generations.
 return requested==='deep'?'deep':'direct';
}
export function sourcePassages(text,documents=[],history=[]){
 const follow=/^(?:et |mais |donc |pourquoi|comment|peux.tu (?:preciser|developper)|plus de|continue)/.test(groundNorm(text));
 const query=text+(follow?' '+history.filter(m=>m.role==='user').slice(-1).map(m=>m.content).join(' '):''),q=terms(query);if(!q.size)return [];
 const passages=[];
 for(const d of documents){
  const original=String(d.text||'');let offset=0,index=0;
  while(offset<original.length){
   let end=Math.min(offset+800,original.length);
   if(end<original.length){const chunk=original.slice(offset,end),breaks=[chunk.lastIndexOf('\n\n'),chunk.lastIndexOf('. '),chunk.lastIndexOf('\n')],cut=Math.max(...breaks);if(cut>250)end=offset+cut+1;}
   const excerpt=original.slice(offset,end),score=[...terms(excerpt)].filter(w=>q.has(w)).length;
   if(score)passages.push({title:String(d.title||'Document privé').slice(0,90),id:d.id+'#'+(++index),start:offset,end,text:excerpt,source:d.source||'OWNER_DOCUMENT',score:score+([...terms(d.title)].some(w=>q.has(w))?1:0)});
   else index++;
   offset=end;
  }
 }
 return passages.sort((a,b)=>b.score-a.score).slice(0,3).map(({score,...x})=>x);
}
export function usefulPastPassages(raw,text){
 const q=terms(text),forgotten=raw?.forgotten||[];
 return (raw?.threads||[]).flatMap(t=>t.messages||[]).filter(m=>m.role==='assistant'&&m.feedback?.value==='useful'&&!forgotten.some(n=>m.at<=n.at&&groundNorm(m.content).includes(n.key))).map(m=>({title:'Réponse que tu as jugée utile',id:'feedback-'+m.at,text:m.content.slice(0,650),source:'OWNER_APPROVED_REPLY',score:[...terms(m.content)].filter(w=>q.has(w)).length})).filter(x=>x.score>=2).sort((a,b)=>b.score-a.score).slice(0,2).map(({score,...x})=>x);
}
export function localDocument(raw){
 if(!raw||typeof raw.text!=='string'||!raw.text.trim()||raw.text.length>60000)throw Error('DOCUMENT_SIZE');
 return {id:String(raw.id||Date.now()).slice(0,80),title:String(raw.title||'Document privé').slice(0,90),text:raw.text,source:'OWNER_DOCUMENT',at:Date.now()};
}
export function guardExecutionClaims(answer){
 const normalized=groundNorm(answer);
 if(/(?:j[’']ai|nous avons|je viens de)\s+(?:effectue|execute|deploye|modifie|lance|verifie)\b/i.test(normalized)||/(?:votre|ta|la) (?:proposition|modification).{0,25}est deploy/i.test(normalized))throw Error('DIALOGUE_UNPROVEN_ACTION');
 return answer;
}

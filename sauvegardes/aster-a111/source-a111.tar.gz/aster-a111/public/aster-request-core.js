// Explicit conversation navigation, no autonomous execution.
import {commitLocalState,ensureDialogueCapacity} from '/noyau-dialogue-store.js?v=A111';
export const COMPOSER_DRAFT_KEY='noyau.composer.draft.v1';
export const GUIDE_ACTIONS=Object.freeze({
 workshop:{label:'Préparer mon pack',text:'Tu peux préparer deux visuels, trois textes et une fiche à partir de tes photos et de tes faits. Retrouve ta demande dans l’atelier, puis ajoute les informations nécessaires.'},
 documents:{label:'Ouvrir mes documents',text:'La recherche locale retrouve des passages dans tes documents TXT et Markdown. Ouvre tes documents pour choisir les mots à chercher ; elle ne consulte pas Internet.'},
 project:{label:'Préparer les étapes',text:'Tu peux avancer étape par étape et conserver les résultats relus. Ton objectif sera repris dans le formulaire, avec trois étapes de départ à adapter avant de l’enregistrer.'},
 agent:{label:'Préparer le relais à l’agent',text:'Cette demande peut être poursuivie avec l’agent connecté dans ChatGPT. Le bouton prépare ton texte ; tu le relis avant de l’enregistrer. Le travail démarre ensuite dans ChatGPT.'}
});
const normalize=text=>text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’]/g,"'");
export function suggestAction(text){
 const t=normalize(text);
 if(/\b(comment|pourquoi|explique|difference|qu'est.ce|est.ce)\b/.test(t)||/[«»"`]/.test(t)||/\b(ne|pas|sans|jamais)\b/.test(t))return null;
 if(!/\b(cree|creer|prepare|preparer|fais|faire|aide|cherche|chercher|recherche|rechercher|repare|reparer|corrige|corriger|ameliore|ameliorer|avance|avancer|reprendre|reprends|organise|organiser|veux|veut|voudrais|besoin|genere|generer)\b/.test(t))return null;
 if(/\b(internet|web|actualites|actualite|video|videos|bug|bugs|code|coder|site|agent|chatgpt)\b/.test(t))return 'agent';
 if(/\b(documents|document|notes|fichiers? txt|markdown)\b/.test(t)&&/\b(cherche|chercher|recherche|rechercher|retrouve|retrouver|trouve|trouver)\b/.test(t))return 'documents';
 if(/\b(pack|visuel|visuels|publication|publications|story|fiche)\b/.test(t)&&/\b(photos?|realisation|chantier|client|artisan|pack)\b/.test(t))return 'workshop';
 if(/\b(?:genere|generer|cree|creer)\b.{0,30}\b(?:image|images|photo|photos)\b/.test(t))return 'agent';
 if(/\b(projet|etapes|plusieurs jours|long terme)\b/.test(t))return 'project';
 return null;
}
export function composerDraft(raw){
 if(raw==null)return {schema:1,text:''};
 if(raw.schema!==1||typeof raw.text!=='string'||raw.text.length>1000)throw Error('Brouillon de demande incompatible.');
 return {schema:1,text:raw.text};
}
export function createComposerDraftStore(storage){
 let expected,opened=false;
 return {
  read(){expected=storage.getItem(COMPOSER_DRAFT_KEY);const result=composerDraft(expected?JSON.parse(expected):null);opened=true;return result.text;},
  save(text){
   if(!opened)throw Error('Brouillon non ouvert.');
   const next=JSON.stringify(composerDraft({schema:1,text}));
   if(storage.getItem(COMPOSER_DRAFT_KEY)!==expected)throw Error('Un autre onglet a modifié le brouillon. Ton texte reste affiché ; copie-le avant de recharger.');
   storage.setItem(COMPOSER_DRAFT_KEY,next);
   if(storage.getItem(COMPOSER_DRAFT_KEY)!==next)throw Error('Brouillon non confirmé.');
   expected=next;
  }
 };
}
export function stageAgentDraft(storage,text){
 composerDraft({schema:1,text});
 if(storage.getItem('noyau-request-pending-v1'))throw Error('Un envoi précédent attend confirmation dans « Avec l’agent ». Termine sa vérification avant ce relais. Ta nouvelle demande reste ici.');
 const key='noyau-request-draft-v1',previous=storage.getItem(key);
 if(previous&&previous!==text)throw Error('Un autre brouillon attend dans « Avec l’agent ». Il reste intact. Ta nouvelle demande est conservée dans cette conversation.');
 storage.setItem(key,text);
 if(storage.getItem(key)!==text)throw Error('Le relais n’a pas pu être conservé. Ta demande reste dans la conversation.');
}
export async function appendGuidance(db,text,kind,id,at=new Date().toISOString()){
 composerDraft({schema:1,text});if(!text.trim()||!Object.hasOwn(GUIDE_ACTIONS,kind))throw Error('Orientation invalide.');
 const result=await commitLocalState(db,null,current=>({dialogue:ensureDialogueCapacity(current.dialogue,[{role:'user',content:text},{role:'assistant',content:GUIDE_ACTIONS[kind].text,guide:kind,requestId:id,savedAt:at}])}));
 return result.dialogue;
}
export function findGuidedRequest(rows,id,kind){
 if(!id||!Array.isArray(rows))return null;
 const i=rows.findIndex(m=>m?.role==='assistant'&&m.requestId===id&&m.guide===kind);
 const text=i>0&&rows[i-1]?.role==='user'?rows[i-1].content:null;
 return typeof text==='string'&&text.length<=1000?text:null;
}

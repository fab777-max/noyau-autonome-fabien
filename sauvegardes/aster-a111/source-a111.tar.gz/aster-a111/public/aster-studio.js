import {WORKSHOP_KEY,FIELDS,MAX_DOSSIERS,MAX_PHOTOS,workshopState,validateDeliverable,printableHTML,safeFilename,zipFiles,escapeHTML} from '/noyau-workshop-core.js?v=A105';
import {saveDossier} from '/noyau-workshop-store.js?v=A97';
import {importPhoto,poster,canvasBlob,photoCanvas,photoDeliveryDossier} from '/noyau-workshop-render.js?v=A105';
import {FIELD_NAMES,newStudioDossier,studioDossier,nextStep,questionFor,submitMessage,editCommand,beginEdit,record,addPhotos,invalidateApproval,exportPrivateProject,importPrivateProject} from '/aster-studio-core.js?v=A105';
import {MODEL} from '/blob-assistant-model.js?v=A83';
import {WRITING_STEPS,WRITING_LIMITS,matchingWriting,newWritingRun,writingRequest,dossierMemory} from '/aster-writing-core.js?v=A106';
import {runLocalWriting} from '/aster-writing-runner.js?v=A106';
import {initStudyUI} from '/aster-study-ui.js?v=A106';
import {LEARNING_KEY,learningState,recallLessons} from '/noyau-learning.js?v=A91';
import {photoCommand,photoEditLabel,hasPhotoEdit,applyPhotoCommand} from '/aster-photo-core.js?v=A105';
import {initImageUI} from '/aster-image-ui.js?v=A107';
import {initConversationUI} from '/aster-conversation-ui.js?v=A111';
import {homeRoute} from '/aster-conversation-core.js?v=A111';

const $=id=>document.getElementById(id), memory=window.BlobLocalMemory;
let db,state=workshopState(null),current=newStudioDossier(crypto.randomUUID());
let busy=false,blocked=false,saveTimer=null,saveQueue=Promise.resolve(),unsaved=false,saveError=null;
let previewGeneration=0,previewKey='',previewPromise=Promise.resolve(),previewCanvases=null;
let deliveryURLs=[],backupURLs=[],deliveryFile=null;
let writingController=null,studyUI=null,imageUI=null;
let conversationUI=null,presentationActive=false;
let photoFocusId=null,photoPreviewKey='',photoGeneration=0,photoRenderAbort=null,photoPreviewPromise=Promise.resolve(),photoURLs=[];
const clone=x=>structuredClone(x), stamp=()=>new Date().toISOString();
const status=(text,error=false)=>{ $('studioStatus').textContent=text; $('studioStatus').className='status'+(error?' error':''); if($('projectsDialog').open){$('projectStatus').hidden=false;$('projectStatus').textContent=text;$('projectStatus').className='status'+(error?' error':'');}else if(error){$('studioStatus').scrollIntoView({block:'center'});} };
function el(tag,text,cls){const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;return node;}
function button(text,handler,cls='quiet'){const b=el('button',text,cls);b.type='button';b.onclick=handler;return b;}
function controls(){
  for(const id of ['studioInput','attachPhotos','attachDocument','returnConversation','sendStudio','openProjects','newStudioProject','restoreStudio','editTitle','approveStudio'])$(id).disabled=!db||busy||blocked;
  $('prepareDelivery').disabled=!db||busy||blocked||!$('approveStudio').checked||!previewCanvases;
  $('backupStudio').disabled=!db||busy; $('cancelEdit').disabled=busy||blocked;
  $('recoveryActions').hidden=!blocked;
  $('writeStudio').disabled=!db||busy||blocked;
  $('stopWriting').hidden=!writingController;
  $('stopWriting').disabled=!writingController;
  $('photoDownloads').hidden=busy||blocked;
  const proposal=current.facts.details&&current.facts.business&&current.facts.title?matchingWriting(current.runs,current.facts,MODEL.id,MODEL.revision):null;
  $('useWriting').disabled=!db||busy||blocked||!proposal?.writing.steps.every(s=>s.status==='done');
  for(const node of document.querySelectorAll('[data-edit-control]'))node.disabled=busy||blocked;
}
async function write(next){
  if(blocked)throw saveError||Error('Enregistrement à reprendre.');
  const wanted=clone(next);
  let written;
  try {
    written=await saveDossier(db,state,wanted);
    const actual=workshopState(await memory.setting(db,WORKSHOP_KEY));
    if(actual.revision!==written.revision || JSON.stringify(actual.dossiers.find(d=>d.id===wanted.id))!==JSON.stringify(wanted))throw Error('Enregistrement écrit mais relecture non confirmée.');
    state=actual;current=studioDossier(wanted);
  } catch(error) {
    blocked=true;saveError=error;controls();
    throw error;
  }
}
function queueDraft(){
  clearTimeout(saveTimer);
  const text=$('studioInput').value;
  const general=draftIsGeneral(text);
  if(!db||blocked)return Promise.resolve();
  saveQueue=saveQueue.catch(()=>{}).then(async()=>{
    if(blocked)return;
    try{await persistDraft(text,general);unsaved=$('studioInput').value!==text;$('draftStatus').textContent=unsaved?'Dernières modifications en cours…':'Brouillon enregistré sur cet appareil.';}
    catch(e){unsaved=true;$('draftStatus').textContent='Brouillon non enregistré.';status(e.message+' Récupère ton brouillon avant de recharger.',true);}
  });
  return saveQueue;
}
async function action(fn){
  if(busy||blocked||!db)return;
  busy=true;controls();clearTimeout(saveTimer);
  try {await saveQueue;if(blocked)throw saveError||Error('Enregistrement à reprendre.');if(unsaved)await flushVisibleDraft();await fn();}
  catch(e){status(e.name==='QuotaExceededError'?'Espace insuffisant. Tes derniers projets enregistrés sont conservés. Récupère le brouillon avant de recharger.':e.message,true);}
  finally{busy=false;controls();}
}
function revoke(list){for(const url of list)URL.revokeObjectURL(url);list.length=0;}
function invalidateDelivery(){revoke(deliveryURLs);deliveryFile=null;$('deliveryLinks').replaceChildren();$('individualFiles').replaceChildren();$('delivery').hidden=true;$('shareDelivery').hidden=true;$('approveStudio').checked=false;}
function addDownload(root,blob,name,label,urls=deliveryURLs,primary=false){const a=el('a',label,primary?'button':'');a.href=URL.createObjectURL(blob);urls.push(a.href);a.download=name;root.append(a);return a;}
function renderMessages(){
  const root=$('studioMessages');root.replaceChildren();
  $('returnConversation').hidden=!presentationActive||!!current.studio.editing;
  if(!presentationActive){$('studioQuestion').hidden=true;$('cancelEdit').hidden=true;$('studioInput').placeholder='Parle-moi, pose une question ou décris un travail…';$('studioInput').maxLength=4000;return;}
  for(const m of current.studio.messages){const p=el('div',null,'message '+m.role);p.append(el('span',m.role==='user'?'Toi':'Aster','who'),document.createTextNode(m.text));root.append(p);}
  $('studioQuestion').textContent=questionFor(current);
  $('studioQuestion').hidden=current.studio.messages.at(-1)?.text.endsWith(questionFor(current))||false;
  $('cancelEdit').hidden=!current.studio.editing;
  const step=nextStep(current), key=current.studio.editing||step;
  $('studioInput').placeholder=current.studio.editing?'Ta correction…':({business:'Le nom à afficher…',title:'Le titre de la réalisation…',details:'Raconte ce que tu veux présenter…',photos:'Une information à ajouter ?'}[step]||'Une correction ou une précision…');
  $('studioInput').maxLength=!current.studio.editing||key.startsWith('caption')?1800:(FIELDS[key]||1800);
}
function edit(key){return action(async()=>{if($('studioInput').value.trim())throw Error('Envoie ou efface d’abord le message en cours pour ne pas le perdre.');presentationActive=true;await write(beginEdit(current,key));renderMessages();$('studioInput').focus();});}
function renderPhotos(){
  const root=$('studioPhotos');root.replaceChildren();
  current.photos.forEach((p,i)=>{
    const box=el('div',null,'photo'),img=el('img');img.src=p.data;img.alt='Photo '+(i+1)+' : '+p.name;
    const remove=button('×',()=>action(async()=>{const d=studioDossier(current);d.photos=d.photos.filter(x=>x.id!==p.id);d.rightsConfirmed=false;invalidateApproval(d);record(d,'assistant','Photo retirée. '+questionFor(d));await write(d);invalidateDelivery();render();}),'remove-photo');remove.setAttribute('aria-label','Retirer la photo '+(i+1));remove.dataset.editControl='';
    const choose=button('',()=>action(async()=>{photoFocusId=p.id;renderPhotoResult();await photoPreviewPromise;$('photoResult').scrollIntoView({block:'center'});}),'photo-select');choose.setAttribute('aria-label','Voir et retoucher la photo '+(i+1));choose.dataset.editControl='';choose.append(img);
    box.append(choose,remove,el('small','Photo '+(i+1)));
    if(i===0)box.append(el('small','Couverture'));
    else {const b=button('En couverture',()=>action(async()=>{const d=studioDossier(current);d.photos=[d.photos[i],...d.photos.filter((_,j)=>j!==i)];invalidateApproval(d);await write(d);invalidateDelivery();render();}));b.dataset.editControl='';box.append(b);}
    root.append(box);
  });
}
function renderPhotoResult(){
  const p=current.photos.find(p=>p.id===photoFocusId)||current.photos[0];
  $('photoResult').hidden=!p;
  if(!p){photoGeneration++;photoRenderAbort?.abort();photoPreviewKey='';revoke(photoURLs);$('photoPreview').replaceChildren();$('photoDownloads').replaceChildren();return;}
  photoFocusId=p.id;const index=current.photos.indexOf(p),key=JSON.stringify([current.id,p.id,p.data,p.edit]);
  $('photoResultTitle').textContent='Photo '+(index+1)+' · '+photoEditLabel(p);
  $('photoSource').hidden=!hasPhotoEdit(p);$('photoSourceImage').src=p.data;
  if(key===photoPreviewKey)return;
  photoPreviewKey=key;const generation=++photoGeneration;photoRenderAbort?.abort();photoRenderAbort=new AbortController();
  revoke(photoURLs);$('photoDownloads').replaceChildren();$('photoPreview').replaceChildren(el('p','Préparation de la photo…','helper'));$('photoRenderError').hidden=true;
  photoPreviewPromise=(async()=>{
    let canvas;
    try{
      canvas=await photoCanvas(p,{signal:photoRenderAbort.signal});
      const png=await canvasBlob(canvas);
      if(generation!==photoGeneration){canvas.width=canvas.height=1;return;}
      canvas.setAttribute('role','img');canvas.setAttribute('aria-label',$('photoResultTitle').textContent);$('photoPreview').replaceChildren(canvas);
      addDownload($('photoDownloads'),png,safeFilename(p.name.replace(/\.[^.]+$/,''))+(hasPhotoEdit(p)?'-retouchee':'-copie')+'.png','Télécharger cette photo · PNG',photoURLs,true);
    }catch(e){if(canvas)canvas.width=canvas.height=1;if(generation!==photoGeneration)return;photoPreviewKey='';$('photoPreview').replaceChildren();$('photoRenderError').hidden=false;$('photoRenderError').textContent='Rendu indisponible : '+e.message;}
    finally{if(generation===photoGeneration)controls();}
  })();
}
async function retouchPhoto(command,text){
  const selected=current.photos.findIndex(p=>p.id===photoFocusId),target={...command,index:command.index??Math.max(0,selected)};
  const result=applyPhotoCommand(current,target,text);
  if(result.changed){await write(result.dossier);invalidateDelivery();}
  else{const d=studioDossier(current);d.studio.draft='';await write(d);}
  photoFocusId=current.photos[result.index].id;$('studioInput').value='';unsaved=false;render();await Promise.all([photoPreviewPromise,previewPromise]);
  if(!$('photoRenderError').hidden)throw Error('Réglages enregistrés, mais rendu indisponible. La copie importée est conservée.');
  status(result.changed?'Photo préparée. Vérifie le rendu puis télécharge-la.':'Ces réglages sont déjà appliqués. Aucune nouvelle copie enregistrée.');$('photoResult').scrollIntoView({block:'center'});
}
function renderResult(){
  const complete=current.facts.details&&current.facts.business&&current.facts.title&&current.photos.length&&current.captions.length===3;
  $('studioResult').hidden=!complete;
  if(!complete){previewGeneration++;previewKey='';previewCanvases=null;$('studioPreviews').replaceChildren();return;}
  $('resultTitle').textContent=current.facts.title;$('resultBusiness').textContent=current.facts.business;
  $('studioFacts').textContent=Object.entries(current.facts).filter(([,v])=>v).map(([k,v])=>FIELD_NAMES[k]+' : '+v).join('\n');
  const captions=$('studioCaptions');captions.replaceChildren();
  current.captions.forEach((text,i)=>{const box=el('article',null,'caption'),head=el('div',null,'row'),change=button('Modifier',()=>edit('caption'+i));change.dataset.editControl='';head.append(el('span',['Présentation','Publication','Message court'][i]),change);box.append(head,el('p',text));captions.append(box);});
  renderWriting();
  const edits=$('editFacts');edits.replaceChildren();for(const [key,label] of Object.entries(FIELD_NAMES)){const b=button(label,()=>edit(key),'secondary');b.dataset.editControl='';edits.append(b);}
  const key=JSON.stringify({facts:current.facts,photo:current.photos[0].id,data:current.photos[0].data,edit:current.photos[0].edit});
  if(previewKey===key)return;
  previewKey=key;previewCanvases=null;const generation=++previewGeneration, frozen=clone(current);
  $('studioPreviews').replaceChildren(el('p','Préparation des aperçus…','muted'));$('previewError').hidden=true;
  previewPromise=(async()=>{
    try{
      const vertical=await poster(frozen,'vertical'),story=await poster(frozen,'story');
      if(generation!==previewGeneration)return;
      previewCanvases={vertical,story,key};
      const figures=[['Publication · 1080 × 1350',vertical],['Story · 1080 × 1920',story]].map(([label,canvas])=>{const fig=el('figure');canvas.setAttribute('role','img');canvas.setAttribute('aria-label',label+' — '+frozen.facts.title);fig.append(canvas,el('figcaption',label));return fig;});
      $('studioPreviews').replaceChildren(...figures);
    }catch(e){if(generation!==previewGeneration)return;previewCanvases=null;previewKey='';$('studioPreviews').replaceChildren();$('previewError').hidden=false;$('previewError').textContent=e.message;}
    finally{if(generation===previewGeneration)controls();}
  })();
}
function renderWriting(){
  const run=matchingWriting(current.runs,current.facts,MODEL.id,MODEL.revision),root=$('writingProposals');root.replaceChildren();
  const count=run?.writing.steps.filter(s=>s.status==='done').length||0;
  $('writingProgress').textContent=run?(count===3?'Trois propositions enregistrées. Relis-les avant de les utiliser.':count+'/3 texte(s) enregistré(s). '+(writingController?'La préparation continue.':'Reprise manuelle à la prochaine étape.')):'Le modèle déjà installé rédige trois propositions, une à une. Garde cette page ouverte.';
  $('writeStudio').hidden=count===3;
  $('writeStudio').textContent=run&&count<3?'Reprendre la rédaction':'Rédiger avec mon modèle local';
  $('useWriting').hidden=count!==3;
  if(run?.writing.methods?.length)root.append(el('p',run.writing.methods.length+' méthode(s) validée(s) incluses dans ce travail. Relis leur effet.','helper'));
  if(run?.writing.omittedMethodIds?.length)root.append(el('p','Une méthode trop longue a été laissée de côté pour conserver tous tes faits.','helper'));
  if(run)for(const [i,s]of run.writing.steps.entries()){
    const box=el('article',null,'caption');box.append(el('strong',WRITING_STEPS[i].label));
    box.append(el('p',s.status==='done'?s.text:s.status==='running'&&writingController?'Rédaction en cours…':'À préparer'));
    if(s.flags.length)box.append(el('p',s.flags.join(' '),'helper'));
    root.append(box);
  }
}
async function prepareWriting(command=''){
  if(!current.facts.business||!current.facts.title||!current.facts.details)throw Error('Complète le nom, le titre et les faits avant de rédiger.');
  if(!current.photos.length)throw Error('Ajoute d’abord une photo à cette présentation pour pouvoir relire les textes avec les visuels.');
  $('writingPanel').open=true;$('writingPanel').scrollIntoView({block:'center'});
  const existing=matchingWriting(current.runs,current.facts,MODEL.id,MODEL.revision);
  if(existing?.writing.steps.every(s=>s.status==='done')){if(command){const d=studioDossier(current);d.studio.draft='';await write(d);$('studioInput').value='';unsaved=false;}renderWriting();status('Propositions déjà enregistrées : aucun nouveau calcul.');return;}
  if(!existing&&current.runs.length>=WRITING_LIMITS.runs)throw Error('Vingt travaux conservés dans ce projet. Sauvegarde-le avant de préparer un nouveau projet. Aucun résultat supprimé.');
  if(!command&&$('studioInput').value.trim())throw Error('Envoie d’abord le message en cours pour que la rédaction utilise tes dernières informations.');
  const projectId=current.id;let firstSave=true;
  writingController=new AbortController();controls();
  try{
    const methods=existing?[]:recallLessons(learningState(await memory.setting(db,LEARNING_KEY)),'demandes client présentation textes '+Object.values(current.facts).join(' '));
    const run=existing||newWritingRun(crypto.randomUUID(),current.facts,MODEL.id,MODEL.revision,stamp(),methods);
    await runLocalWriting(run,{signal:writingController.signal,onProgress:t=>{status(t);$('writingProgress').textContent=t;},save:async saved=>{
      if(blocked||current.id!==projectId)throw Error('Le projet a changé. Reprise manuelle nécessaire.');
      const d=studioDossier(current),i=d.runs.findIndex(r=>r.id===saved.id);
      if(!matchingWriting([saved],d.facts,MODEL.id,MODEL.revision))throw Error('Les faits ont changé pendant la rédaction.');
      if(i<0)d.runs.push(saved);else d.runs[i]=saved;
      if(firstSave&&command){record(d,'user',command);record(d,'assistant','Préparation de trois propositions avec le modèle local. Les textes actuels restent conservés pour la relecture.');d.studio.draft='';}
      d.updatedAt=stamp();await write(d);
      if(firstSave&&command){$('studioInput').value='';unsaved=false;renderMessages();}
      firstSave=false;renderWriting();controls();
    }});
    status('Les trois propositions sont enregistrées. Vérifie les faits, puis utilise celles qui te conviennent.');
  }finally{writingController=null;if(current.facts.details&&current.facts.business&&current.facts.title)renderWriting();controls();}
}
$('writeStudio').onclick=()=>action(()=>prepareWriting());
$('stopWriting').onclick=()=>{writingController?.abort();status('Mise en pause. Les textes déjà enregistrés sont conservés.');};
$('useWriting').onclick=()=>action(async()=>{
  const run=matchingWriting(current.runs,current.facts,MODEL.id,MODEL.revision);
  if(!run?.writing.steps.every(s=>s.status==='done'))throw Error('Les trois propositions ne sont pas encore prêtes.');
  const d=studioDossier(current);d.captions=run.writing.steps.map(s=>s.text);d.source='LOCAL_LLM_REVIEW';invalidateApproval(d);d.updatedAt=stamp();
  await write(d);invalidateDelivery();render();status('Propositions reprises dans les textes. Corrige-les si nécessaire et confirme ta relecture avant livraison.');
});
function render(){renderMessages();renderPhotos();renderPhotoResult();renderResult();imageUI?.render();controls();}
function renderProjects(){
  const usage=dossierMemory(state.dossiers),size=n=>n>=1048576?(n/1048576).toLocaleString('fr-FR',{maximumFractionDigits:1})+' Mio':Math.ceil(n/1024)+' Kio';
  $('studioMemory').textContent=usage.projects+'/6 projets · photos : '+size(usage.photosBytes)+' · textes, échanges et travaux : '+size(usage.workBytes)+'. Les poids du modèle sont stockés séparément et réutilisés.';
  const root=$('savedStudioProjects');root.replaceChildren();
  if(!state.dossiers.length)root.append(el('p','Ton premier projet sera enregistré pendant cet échange.','muted'));
  for(const d of [...state.dossiers].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))){
    const row=el('div',null,'project-row');const open=button(d.facts.title||d.facts.business||'Présentation en préparation',()=>action(async()=>{await flushVisibleDraft();current=studioDossier(state.dossiers.find(x=>x.id===d.id));presentationActive=true;$('studioInput').value=current.studio.draft;unsaved=false;invalidateDelivery();render();$('projectsDialog').close();status('Projet repris. Tes photos, tes textes et tes échanges sont conservés.');}),'project-open');
    open.append(el('small',d.photos.length+' photo'+(d.photos.length>1?'s':'')+' · '+new Date(d.updatedAt).toLocaleDateString('fr-FR')+(d.id===current.id?' · ouvert':'')));
    const remove=button('Retirer',()=>action(async()=>{await flushVisibleDraft();if(!confirm('Retirer ce projet de cet appareil ? Garde sa sauvegarde pour pouvoir le récupérer.'))return;state=await saveDossier(db,state,d,true);const actual=workshopState(await memory.setting(db,WORKSHOP_KEY));if(actual.revision!==state.revision||actual.dossiers.some(x=>x.id===d.id))throw Error('Suppression non confirmée.');state=actual;if(current.id===d.id){current=studioDossier(state.dossiers.at(-1)||newStudioDossier(crypto.randomUUID()));$('studioInput').value=current.studio.draft;invalidateDelivery();render();}renderProjects();status('Projet retiré après confirmation.');}),'quiet danger');
    row.append(open,remove);root.append(row);
  }
}
async function flushVisibleDraft(){
  clearTimeout(saveTimer);await saveQueue;
  if(blocked)throw saveError;
  await persistDraft($('studioInput').value,draftIsGeneral($('studioInput').value));
  unsaved=false;
}
function draftIsGeneral(text){return !presentationActive||homeRoute(text,{editing:!!current.studio.editing,fieldCommand:!!editCommand(text),presentationActive})==='dialogue';}
async function persistDraft(text,general){
  if(general){if(!conversationUI)throw Error('Conversation encore indisponible. Ton brouillon reste dans le champ.');await conversationUI.saveDraft(text);}
  else if(current.studio.draft!==text){const d=studioDossier(current);d.studio.draft=text;d.updatedAt=stamp();await write(d);}
}
async function clearGeneralDraft(){if(conversationUI)await conversationUI.saveDraft('');}
$('studioInput').addEventListener('input',()=>{unsaved=true;$('draftStatus').textContent='Enregistrement du brouillon…';clearTimeout(saveTimer);saveTimer=setTimeout(queueDraft,350);});
$('studioForm').onsubmit=e=>{e.preventDefault();return action(async()=>{
  const text=$('studioInput').value;
  if(!current.studio.editing&&await studyUI?.handle(text)){await clearGeneralDraft();return;}
  const retouch=!current.studio.editing&&!editCommand(text)&&photoCommand(text);
  if(retouch&&retouch.operation!=='unsupported'){await retouchPhoto(retouch,text);await clearGeneralDraft();return;}
  if(!current.studio.editing&&!editCommand(text)&&await imageUI?.handle(text,Math.max(0,current.photos.findIndex(p=>p.id===photoFocusId)))){await clearGeneralDraft();return;}
  if(retouch){await retouchPhoto(retouch,text);await clearGeneralDraft();return;}
  if(!current.studio.editing&&writingRequest(text)){await prepareWriting(text);await clearGeneralDraft();return;}
  const route=homeRoute(text,{editing:!!current.studio.editing,fieldCommand:!!editCommand(text),presentationActive});
  if(route==='start-presentation'){
    const d=studioDossier(current);record(d,'user',text);record(d,'assistant','Préparons ta présentation. '+questionFor(d));d.studio.draft='';await write(d);await clearGeneralDraft();presentationActive=true;$('studioInput').value='';unsaved=false;render();status('Présentation en cours. Tu peux aussi poser une question à tout moment.');return;
  }
  if(route==='dialogue'){
    if(!conversationUI)throw Error('Conversation encore indisponible. Ton message est conservé.');
    presentationActive=false;renderMessages();await conversationUI.handle(text);return;
  }
  const d=submitMessage(current,text);await write(d);
  $('studioInput').value='';unsaved=false;$('draftStatus').textContent='Échange enregistré sur cet appareil.';
  invalidateDelivery();render();status('Projet enregistré.');$('studioMessages').lastElementChild?.scrollIntoView({block:'center'});
});};
$('attachPhotos').onclick=()=>{if(!busy&&!blocked)$('studioPhotoInput').click();};
$('attachDocument').onclick=()=>{if(!busy&&!blocked)conversationUI?.chooseDocument();};
$('returnConversation').onclick=()=>action(async()=>{await flushVisibleDraft();presentationActive=false;$('studioInput').value=conversationUI?.draft()||'';unsaved=false;renderMessages();$('studioInput').focus();});
$('studioPhotoInput').onchange=()=>action(async()=>{
  try{
    const files=[...($('studioPhotoInput').files||[])];if(!files.length)return;
    if(files.length+current.photos.length>MAX_PHOTOS)throw Error('Six photos maximum par projet.');
    await flushVisibleDraft();const photos=[];
    for(const file of files){status('Préparation de '+file.name+'…');photos.push(await importPhoto(file,crypto.randomUUID()));}
    const next=addPhotos(current,photos);await write(next);invalidateDelivery();render();status('Photos enregistrées dans cet appareil.');
  }finally{$('studioPhotoInput').value='';}
});
$('editTitle').onclick=()=>edit('title');
$('cancelEdit').onclick=()=>action(async()=>{if($('studioInput').value.trim())throw Error('Envoie ou efface d’abord ta correction pour ne pas la perdre.');const d=studioDossier(current);d.studio.editing=null;record(d,'assistant','Modification annulée. '+questionFor(d));await write(d);renderMessages();});
$('approveStudio').onchange=controls;
$('prepareDelivery').onclick=()=>action(async()=>{
  if(!$('approveStudio').checked)throw Error('Relis et confirme les informations et les photos avant de préparer les fichiers.');
  await flushVisibleDraft();await previewPromise;if(!previewCanvases)throw Error('Les aperçus doivent être prêts.');
  const d=studioDossier(current);d.factsConfirmed=true;d.rightsConfirmed=true;const errors=validateDeliverable(d);if(errors.length)throw Error(errors.join(' '));
  status('Préparation des fichiers…');
  const png=await canvasBlob(previewCanvases.vertical),story=await canvasBlob(previewCanvases.story),html=printableHTML(await photoDeliveryDossier(d)),text=d.captions.map((s,i)=>'TEXTE '+(i+1)+'\n\n'+s).join('\n\n──────────\n\n');
  const readme='VOTRE PRÉSENTATION\n\npublication.png : visuel vertical 1080 × 1350.\nstory.png : visuel vertical 1080 × 1920.\ntextes.txt : trois textes à copier et adapter à vos réseaux.\nfiche-realisation.html : ouvrez ce fichier dans un navigateur pour le lire ou l’imprimer en PDF.\n\nLes fichiers restent à vérifier avant diffusion. Les photos et les informations ont été fournies par le responsable du projet.\nAucune publication automatique.\n';
  const zip=zipFiles([{name:'publication.png',data:new Uint8Array(await png.arrayBuffer())},{name:'story.png',data:new Uint8Array(await story.arrayBuffer())},{name:'textes.txt',data:text},{name:'fiche-realisation.html',data:html},{name:'LIRE-MOI.txt',data:readme}]);
  d.exports++;d.validatedAt=stamp();d.updatedAt=d.validatedAt;await write(d);
  revoke(deliveryURLs);$('deliveryLinks').replaceChildren();$('individualFiles').replaceChildren();
  const base=safeFilename(d.facts.title);
  addDownload($('deliveryLinks'),zip,base+'-presentation.zip','Télécharger la présentation',deliveryURLs,true);
  addDownload($('individualFiles'),png,base+'-publication.png','Visuel de publication · PNG');
  addDownload($('individualFiles'),story,base+'-story.png','Story · PNG');
  addDownload($('individualFiles'),new Blob([text],{type:'text/plain;charset=utf-8'}),base+'-textes.txt','Les trois textes · TXT');
  addDownload($('individualFiles'),new Blob([html],{type:'text/html;charset=utf-8'}),base+'-fiche.html','Fiche imprimable · HTML');
  deliveryFile=typeof File==='function'?new File([zip],base+'-presentation.zip',{type:'application/zip'}):null;
  $('shareDelivery').hidden=!(deliveryFile&&navigator.canShare?.({files:[deliveryFile]}));
  $('delivery').hidden=false;status('Présentation préparée et projet enregistré. Télécharge les fichiers pour les conserver dans Fichiers.');$('delivery').scrollIntoView({block:'nearest'});
});
$('shareDelivery').onclick=async()=>{if(!deliveryFile)return;try{await navigator.share({files:[deliveryFile],title:current.facts.title});}catch(e){if(e.name!=='AbortError')status('Le partage n’a pas abouti. Utilise le téléchargement de la présentation.',true);}};
$('openProjects').onclick=()=>action(async()=>{await flushVisibleDraft();renderProjects();$('projectsDialog').showModal();});
$('closeProjects').onclick=()=>$('projectsDialog').close();
$('newStudioProject').onclick=()=>action(async()=>{
  await flushVisibleDraft();if(state.dossiers.length>=MAX_DOSSIERS)throw Error('Six projets sont conservés. Sauvegarde puis retire un ancien projet pour en commencer un autre.');
  current=newStudioDossier(crypto.randomUUID());presentationActive=true;$('studioInput').value='';invalidateDelivery();render();$('projectsDialog').close();status('Nouveau projet. Raconte ta réalisation et ajoute tes photos.');
});
function backupLink(d,label='Télécharger la sauvegarde privée'){
  revoke(backupURLs);$('projectBackupLinks').replaceChildren();
  addDownload($('projectBackupLinks'),new Blob([exportPrivateProject(d)],{type:'application/json'}),safeFilename(d.facts.title)+'-projet-prive.json',label,backupURLs,true);
}
$('backupStudio').onclick=()=>{if(blocked)return $('saveRescue').onclick();return action(async()=>{await flushVisibleDraft();backupLink(current);status('Copie privée prête. Télécharge-la dans Fichiers pour pouvoir reprendre ce projet.');});};
$('restoreStudio').onchange=()=>action(async()=>{
  try{const file=$('restoreStudio').files?.[0];if(!file)return;if(file.size>8*1024*1024)throw Error('Sauvegarde supérieure à 8 Mio.');
    const restored=importPrivateProject(await file.text(),crypto.randomUUID());await flushVisibleDraft();
    if(state.dossiers.length>=MAX_DOSSIERS)throw Error('Six projets conservés. Sauvegarde puis retire un projet avant d’importer.');
    await write(restored);$('studioInput').value=current.studio.draft;unsaved=false;invalidateDelivery();render();renderProjects();$('projectsDialog').close();status('Projet repris dans une nouvelle copie. Relis les informations avant livraison.');
  }finally{$('restoreStudio').value='';}
});
$('saveRescue').onclick=()=>{try{const d=studioDossier(current);d.studio.draft=$('studioInput').value;backupLink(d,'Récupérer le projet et le message en cours');$('projectsDialog').showModal();}catch(e){status(e.message,true);}};
$('reloadProject').onclick=()=>{if(!confirm('Le texte non enregistré restera dans la zone de saisie. Relire les projets enregistrés ?'))return;(async()=>{try{const text=$('studioInput').value;state=workshopState(await memory.setting(db,WORKSHOP_KEY));current=studioDossier(state.dossiers.find(x=>x.id===current.id)||state.dossiers.at(-1)||newStudioDossier(crypto.randomUUID()));blocked=false;saveError=null;$('studioInput').value=text;unsaved=text!==current.studio.draft;invalidateDelivery();render();status('Données enregistrées relues. Vérifie le message conservé avant de l’envoyer.');}catch(e){status(e.message,true);}})();};
$('downloadOffer').onclick=()=>{
  const html='<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vos réalisations, prêtes à montrer — Fabien</title><style>body{font:18px/1.65 system-ui,sans-serif;max-width:780px;margin:70px auto;padding:0 25px;color:#214432;background:#faf9f2}h1{font:54px/1.1 Georgia,serif;letter-spacing:-2px}small{letter-spacing:2px}li{margin:10px 0}.box{border-top:2px solid;padding-top:25px;margin-top:35px}@media print{body{margin:20px}h1{font-size:40px}}</style><small>PRÉSENTATION DE SERVICE · FABIEN</small><h1>Vos réalisations,<br>prêtes à montrer.</h1><p>Vous avez les photos et le savoir-faire. Je prépare une présentation claire pour mettre votre travail en valeur.</p><div class="box"><h2>Pour une réalisation</h2><ul><li>Deux visuels : une publication et une story.</li><li>Retouches simples des photos fournies : luminosité, contraste, noir et blanc, rotation ou carré centré.</li><li>Trois textes pour présenter votre réalisation.</li><li>Une fiche illustrée, imprimable depuis votre navigateur.</li><li>Une relecture ensemble avant livraison des fichiers.</li></ul></div><h2>Comment cela se passe</h2><p>Vous fournissez jusqu’à six photos que vous avez le droit d’utiliser et les informations à afficher. Je prépare les fichiers. Vous vérifiez les faits et validez la présentation.</p><p>Tarif, délai et éventuelles retouches sont convenus avant la commande.</p><div class="box"><p>Mise en page et retouches simples de la copie importée (1 600 pixels maximum). Transformation du décor par IA, création d’images, vidéos, diffusion sur les réseaux et résultats commerciaux garantis ne font pas partie de cette prestation.</p><p>Pour discuter d’une réalisation, contactez la personne qui vous a transmis cette présentation.</p></div></html>';
  const root=$('projectBackupLinks');addDownload(root,new Blob([html],{type:'text/html;charset=utf-8'}),'offre-presentation-fabien.html','Télécharger l’offre à montrer',backupURLs,true);root.scrollIntoView({block:'nearest'});
};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&unsaved&&!busy&&!blocked)queueDraft();});
window.addEventListener('pagehide',()=>{if(unsaved&&!busy&&!blocked)queueDraft();});
window.addEventListener('beforeunload',e=>{if(unsaved||busy||studyUI?.pending()||conversationUI?.pending()){ e.preventDefault();e.returnValue='';}});
try{const channel=new BroadcastChannel('noyau-recovery');channel.onmessage=e=>{if(e.data==='RESTORED'){conversationUI?.invalidate();imageUI?.invalidate();studyUI?.invalidate();writingController?.abort();photoGeneration++;photoRenderAbort?.abort();photoPreviewKey='';revoke(photoURLs);$('photoDownloads').replaceChildren();previewGeneration++;previewKey='';previewCanvases=null;invalidateDelivery();blocked=true;saveError=Error('Une sauvegarde a été restaurée dans un autre onglet.');status(saveError.message+' Récupère ton brouillon puis rouvre la page.',true);controls();}};}catch{}
async function init(){
  try{
    db=await memory.open();state=workshopState(await memory.setting(db,WORKSHOP_KEY));
    current=studioDossier([...state.dossiers].sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)).at(-1)||current);
    presentationActive=!!current.studio.editing;
    $('studioInput').value=current.studio.draft;render();status('Prêt. Tu peux parler à Aster ou lui demander un travail.');
    $('draftStatus').textContent=current.studio.draft?'Brouillon récupéré.':'Tu peux dicter avec le microphone de ton clavier.';
    studyUI=await initStudyUI({db,root:$('studySession'),execute:action,status,onAccepted:async()=>{if(presentationActive){const d=studioDossier(current);d.studio.draft='';await write(d);}else await clearGeneralDraft();$('studioInput').value='';unsaved=false;$('draftStatus').textContent='Demande d’étude enregistrée sur cet appareil.';}});
    imageUI=await initImageUI({root:$('imageSession'),execute:action,status,getProject:()=>current,getSource:async id=>{const p=current.photos.find(p=>p.id===id);if(!p)throw Error('Photo source introuvable.');return (await photoCanvas(p)).toDataURL('image/jpeg',.9);},saveDraft:async value=>{const d=studioDossier(current);if(value)d.studio.imageRequest=value;else delete d.studio.imageRequest;d.studio.draft='';await write(d);$('studioInput').value='';unsaved=false;$('draftStatus').textContent='Demande d’image enregistrée. Aucun lancement automatique.';}});
    try{conversationUI=await initConversationUI({db,root:$('generalConversation'),execute:action,status,onAccepted:async()=>{$('studioInput').value='';unsaved=false;$('draftStatus').textContent='Échange enregistré sur cet appareil.';},onDraft:text=>action(async()=>{if($('studioInput').value.trim())throw Error('Conserve ou envoie ton brouillon avant de reprendre cette demande.');presentationActive=false;$('studioInput').value=text;unsaved=true;await flushVisibleDraft();renderMessages();$('studioInput').focus();})});
      if(conversationUI.draft()===null)await conversationUI.saveDraft(!presentationActive?current.studio.draft:'');
      if(!presentationActive)$('studioInput').value=conversationUI.draft()||'';
      $('draftStatus').textContent=$('studioInput').value?'Brouillon récupéré.':'Tu peux dicter avec le microphone de ton clavier.';controls();
    }catch(e){status('Conversation indisponible : '+e.message+' Les projets restent disponibles.',true);}
    // Old deep links keep opening the retained tools without changing their data.
    if(/^#(?:projectPanel|documentsPanel|researchPanel|restorePanel|learnPanel|settingsPanel|workPanel|localSetup|dialogue)$/.test(location.hash))location.replace('/espace-local.html'+location.hash);
  }catch(e){db=null;status('Ouverture impossible : '+e.message,true);controls();}
}
init();

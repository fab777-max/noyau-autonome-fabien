import {STUDY_KEY,studyState,studyCandidates} from '/aster-study-core.js?v=A111';
import {LEARNING_KEY,learningState,retainLesson} from '/noyau-learning.js?v=A91';
// Study evidence and an explicitly accepted method commit in the same transaction.
export async function commitStudy(db,expected,transform,{retain=null}={}){
 let next,learned;
 const operation=()=>new Promise((resolve,reject)=>{
  const tx=db.transaction('settings','readwrite'),store=tx.objectStore('settings');let raw,mem,pending=2,error;
  tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(error||tx.error||Error('Étude non enregistrée.'));
  const ready=()=>{if(--pending)return;try{
   const current=studyState(raw);if(current.revision!==expected)throw Error('Étude modifiée ou restaurée ailleurs. Relis les données avant de reprendre.');
   next=studyState(transform(current));next.revision=current.revision+1;if(!Number.isSafeInteger(next.revision))throw Error('Compteur d’étude incompatible.');
   if(retain){
    const session=next.sessions.find(s=>s.id===retain.sessionId),candidate=session&&studyCandidates(session).find(c=>c.family===retain.family);
    if(!session?.grade||!candidate||session.retained.some(r=>r.family===retain.family))throw Error('Note d’abord ce bilan, puis choisis une méthode non encore retenue.');
    learned=learningState(mem);
    const answer=retain.answer?.trim();if(!answer||answer.length>400)throw Error('Une méthode contient de 1 à 400 caractères.');
    const normalize=t=>t.normalize('NFC').replace(/\s+/g,' ').trim();
    const duplicate=learned.lessons.find(m=>normalize(m.answer)===normalize(answer));
    if(learned.lessons.some(m=>m.question.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim()===candidate.question.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim()&&normalize(m.answer)!==normalize(answer)))throw Error('Une autre méthode existe pour cette situation. Compare-les dans la mémoire avant de remplacer la précédente.');
    const id=duplicate?.id||retain.id;
    if(!duplicate)learned=retainLesson(learned,candidate.question,answer,id);
    session.retained.push({family:candidate.family,id,at:new Date().toISOString()});
    store.put(learned,LEARNING_KEY);
   }
   next=studyState(next);store.put(next,STUDY_KEY);
  }catch(e){error=e;tx.abort();}};
  store.get(STUDY_KEY).onsuccess=e=>{raw=e.target.result;ready();};store.get(LEARNING_KEY).onsuccess=e=>{mem=e.target.result;ready();};
 });
 if(globalThis.navigator?.locks?.request)await navigator.locks.request('noyau-data-maintenance',{mode:'shared'},operation);else await operation();
 const actual=await new Promise((resolve,reject)=>{const tx=db.transaction('settings','readonly'),store=tx.objectStore('settings'),out={};store.get(STUDY_KEY).onsuccess=e=>{out.study=e.target.result;};store.get(LEARNING_KEY).onsuccess=e=>{out.learning=e.target.result;};tx.oncomplete=()=>resolve(out);tx.onerror=tx.onabort=()=>reject(tx.error||Error('Relecture de l’étude impossible.'));});
 if(JSON.stringify(next)!==JSON.stringify(actual.study)||learned&&JSON.stringify(learned)!==JSON.stringify(actual.learning))throw Error('Étude écrite mais relecture non confirmée. Aucune étape suivante lancée.');
 return next;
}

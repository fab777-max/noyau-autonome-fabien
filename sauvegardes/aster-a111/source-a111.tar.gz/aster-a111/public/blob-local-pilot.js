// A80.1: bounded resident probes using the existing controller and engine lock.
import {ENGINE_PROTOCOL,diagnosticCode,safeEvent,createLlmTrace,readLlmTrace,readLlmTraceHistory} from '/blob-llm-evidence.js?v=A91';
import {PILOT_RELEASE,PILOT_KEY,PROFILES,PROBES,PLAN_SIZE,loadOptions,probePass,signature,actualOK,profileOK,isCycle,runtimeReceipt,copyActual,nextTrial,planProgress,studyAssessment} from '/blob-pilot-plan.js?v=A83';
export {PILOT_RELEASE,PILOT_KEY,PROFILES,PROBES,loadOptions,probePass,nextTrial};
const clone=v=>JSON.parse(JSON.stringify(v));
export function freshPilot(model,revision=''){return {release:PILOT_RELEASE,model,revision,enabled:false,selected:null,inflight:null,receipts:[],previousReceipts:[],sessions:[],notice:'Parcours local non lancé. Aucun score mesuré sur cet appareil.'};}
export const technicalIncident=r=>r.outcome==='INTERRUPTED'||(r.outcome==='FAIL'&&r.reason!=='PROBE_OUTPUT_REJECTED');
const blockedTrial=state=>state.receipts.find(technicalIncident);
function incidentNotice(row){
 const names={WORKER_ERROR:'le moteur a été interrompu',WORKER_MESSAGE_ERROR:'communication avec le moteur interrompue',WORKER_HANDSHAKE_TIMEOUT:'le moteur ne répond pas',PROBE_TIMEOUT:'délai dépassé',PROFILE_UNVERIFIED:'identité ou réglage du modèle non confirmé',UNFINISHED_CHECKPOINT:'essai précédent interrompu, cause inconnue',MODEL_ERROR:'erreur du moteur',CHECKPOINT_STORAGE_FAILED:'sauvegarde du point de reprise non confirmée'};
 return 'Arrêt technique sur '+row.caseId+(row.failedStage==='LOAD'?' pendant le chargement':'')+' : '+(names[row.reason]||row.reason)+'. '+(row.diagnostic&&row.diagnostic!=='UNKNOWN'?'Diagnostic : '+row.diagnostic+'. ':'')+'Réessaie cette étape uniquement après avoir corrigé la cause. Les résultats précédents sont conservés.';
}
function qualified(state,id){const rs=state.receipts.filter(r=>r.profile===id);return !rs.some(r=>['FAIL','INTERRUPTED'].includes(r.outcome))&&PROBES.every(c=>rs.some(r=>r.caseId===c.id&&r.outcome==='PASS'&&profileOK(id,r.actual)&&runtimeReceipt(r.actual,r.pacing)&&(!c.minInputTokens||r.maxInputTokens>=c.minInputTokens)&&(!c.pipeline||(r.cycleReadback===true&&r.reusedFinal===true))))&&new Set(rs.filter(r=>r.outcome==='PASS').map(r=>signature(r.actual))).size===1;}
export function chooseProfile(state){return PROFILES.filter(p=>qualified(state,p.id)).sort((a,b)=>{const time=id=>state.receipts.filter(r=>r.profile===id&&r.outcome==='PASS').reduce((s,r)=>s+r.elapsedMs,0);return time(a.id)-time(b.id);})[0]?.id||null;}
// Only called with the shared engine lock held: a leftover checkpoint then has no live owner.
// Do not diagnose RAM from a reload. Quarantine the profile without erasing previous receipts.
export function recoverInterrupted(saved,at=Date.now()){
 const next=clone(saved),trial=next.inflight;if(!trial)return next;
 if(!PROFILES.some(p=>p.id===trial.profile)||!PROBES.some(p=>p.id===trial.caseId)||!Number.isFinite(trial.started))throw Error('PILOT_CHECKPOINT_INVALID');
 if(!next.receipts.some(r=>r.profile===trial.profile&&r.caseId===trial.caseId))next.receipts.push({profile:trial.profile,caseId:trial.caseId,outcome:'INTERRUPTED',reason:'UNFINISHED_CHECKPOINT',cause:'UNKNOWN',elapsedMs:0,durationKnown:false,started:trial.started,at,testKind:'RECOVERY_OBSERVATION',personalTextStored:false});
 next.inflight=null;next.selected=chooseProfile(next);next.notice=incidentNotice({caseId:trial.caseId,reason:'UNFINISHED_CHECKPOINT'});return next;
}
export function pilotReport(state){
 const number=v=>Number.isFinite(v)?v:null;
 const reasons=new Set(['SYNTHETIC_ORACLE','SAME_EFFECTIVE_PROFILE','PROFILE_UNVERIFIED','PROBE_OUTPUT_REJECTED','MODEL_ERROR','PROBE_TIMEOUT','WORKER_HANDSHAKE_TIMEOUT','WORKER_ERROR','WORKER_MESSAGE_ERROR','UNKNOWN_INTERRUPTION','UNFINISHED_CHECKPOINT','PACING_UNVERIFIED','CONTEXT_TOO_SMALL','CHECKPOINT_REJECTED','CHECKPOINT_STORAGE_FAILED','SESSION_BUDGET']);
 return {schema:'noyau-local-pilot-report-v1',controller:'A91',assessment:{...studyAssessment(state),previousTechnicalFailures:(state.previousReceipts||[]).length},sessions:(state.sessions||[]).slice(-12),maxTrials:PLAN_SIZE,phase:planProgress(state).phase,model:state.model,revision:state.revision,selected:state.selected,manualOriginal:state.manualOriginal===true,generalQualityCertified:false,weightTraining:false,personalTextIncluded:false,previousReceipts:(state.previousReceipts||[]).map(r=>({profile:r.profile,caseId:r.caseId,outcome:r.outcome,reason:reasons.has(r.reason)?r.reason:'UNSPECIFIED',at:number(r.at),retriedAt:number(r.retriedAt),diagnostic:safeEvent('NATIVE_DIAGNOSTIC',{code:r.diagnostic})?.code||null,failedStage:['LOAD','PROBE'].includes(r.failedStage)?r.failedStage:null})),technicalTrace:readLlmTrace(),previousTechnicalTraces:readLlmTraceHistory(),receipts:state.receipts.map(r=>({profile:r.profile,caseId:r.caseId,outcome:r.outcome,reason:reasons.has(r.reason)?r.reason:'UNSPECIFIED',diagnostic:safeEvent('NATIVE_DIAGNOSTIC',{code:r.diagnostic})?.code||null,failureClass:r.outcome!=='FAIL'?null:r.reason==='PROBE_OUTPUT_REJECTED'?'CONTENT':String(r.reason||'').includes('CHECKPOINT')?'STORAGE':'EXECUTION',failedStage:['LOAD','PROBE'].includes(r.failedStage)?r.failedStage:null,reusedEngine:r.reusedEngine===true,outputTokens:number(r.outputTokens),elapsedMs:r.elapsedUnknown||r.durationKnown===false?null:number(r.elapsedMs),loadMs:number(r.loadMs),generationMs:number(r.generationMs),maxInputTokens:number(r.maxInputTokens),pacing:runtimeReceipt(r.actual,r.pacing),cycleReadback:r.cycleReadback===true,reusedFinal:r.reusedFinal===true,at:number(r.at),actual:actualOK(r.actual)?copyActual(r.actual):null}))};
}
// Shared by manual chat and calibration. Automatic trials require Web Locks.
export async function reserveEngine(locks=globalThis.navigator?.locks){if(!locks?.request)return ()=>{};return new Promise((resolve,reject)=>{locks.request('noyau-local-compute-v1',{ifAvailable:true},lock=>{if(!lock){resolve(null);return;}return new Promise(done=>resolve(done));}).catch(reject);});}
export function createLocalPilot({model,revision='',read,write,canRun,render,pauseWork,resumeWork,budgetMs=()=>300000,makeWorker=()=>new Worker('/blob-assistant-worker.js?v=A111',{type:'module'}),now=()=>Date.now(),locks=globalThis.navigator?.locks}){
 let state=freshPilot(model,revision),initialized=false,initializing=null,flight=null,worker=null,timer=null,settle=null,unlock=null,nextAt=0,serial=0,resident=null,trace=null,beat=null,pauseReason=null;
 const releaseWorker=()=>{clearInterval(beat);beat=null;worker?.terminate();worker=null;resident=null;};
 const show=()=>render({...clone(state),active:!!flight,nextAt,assessment:studyAssessment(state),plan:planProgress(state),retryable:!!state.inflight||!!blockedTrial(state)});
 function restore(saved){
  if(saved==null)return freshPilot(model,revision);
  if(saved.release!==PILOT_RELEASE||saved.model!==model||saved.revision!==revision||!Array.isArray(saved.receipts)||saved.receipts.length>32)throw Error('PILOT_STATE_INCOMPATIBLE');
  if(saved.sessions!==undefined&&(!Array.isArray(saved.sessions)||saved.sessions.length>12||saved.sessions.some(s=>!Number.isFinite(s.started)||!Number.isFinite(s.finished)||s.finished<s.started||!Number.isInteger(s.trials)||s.trials<0||s.trials>PLAN_SIZE)))throw Error('PILOT_SESSIONS_INVALID');
  if(saved.previousReceipts!==undefined&&(!Array.isArray(saved.previousReceipts)||saved.previousReceipts.some(r=>!PROFILES.some(p=>p.id===r?.profile)||!PROBES.some(p=>p.id===r.caseId)||!technicalIncident(r)||!Number.isFinite(r.retriedAt))))throw Error('PILOT_HISTORY_INVALID');
  const seen=new Set();
  for(const r of saved.receipts){const key=r.profile+'/'+r.caseId;if(!PROFILES.some(p=>p.id===r.profile)||!PROBES.some(p=>p.id===r.caseId)||!['PASS','FAIL','EQUIVALENT','INTERRUPTED'].includes(r.outcome)||!Number.isFinite(r.elapsedMs)||r.elapsedMs<0||seen.has(key)||(r.outcome==='PASS'&&!actualOK(r.actual)))throw Error('PILOT_RECEIPT_INVALID');seen.add(key);}
  const result={...freshPilot(model,revision),...clone(saved),enabled:false};result.selected=chooseProfile(result);return result;
 }
 // Call only while holding the engine lock. A receipt is not promoted before readback.
 async function save(next){const token=serial,snapshot={...clone(next),enabled:false};await write(snapshot);if(JSON.stringify(await read())!==JSON.stringify(snapshot))throw Error('PILOT_STORAGE_READBACK');state={...next,enabled:next.enabled&&token===serial};}
 async function init(){if(initialized)return;if(initializing)return initializing;initializing=(async()=>{state=restore(await read());initialized=true;show();})().finally(()=>{initializing=null;});return initializing;}
 function stop(reason='PAUSED'){pauseReason=reason;state.enabled=false;serial++;settle?.({outcome:'PAUSED',reason});state.notice='Calibration en pause. Résultats conservés ; reprise par le bouton.';show();return flight;}
 async function enable({retry=false}={}){if(flight)return flight;const token=serial;await init();if(token!==serial)return;if(!locks?.request){state.notice='Essais automatiques indisponibles : verrou inter-onglets absent. Dialogue manuel conservé.';show();return;}state.enabled=true;state.notice='Essais armés : un seul calcul, page visible, priorité à tes demandes.';show();return tick(retry);}
 async function runTrial(trial,deadline){
  const started=now(),reuse=!!(worker&&resident?.profile===trial.profile),nonce=String(serial)+':'+trial.caseId+':'+started;
  if(!reuse){releaseWorker();try{worker=makeWorker();}catch{trace?.mark('FAILED',{code:'WORKER_FAILURE',outcome:'FAIL'});return {outcome:'FAIL',reason:'WORKER_ERROR',failedStage:'LOAD',elapsedMs:Math.max(0,now()-started)};}trace?.mark('WORKER_CREATED');}
  return new Promise(resolve=>{
   let ended=false,ready=reuse,actual=reuse?copyActual(resident.actual):null,loadMs=reuse?0:null,maxInputTokens=0,checkpointWrites=Promise.resolve(),checkpointCount=0,lastCheckpoint=null,ack=false;
   const finish=r=>{if(ended)return;ended=true;clearTimeout(timer);clearInterval(beat);beat=null;settle=null;if(r.outcome!=='PASS')trace?.mark(r.outcome==='PAUSED'?'PAUSED':'FAILED',{outcome:r.outcome});checkpointWrites.catch(()=>{}).then(()=>resolve({...r,actual,loadMs,maxInputTokens,reusedEngine:reuse,elapsedMs:Math.max(0,now()-started)}));};settle=finish;
   const probe=()=>{arm(120000,'PROBE_TIMEOUT','PROBE');trace?.mark('PROBE_STARTED');worker.postMessage({type:'PROBE',caseId:trial.caseId});};
   const arm=(ms,reason,failedStage)=>{clearTimeout(timer);const remaining=Math.max(0,deadline-now()),limited=remaining<=ms;timer=setTimeout(()=>finish({outcome:limited?'PAUSED':'FAIL',reason:limited?'SESSION_BUDGET':reason,failedStage}),Math.min(ms,remaining));};
   arm(reuse?120000:20000,reuse?'PROBE_TIMEOUT':'WORKER_HANDSHAKE_TIMEOUT',reuse?'PROBE':'LOAD');
   let lastNotice='Attente du moteur';
   beat=setInterval(()=>{if(!ended){state.notice='Micro-test '+trial.caseId+' · '+Math.floor((now()-started)/1000)+' s écoulées · '+lastNotice;show();}},1000);
   worker.onerror=()=>finish({outcome:'FAIL',reason:'WORKER_ERROR'});worker.onmessageerror=()=>finish({outcome:'FAIL',reason:'WORKER_MESSAGE_ERROR'});
   worker.onmessage=({data:p})=>{
    if(ended||!p)return;
    if(p.type==='HELLO_ACK'){
     if(reuse||ack||p.nonce!==nonce)return;
     if(p.protocol!==ENGINE_PROTOCOL||p.model!==model||p.revision!==revision){finish({outcome:'FAIL',reason:'PROFILE_UNVERIFIED'});return;}
     ack=true;trace?.mark('WORKER_ACK');arm(480000,'PROBE_TIMEOUT','LOAD');
     trace?.mark('LOAD_SENT');worker.postMessage({type:'LOAD',profile:trial.profile,probe:true});
    }else if(p.type==='TECHNICAL'){
     trace?.mark(p.event,p);
    }else if(p.type==='READY'){
     if(ready)return;
     if(p.profile!==trial.profile||p.model!==model||p.revision!==revision||!profileOK(trial.profile,p.actual)){finish({outcome:'FAIL',reason:'PROFILE_UNVERIFIED'});return;}
     actual=copyActual(p.actual);loadMs=Number.isFinite(p.loadWallMs)?p.loadWallMs:null;ready=true;resident={profile:trial.profile,actual:copyActual(actual)};trace?.mark('MODEL_READY');
     const same=state.receipts.find(r=>r.profile!==trial.profile&&qualified(state,r.profile)&&signature(r.actual)===signature(actual));
     if(same){finish({outcome:'EQUIVALENT',reason:'SAME_EFFECTIVE_PROFILE',equivalentTo:same.profile});return;}
     probe();
    }else if(p.type==='CONTEXT'){
     if(ready&&Number.isInteger(p.inputTokens)&&p.inputTokens>0&&p.inputTokens<=2048)maxInputTokens=Math.max(maxInputTokens,p.inputTokens);
    }else if(p.type==='CHECKPOINT'){
     // Only synthetic plan cases can write here. Never the personal dialogue store.
     let size=Infinity;try{size=JSON.stringify(p.checkpoint).length;}catch{}
     if(!ready||!isCycle(trial.caseId)||!Number.isInteger(p.id)||p.id<1||++checkpointCount>4||size>16000||typeof p.checkpoint?.answer?.identity!=='string'){finish({outcome:'FAIL',reason:'CHECKPOINT_REJECTED'});return;}
     checkpointWrites=checkpointWrites.then(async()=>{
      if(ended)return;const value=clone(p.checkpoint);
      await save({...state,inflight:{...state.inflight,checkpoint:value}});
      const durable=await read();
      if(JSON.stringify(durable?.inflight?.checkpoint)!==JSON.stringify(value))throw Error('PILOT_CHECKPOINT_READBACK');
      lastCheckpoint=durable.inflight.checkpoint;
      if(!ended)worker?.postMessage({type:'CHECKPOINT_ACK',id:p.id,ok:true,checkpoint:lastCheckpoint});
     }).catch(()=>{if(!ended){worker?.postMessage({type:'CHECKPOINT_ACK',id:p.id,ok:false});finish({outcome:'FAIL',reason:'CHECKPOINT_STORAGE_FAILED'});}});
    }else if(p.type==='PROBE_RESULT'){
     const test=PROBES.find(c=>c.id===trial.caseId),readyOnly=test?.readyOnly===true,pacing=readyOnly?{runtime:'READY_ONLY',measured:false,sliceMs:actual?.sliceMs||0,pauseMs:actual?.pauseMs||0}:runtimeReceipt(actual,p.runtimeStats);
     const cycleOK=!isCycle(trial.caseId)||(p.cycleReadback===true&&p.reusedFinal===true&&lastCheckpoint?.answer?.final===p.answer);
     const contextOK=!test?.minInputTokens||maxInputTokens>=test.minInputTokens;
     const tokenOK=!test?.mechanical||(Number.isInteger(p.outputTokens)&&p.outputTokens>=1&&p.outputTokens<=test.maxTokens);
     const pass=ready&&cycleOK&&contextOK&&tokenOK&&!!pacing&&p.caseId===trial.caseId&&p.model===model&&p.revision===revision&&probePass(trial.caseId,p.answer);
     finish({outcome:pass?'PASS':'FAIL',reason:pass?'SYNTHETIC_ORACLE':!ready||p.caseId!==trial.caseId||p.model!==model||p.revision!==revision?'PROFILE_UNVERIFIED':!cycleOK?'CHECKPOINT_REJECTED':!pacing?'PACING_UNVERIFIED':!contextOK?'CONTEXT_TOO_SMALL':'PROBE_OUTPUT_REJECTED',outputTokens:Number.isInteger(p.outputTokens)?p.outputTokens:null,pacing,...(isCycle(trial.caseId)?{cycleReadback:pass,reusedFinal:pass}:{}),generationMs:Number.isFinite(p.elapsedMs)&&p.elapsedMs>=0?p.elapsedMs:null});
    }else if(p.type==='ERROR')finish({outcome:'FAIL',reason:'MODEL_ERROR',diagnostic:diagnosticCode(p.message),failedStage:['LOAD','PROBE'].includes(p.stage)?p.stage:'UNKNOWN'});
    else if(p.type==='STAGE'){lastNotice=String(p.label||'calcul').slice(0,160);state.notice='Essai '+trial.profile+' / '+trial.caseId+' · '+lastNotice;show();}
   };
   if(reuse)probe();else worker.postMessage({type:'HELLO',nonce});
  });
 }
 async function tick(retry=false){
  await init();if(flight||!state.enabled||!locks?.request)return;
  if(now()<nextAt){state.enabled=false;state.notice='Moteur au repos : attends '+Math.ceil((nextAt-now())/1000)+' secondes, puis appuie une fois sur Lancer / reprendre. Modèle sélectionné conservé.';show();return;}
  if(!canRun()){state.enabled=false;state.notice='Lancement indisponible : garde la page visible et vérifie les fichiers du modèle sélectionné. Aucun changement de modèle nécessaire.';show();return;}
  const token=serial,sessionStarted=now(),limit=Number(budgetMs()),deadline=sessionStarted+Math.max(60000,Math.min(7200000,Number.isFinite(limit)?limit:300000));
  flight=(async()=>{let pausedWork=false,attempted=false;
   try{
    unlock=await reserveEngine(locks);if(!unlock){state.notice='Un autre onglet utilise le moteur ; essais différés.';return;}
    if(token!==serial||!canRun())return;
    const saved=restore(await read()),interrupted=!!saved.inflight;
    state={...recoverInterrupted(saved,now()),enabled:!interrupted,manualOriginal:false};
    if(retry){
     const incident=blockedTrial(state);
     if(!incident){state.enabled=false;state.notice='Aucun arrêt technique à réessayer. Les résultats restent conservés.';return;}
     // Explicit user retry only. Move the failed receipt to history before allocating anything.
     state={...state,enabled:true,selected:null,receipts:state.receipts.filter(r=>r!==incident),previousReceipts:[...(state.previousReceipts||[]),{...incident,retriedAt:now()}]};
     await save(state);
    }else if(interrupted){state.notice=incidentNotice(blockedTrial(state)||{caseId:saved.inflight.caseId,reason:'UNFINISHED_CHECKPOINT'});await save(state);return;}
    if(token!==serial||!canRun()){state.enabled=false;return;}
    if(!nextTrial(state)){state.enabled=false;state.notice=blockedTrial(state)?incidentNotice(blockedTrial(state)):'Parcours terminé ou limité par les réponses du modèle. Bilan conservé ; aucun calcul répété.';await save(state);return;}
    attempted=true;trace=createLlmTrace();trace.mark('ATTEMPT_STARTED');
    let steps=0;
    while(state.enabled&&token===serial&&canRun()&&steps<PLAN_SIZE&&now()<deadline){
     const trial=nextTrial(state);if(!trial)break;
     await save({...state,inflight:{...trial,started:now()}});
     let result;
     if(token!==serial||!canRun())result={outcome:'PAUSED',reason:'USER_PRIORITY'};
     else{if(!pausedWork){pauseWork();pausedWork=true;}result=await runTrial(trial,deadline);}
     const mayContinue=result.outcome==='PASS'||(result.outcome==='FAIL'&&result.reason==='PROBE_OUTPUT_REJECTED');
     if(!mayContinue)releaseWorker();
     const next={...state,enabled:state.enabled&&token===serial&&mayContinue,inflight:null,receipts:[...state.receipts]};
     if(result.outcome!=='PAUSED')next.receipts.push({...trial,...result,at:now(),testKind:'LOCAL_SYNTHETIC',personalTextStored:false});
     next.selected=chooseProfile(next);
     next.notice=result.outcome==='PASS'?'Contrôle '+trial.caseId+' validé ; preuve sauvegardée.':result.reason==='PROBE_OUTPUT_REJECTED'?'Réponse incorrecte sur '+trial.caseId+' : aucun succès accordé, prochain contrôle distinct.':result.outcome==='PAUSED'?'Essais en pause ; acquis conservés.':'Arrêt technique à '+trial.caseId+' · '+result.reason+' · exporte le bilan.';
     await save(next);steps++;if(result.outcome==='PASS')trace?.mark('PROBE_SAVED',{outcome:'PASS',count:steps});show();
     if(state.enabled&&nextTrial(state))await new Promise(resolve=>setTimeout(resolve,steps%3===0?1000:100));
    }
    const remaining=nextTrial(state);state.enabled=false;
    state.sessions=[...(state.sessions||[]),{started:sessionStarted,finished:now(),trials:steps,budgetMs:deadline-sessionStarted,complete:!!state.selected,stopReason:token!==serial?'USER_OR_VISIBILITY':now()>=deadline?'BUDGET':state.selected?'COMPLETE':remaining?'UNAVAILABLE':'GATE_OR_INCIDENT'}].slice(-12);
    if(!remaining){state.notice=blockedTrial(state)?incidentNotice(blockedTrial(state)):state.selected?'Parcours synthétique terminé · '+state.selected+' retenu. Conversation libre et réouverture iPhone restent à tester.':'Campagne arrêtée ou terminée sans profil entièrement validé. Les preuves et le diagnostic sont conservés ; pas de répétition automatique.';}
    else if(token===serial)state.notice='Campagne mise en pause au budget ou à une indisponibilité ; contrôles terminés conservés.';
    if(token!==serial)state.notice=pauseReason==='HIDDEN'?'Page passée hors écran : essais en pause, résultats conservés. Reviens dans Noyau et utilise Lancer / reprendre.':'Essais mis en pause à ta demande. Résultats conservés.';
    await save(state);
   }catch{state.enabled=false;state.notice='Calibration arrêtée : stockage ou exécution non confirmé. Données antérieures conservées, reprise manuelle.';trace?.mark('FAILED',{code:'STORAGE_FAILURE',outcome:'FAIL'});}
   finally{clearTimeout(timer);settle=null;releaseWorker();trace?.mark('RELEASED');unlock?.();unlock=null;if(attempted)nextAt=now()+30000;flight=null;if(pausedWork)resumeWork();show();}
  })();return flight;
 }
 async function reset(){await stop('MANUAL_ORIGINAL');await init();if(!locks?.request)throw Error('PILOT_LOCK_REQUIRED');const release=await reserveEngine(locks);if(!release)throw Error('PILOT_ENGINE_BUSY');try{const saved=recoverInterrupted(restore(await read()),now());await save({...saved,enabled:false,inflight:null,manualOriginal:true,notice:'Réglage initial rétabli. Tous les résultats des essais sont conservés.'});}finally{release();show();}}
 return {init,tick,enable,retry:()=>enable({retry:true}),stop,reset,active:()=>!!flight,profile:()=>state.selected||PROFILES[0].id,snapshot:()=>clone(state),report:()=>pilotReport(state)};
}
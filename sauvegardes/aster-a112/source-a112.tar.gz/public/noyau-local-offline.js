(()=>{
 const REVISION='A112-local-only-1',get=id=>document.getElementById(id),offline=get('offline'),maintenance=get('maintenance'),retry=get('retryOffline'),home=get('homeMode');
 if(home)home.textContent=navigator.standalone===true||(typeof matchMedia==='function'&&matchMedia('(display-mode: standalone)').matches)
  ?'Aster est ouvert depuis son icône. Les vérifications ci-dessous concernent cet espace local.'
  :'Aster est ouvert dans un navigateur. Sur iPhone, utilise Safari pour ajouter son icône à l’écran d’accueil.';
 if(!offline||!maintenance)return;
 if(!('serviceWorker' in navigator)){offline.textContent='Installation hors ligne indisponible dans ce navigateur. Ouvre Aster dans Safari.';maintenance.textContent='Données conservées.';return;}
 const sent=new WeakSet();let registering=false,preparing=false,activeWorker=null,timer=null,generation=0;
 const resetTimer=()=>{clearTimeout(timer);timer=null;};
 function failed(message){
  resetTimer();generation++;registering=false;preparing=false;
  if(activeWorker)sent.delete(activeWorker);
  offline.textContent=message;maintenance.textContent='Données et fichiers déjà présents conservés.';
  if(retry){retry.hidden=false;retry.disabled=false;}
 }
 function watch(){resetTimer();timer=setTimeout(()=>failed('Préparation hors ligne trop longue ou interrompue. Reprends-la manuellement avec une connexion.'),60000);}
 function prepare(worker){
  if(!worker||sent.has(worker))return;
  sent.add(worker);activeWorker=worker;registering=false;preparing=true;
  if(retry)retry.disabled=true;
  offline.textContent='Préparation de l’interface hors ligne…';watch();
  try{worker.postMessage({type:'CACHE_SHELL',url:new URL('/',location.href).href,revision:REVISION});}
  catch{failed('Préparation hors ligne interrompue. Reprends-la manuellement.');}
 }
 async function connect(){
  if(registering||preparing)return;
  const own=++generation;registering=true;if(retry)retry.disabled=true;
  offline.textContent='Activation de la copie hors ligne…';watch();
  try{
   const registration=await navigator.serviceWorker.register('/blob-sw.js',{scope:'/',updateViaCache:'none'});
   if(own!==generation)return;
   let worker=navigator.serviceWorker.controller||registration.active;
   if(!worker){const ready=await navigator.serviceWorker.ready;if(own!==generation)return;worker=navigator.serviceWorker.controller||ready.active;}
   registering=false;
   if(!worker){failed('Activation hors ligne non confirmée. Reprends-la manuellement.');return;}
   prepare(worker);
  }catch{if(own===generation)failed('Installation hors ligne non confirmée. Vérifie la connexion puis reprends-la.');}
 }
 if(retry)retry.onclick=connect;
 navigator.serviceWorker.addEventListener('controllerchange',()=>prepare(navigator.serviceWorker.controller));
 navigator.serviceWorker.addEventListener('message',e=>{
  const p=e.data;
  if(p?.type==='SHELL_READY'&&p.ok&&/^A\d+-local-only-\d+$/.test(p.revision)&&p.revision!==REVISION){
   const current=Number(REVISION.match(/^A(\d+)/)[1]),incoming=Number(p.revision.match(/^A(\d+)/)[1]);
   if(incoming>current){resetTimer();preparing=false;registering=false;if(retry)retry.hidden=true;maintenance.textContent='Nouvelle interface prête. Termine ou mets en pause ton opération, puis ouvre la mise à jour. Modèles et mémoire conservés.';const button=get('refreshApp');if(button){button.hidden=false;button.onclick=()=>location.reload();}}
   return;
  }
  if(p?.revision!==REVISION)return;
  if(p.type==='SHELL_PROGRESS'&&Number.isInteger(p.completed)&&Number.isInteger(p.total)&&p.total>0&&p.completed>=0&&p.completed<=p.total){
   const transfer=Number.isFinite(p.receivedBytes)&&p.receivedBytes>0?' Fichier en cours : '+(p.receivedBytes/1000000).toFixed(1)+' Mo reçus.':'';
   offline.textContent='Interface hors ligne : '+p.completed+' / '+p.total+' fichiers présents.'+transfer+' Le modèle se prépare séparément.';watch();
  }
  if(p.type==='SHELL_READY'){
   if(p.ok){resetTimer();preparing=false;registering=false;if(retry){retry.hidden=true;retry.disabled=false;}offline.textContent='Interface locale enregistrée. Le modèle texte doit aussi être présent ; la création d’images connectée exige Internet.';}
   else failed('Copie hors ligne interrompue ou incomplète. Reprends-la avec une connexion ; les fichiers déjà présents seront réutilisés.');
  }
  if(p.type==='MAINTENANCE_DONE')maintenance.textContent=p.status==='DONE'?(p.removed?p.removed+' ancienne(s) copie(s) de l’interface supprimée(s).':'Interface à jour, rien à supprimer.')+' Modèles et mémoire conservés.':p.status==='OTHER_TAB'?'Nettoyage différé : ferme les autres onglets Aster puis rouvre cette page.':'Nettoyage différé : copie locale non confirmée.';
 });
 connect();
})();

// A95: atomic local recovery with a new workshop revision. Model caches are never touched.
import {learningState, LEARNING_KEY} from '/noyau-learning.js?v=A91';
import {WORKSHOP_KEY,workshopState} from '/noyau-workshop-core.js?v=A105';
import {PROJECT_KEY,projectState,projectDrafts} from '/noyau-project-core.js?v=A100';
import {DOCUMENTS_KEY,documentsState,documentDraft} from '/noyau-documents-core.js?v=A100';
import {RESEARCH_KEY,researchState,researchDrafts} from '/noyau-research-core.js?v=A100';
import {STUDY_KEY,studyState} from '/aster-study-core.js?v=A112';
import {composerDraft} from '/aster-request-core.js?v=A110';
import {DIALOGUE_REVISION_KEY,dialogueRevision} from '/noyau-dialogue-store.js?v=A112';
import {personalState} from '/blob-personal-core.js?v=A65.1';
import {HOME_DRAFT_KEY,homeDraft,validateCorrections} from '/aster-conversation-learning.js?v=A112';
import {validateWorkJob} from '/aster-work-budget.js?v=A112';
export const BACKUP_SCHEMA = 'noyau-local-full-backup-A93';
export const ROLLBACK_KEY = 'noyau.restore-previous.v1';
export const RECEIPT_KEY = 'noyau.restore-receipt.v1';
export const MAX_BACKUP_BYTES = 40 * 1024 * 1024;
export const STORES = ['settings', 'strategies', 'strategy_archive', 'proofs', 'run_summaries'];
const KEYS = {strategies:'key', strategy_archive:'key', proofs:'proofHash', run_summaries:'runId'};
const LIMITS = {strategies:128, strategy_archive:128, proofs:32, run_summaries:64};
const internal = key => [ROLLBACK_KEY, RECEIPT_KEY].includes(key);
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const bytes = value => new TextEncoder().encode(JSON.stringify(value)).length;
function jsonSafe(value, depth = 0) {
  if (depth > 35) throw Error('Sauvegarde trop imbriquée.');
  if (value === null || ['string','boolean'].includes(typeof value)) return;
  if (typeof value === 'number' && Number.isFinite(value)) return;
  if (Array.isArray(value)) { for (const row of value) jsonSafe(row, depth + 1); return; }
  if (!plain(value)) throw Error('Valeur de sauvegarde invalide.');
  for (const [key, row] of Object.entries(value)) {
    if (['__proto__','constructor','prototype'].includes(key)) throw Error('Clé de sauvegarde interdite.');
    jsonSafe(row, depth + 1);
  }
}
export function validateBackup(input) {
  if (typeof input === 'string' && new TextEncoder().encode(input).length > MAX_BACKUP_BYTES) throw Error('Sauvegarde supérieure à 40 Mio.');
  const data = typeof input === 'string' ? JSON.parse(input) : structuredClone(input);
  jsonSafe(data);
  if (!plain(data) || !['noyau-local-full-backup-A92', BACKUP_SCHEMA].includes(data.schema) || data.weightsIncluded !== false || !plain(data.settings)) throw Error('Choisis une sauvegarde complète Noyau compatible.');
  if (bytes(data) > MAX_BACKUP_BYTES || Object.keys(data.settings).length > 1000) throw Error('Sauvegarde trop volumineuse.');
  for (const key of Object.keys(data.settings)) {
    if (!key || key.length > 240 || internal(key)) throw Error('Réglage de sauvegarde invalide.');
  }
  const chat = data.settings['noyauStandaloneDialogue-v1'];
  homeDraft(data.settings[HOME_DRAFT_KEY]);
  dialogueRevision(data.settings[DIALOGUE_REVISION_KEY]);
  personalState(data.settings['assistantPersonal-v1']);
  if (chat != null && (!Array.isArray(chat) || chat.length > 50000 || chat.some(row => !plain(row) || !['user','assistant'].includes(row.role) || typeof row.content !== 'string' || row.content.length > 12000))) throw Error('Dialogue incompatible dans la sauvegarde.');
  validateCorrections(chat);
  learningState(data.settings[LEARNING_KEY]);
  studyState(data.settings[STUDY_KEY]);
  workshopState(data.settings[WORKSHOP_KEY]);
  projectState(data.settings[PROJECT_KEY]);
  projectDrafts(data.preferences?.projectDrafts);
  documentsState(data.settings[DOCUMENTS_KEY]);
  documentDraft(data.preferences?.documentDraft);
  researchState(data.settings[RESEARCH_KEY]);
  researchDrafts(data.preferences?.researchDrafts);
  composerDraft(data.preferences?.composerDraft);
  const archived = data.settings['noyauStandalonePendingArchive-v1'];
  if (archived != null && (!Array.isArray(archived) || archived.length > 50 || archived.some(row => !plain(row) || typeof row.text !== 'string' || !row.text.trim() || row.text.length > 4000))) throw Error('Demandes mises de côté incompatibles dans la sauvegarde.');
  const job = data.settings['noyauStandaloneJob-v1'];
  validateWorkJob(job);
  if (job != null && (!plain(job) || typeof job.text !== 'string' || !job.text.trim() || job.text.length > 4000)) throw Error('Demande interrompue incompatible.');
  const mem = data.memory;
  if (!plain(mem) || mem.schema !== 'blob-local-memory-export-v1' || mem.canonicalBrainIncluded !== false || mem.creditsSpendable !== false || !plain(mem.records)) throw Error('Mémoire de sauvegarde incompatible.');
  for (const [name, key] of Object.entries(KEYS)) {
    const rows = mem.records[name], seen = new Set();
    if (!Array.isArray(rows) || rows.length > LIMITS[name]) throw Error('Taille de mémoire invalide : ' + name);
    for (const row of rows) {
      if (!plain(row) || typeof row[key] !== 'string' || !row[key] || row[key].length > 240 || seen.has(row[key]) || bytes(row) > 4096) throw Error('Enregistrement invalide : ' + name);
      seen.add(row[key]);
    }
  }
  if (data.preferences?.modelChoice != null && !['compact','standard'].includes(data.preferences.modelChoice)) throw Error('Modèle sélectionné invalide.');
  // Restored work never becomes armed. Preserve unfinished checkpoints for manual review.
  for (const [key, value] of Object.entries(data.settings)) {
    if (plain(value) && key.startsWith('assistantLocalPilot-')) value.enabled = false;
  }
  return data;
}
// Validate the exact compact UTF-8 content that the browser will offer to save.
// Pretty-printing after validation could push a valid snapshot over the import limit.
export function serializeBackup(input) {
  const text = JSON.stringify(validateBackup(input));
  if (new TextEncoder().encode(text).length > MAX_BACKUP_BYTES) throw Error('Sauvegarde supérieure à 40 Mio. Aucune donnée n’a été supprimée.');
  return text;
}
function collect(tx, done) {
  const result = {settings:{}, records:{}};
  let pending = STORES.length + 1, settingKeys, settingValues;
  const finish = () => {
    if (--pending) return;
    result.settings = Object.fromEntries(settingKeys.map((key,i) => [key,settingValues[i]]).filter(([key]) => !internal(key)));
    done(result);
  };
  tx.objectStore('settings').getAllKeys().onsuccess = e => { settingKeys = e.target.result; finish(); };
  tx.objectStore('settings').getAll().onsuccess = e => { settingValues = e.target.result; finish(); };
  for (const name of Object.keys(KEYS)) tx.objectStore(name).getAll().onsuccess = e => { result.records[name] = e.target.result; finish(); };
}
function envelope(data, preferences = {}) {
  return {schema:BACKUP_SCHEMA, at:new Date().toISOString(), settings:data.settings, preferences,
    memory:{schema:'blob-local-memory-export-v1', databaseVersion:3, canonicalBrainIncluded:false, creditsSpendable:false, records:data.records}, weightsIncluded:false};
}
export function snapshot(db, preferences = {}) {
  return new Promise((resolve,reject) => {
    const tx = db.transaction(STORES,'readonly'); let result;
    collect(tx, data => { result = envelope(data,preferences); });
    tx.oncomplete = () => resolve(result);
    tx.onerror = tx.onabort = () => reject(tx.error || Error('Lecture de sauvegarde interrompue.'));
  });
}
export function previewBackup(data) {
  const p = validateBackup(data);
  return {date:p.at || null, messages:p.settings['noyauStandaloneDialogue-v1']?.length || 0,
    methods:p.settings[LEARNING_KEY]?.lessons?.length || 0, settings:Object.keys(p.settings).length,
    dossiers:p.settings['noyau.workshop.v1']?.dossiers?.length || 0,
    projects:p.settings[PROJECT_KEY]?.projects?.length || 0,
    documents:p.settings[DOCUMENTS_KEY]?.documents?.length || 0,
    research:p.settings[RESEARCH_KEY]?.dossiers?.length || 0,
    studies:p.settings[STUDY_KEY]?.sessions?.length || 0,
    records:Object.values(p.memory.records).reduce((n,rows) => n + rows.length,0), bytes:bytes(p), weightsIncluded:false};
}
export async function restoreBackup(db, input, preferences = {}) {
  const data = validateBackup(input);
  await new Promise((resolve,reject) => {
    const tx = db.transaction(STORES,'readwrite');
    const fail = () => reject(tx.error || Error('Restauration annulée ; données précédentes conservées.'));
    tx.onerror = tx.onabort = fail;
    collect(tx, current => {
      try {
        // Safety copy and replacement commit together, including on quota failure.
        const previous = envelope(current,preferences);
        // Even an old backup or a same-content restore invalidates delayed chat writes.
        const conversationRevision=Math.max(dialogueRevision(data.settings[DIALOGUE_REVISION_KEY]),dialogueRevision(current.settings[DIALOGUE_REVISION_KEY]))+1;
        if(!Number.isSafeInteger(conversationRevision))throw Error('Compteur de conversation incompatible ; aucune donnée remplacée.');
        data.settings[DIALOGUE_REVISION_KEY]=conversationRevision;
        // A delayed BroadcastChannel message must never let an old workshop tab
        // overwrite restored data. Advance even when the backup has no workshop.
        const restoredWorkshop = workshopState(data.settings[WORKSHOP_KEY]);
        const currentRevision = current.settings[WORKSHOP_KEY]?.revision;
        const revision = Math.max(restoredWorkshop.revision,
          Number.isSafeInteger(currentRevision) && currentRevision >= 0 ? currentRevision : 0) + 1;
        if (!Number.isSafeInteger(revision)) throw Error('Compteur de dossiers incompatible ; aucune donnée remplacée.');
        data.settings[WORKSHOP_KEY] = {...restoredWorkshop,revision};
        const restoredProjects=projectState(data.settings[PROJECT_KEY]);
        const currentProjectRevision=current.settings[PROJECT_KEY]?.revision;
        const projectRevision=Math.max(restoredProjects.revision,Number.isSafeInteger(currentProjectRevision)&&currentProjectRevision>=0?currentProjectRevision:0)+1;
        if(!Number.isSafeInteger(projectRevision))throw Error('Compteur de projets incompatible ; aucune donnée remplacée.');
        data.settings[PROJECT_KEY]={...restoredProjects,revision:projectRevision};
        const restoredDocuments=documentsState(data.settings[DOCUMENTS_KEY]);
        const currentDocumentsRevision=current.settings[DOCUMENTS_KEY]?.revision;
        const documentsRevision=Math.max(restoredDocuments.revision,Number.isSafeInteger(currentDocumentsRevision)&&currentDocumentsRevision>=0?currentDocumentsRevision:0)+1;
        if(!Number.isSafeInteger(documentsRevision))throw Error('Compteur de documents incompatible ; aucune donnée remplacée.');
        data.settings[DOCUMENTS_KEY]={...restoredDocuments,revision:documentsRevision};
        const restoredResearch=researchState(data.settings[RESEARCH_KEY]);
        const currentResearchRevision=current.settings[RESEARCH_KEY]?.revision;
        const researchRevision=Math.max(restoredResearch.revision,Number.isSafeInteger(currentResearchRevision)&&currentResearchRevision>=0?currentResearchRevision:0)+1;
        if(!Number.isSafeInteger(researchRevision))throw Error('Compteur de recherche incompatible ; aucune donnée remplacée.');
        data.settings[RESEARCH_KEY]={...restoredResearch,revision:researchRevision};
        const restoredStudy=studyState(data.settings[STUDY_KEY]);
        const studyRevision=Math.max(restoredStudy.revision,current.settings[STUDY_KEY]?.revision||0)+1;
        if(!Number.isSafeInteger(studyRevision))throw Error('Compteur d’étude incompatible ; aucune donnée remplacée.');
        data.settings[STUDY_KEY]={...restoredStudy,revision:studyRevision};
        for (const name of STORES) tx.objectStore(name).clear();
        const settings = tx.objectStore('settings');
        for (const [key,value] of Object.entries(data.settings)) settings.put(value,key);
        for (const [name,rows] of Object.entries(data.memory.records)) if (KEYS[name]) for (const row of rows) tx.objectStore(name).put(row);
        settings.put(previous,ROLLBACK_KEY);
        settings.put({at:new Date().toISOString(), sourceDate:data.at || null, automaticExecution:false},RECEIPT_KEY);
      } catch (error) { tx.abort(); reject(error); }
    });
    tx.oncomplete = resolve;
  });
  const actual = await snapshot(db);
  if (JSON.stringify(actual.settings) !== JSON.stringify(data.settings)) {
    // Object-store key ordering can differ from the uploaded JSON.
    for (const key of new Set([...Object.keys(actual.settings),...Object.keys(data.settings)])) if (JSON.stringify(actual.settings[key]) !== JSON.stringify(data.settings[key])) throw Error('Restauration écrite mais relecture non confirmée ; la copie précédente est conservée.');
  }
  for (const [name,key] of Object.entries(KEYS)) {
    const expected = new Map(data.memory.records[name].map(row => [row[key],row]));
    if (actual.memory.records[name].length !== expected.size || actual.memory.records[name].some(row => JSON.stringify(row) !== JSON.stringify(expected.get(row[key])))) throw Error('Relecture de mémoire non confirmée ; la copie précédente est conservée.');
  }
  return {restored:true, previousPreserved:true, automaticExecution:false, preferences:data.preferences || {}};
}

// A102: conversation first, explicit guidance and preserved drafts.
import {MODEL,MODEL_MODE,cacheReport,storagePlan} from '/blob-assistant-model.js?v=A83';
import {workerModelURL,workerModelOptions,MODEL_CHOICE_KEY} from '/blob-model-choice.js?v=A100';
import {createLocalPilot,PILOT_KEY,reserveEngine} from '/blob-local-pilot.js?v=A91';
import {ENGINE_PROTOCOL,createLlmTrace,readLlmTrace,traceLabel} from '/blob-llm-evidence.js?v=A91';
import {LEARNING_KEY,learningState,retainLesson,recallLessons,recordContextUse} from '/noyau-learning.js?v=A91';
import {GUIDE_ACTIONS,suggestAction,createComposerDraftStore,stageAgentDraft,appendGuidance} from '/aster-request-core.js?v=A110';
import {DIALOGUE_LIMITS,readLocalState,commitLocalState,reserveDialogueAnswer,dialogueRows} from '/noyau-dialogue-store.js?v=A112';
const $=id=>document.getElementById(id),memory=window.BlobLocalMemory;
let maintenanceActive=false,db=null,complete=false,worker=null,resident=null,idleTimer=null,busy=false,serial=0,unlock=null,timer=null,trace=null,dialogue=[],job=null,learning=null;
const CHAT='noyauStandaloneDialogue-v1';
let archived=[],dossierCount=0,localRevision=0;
let composerStore=null,unsavedComposer=false;
const activity=detail=>{if(typeof CustomEvent==='function')document.dispatchEvent(new CustomEvent('noyau-local-activity',{detail}));};
const status=text=>{$('state').textContent=text;activity({phase:text,active:busy||pilot.active()});};
const read=k=>memory.setting(db,k);
async function write(k,v){await memory.setting(db,k,v);if(JSON.stringify(await read(k))!==JSON.stringify(v))throw Error('STORAGE_READBACK');}
function acceptLocal(s){dialogue=s.dialogue;job=s.job;archived=s.archive;learning=s.learning;localRevision=s.revision;}
async function commitConversation(transform,token=serial){
 const s=await commitLocalState(db,localRevision,current=>{if(token!==serial)throw Error('PAUSED');return transform(current);});
 if(token===serial)acceptLocal(s);return s;
}
async function commitAnswer(answer,memoryIds,token){
 const text=job.text;
 return commitConversation(current=>{
  if(current.job?.text!==text)throw Error('Demande modifiée. Aucune réponse n’a remplacé les données.');
  return {dialogue:[...current.dialogue,{role:'user',content:text},{role:'assistant',content:answer,memoryIds,savedAt:new Date().toISOString()}],job:null,learning:recordContextUse(current.learning,memoryIds)};
 },token);
}
function technical(){ $('trace').textContent=traceLabel(readLlmTrace()); }
function controls(){
 const occupied=busy||pilot.active();
 if(typeof CustomEvent==='function')document.dispatchEvent(new CustomEvent('noyau-workspace-state',{detail:{busy:occupied}}));
 for(const id of ['install','ask','switch','learnSave','refreshApp'])$(id).disabled=!db||occupied;
 $('question').disabled=!db||occupied;
 $('allowFullTransfer').disabled=!db||occupied;
 // Navigation guidance remains usable without downloading a model.
 $('stop').disabled=!occupied&&!resident;$('stop').hidden=!occupied&&!resident;
 $('resume').hidden=!job?.text;$('resume').disabled=!db||occupied||!job?.text||!complete;
 $('pendingNotice').hidden=!job?.text;
 $('pendingNotice').textContent=job?.text?'Demande interrompue conservée. Reprends-la, ou envoie un autre message : la précédente restera dans les demandes mises de côté.':'';
}
async function saveNewJob(next,token){
 await commitConversation(current=>{
  const previous=current.job,history=current.archive;
  reserveDialogueAnswer(current.dialogue,next.text);
  if(previous?.text&&history.length>=50)throw Error('50 demandes mises de côté. Reprends la demande en cours et garde une sauvegarde avant de poursuivre.');
  return{archive:previous?.text?[...history,{...previous,archivedAt:new Date().toISOString()}]:history,job:next};
 },token);
 if(token===serial)renderContinuity();
}
function renderContinuity(){
 const at=dialogue.at(-1)?.savedAt;
 $('continuityState').textContent=dialogue.length+' messages · '+(learning?.lessons.length||0)+' méthodes · '+dossierCount+' dossiers · '+archived.length+' demandes mises de côté.'+(at?' Dernière réponse enregistrée : '+new Date(at).toLocaleString('fr-FR')+'.':'')+' Nouveaux échanges limités à '+DIALOGUE_LIMITS.messages+' messages ou 2 Mio, sans effacement automatique.';
 $('savedRequests').hidden=!archived.length;const list=$('savedRequestList');list.replaceChildren();
 for(const row of archived.slice().reverse()){
  const item=document.createElement('div'),text=document.createElement('p'),button=document.createElement('button');
  text.textContent=row.text;button.className='secondary';button.textContent='Reprendre ce texte';button.disabled=busy;
  button.onclick=()=>{if(busy||!restoreComposer(row.text))return;$('question').focus();status('Texte récupéré. Appuie sur Envoyer pour une nouvelle réponse ; la demande archivée reste conservée.');};item.append(text,button);list.append(item);
 }
 if($('workSummary'))$('workSummary').textContent=job?.text?'Une demande interrompue attend ta reprise.':dialogue.length?dialogue.length+' messages conservés'+(dossierCount?' · '+dossierCount+' dossier(s) dans Créer':'')+'.':dossierCount?dossierCount+' dossier(s) conservé(s) dans Créer.':'Tes projets, documents et sauvegardes restent ici.';
}
const readDialogue=dialogueRows;
function openPanel(id,focusId){
 const panel=$(id);if(!panel)return;
 for(let el=panel;el;el=el.parentElement)if(el.tagName==='DETAILS')el.open=true;
 panel.scrollIntoView({block:'start',behavior:'smooth'});if(focusId)$(focusId)?.focus({preventScroll:true});
}
function rememberComposer(){
 unsavedComposer=true;
 try{if(!composerStore)throw Error('Stockage du brouillon indisponible.');composerStore.save($('question').value);unsavedComposer=false;$('draftState').textContent=$('question').value?'Brouillon conservé dans cet appareil.':'';}
 catch(e){$('draftState').textContent='Brouillon non sauvegardé. '+e.message;}
}
function restoreComposer(text){
 if($('question').value.trim()&&$('question').value.trim()!==text.trim()){status('Tu as déjà une demande en préparation. Envoie-la ou mets son texte de côté avant de reprendre celle-ci.');$('question').focus();return false;}
 $('question').value=text;rememberComposer();return true;
}
function clearComposerAfterSave(text){
 if($('question').value.trim()!==text)return;
 try{composerStore?.save('');$('question').value='';unsavedComposer=false;$('draftState').textContent='';}
 catch(e){$('draftState').textContent='Demande enregistrée ; le brouillon reste affiché. '+e.message;}
}
function guideAction(m,text){
 if(busy||pilot.active())return;
 try{
  if(m.guide==='workshop')location.assign('/atelier.html?request='+encodeURIComponent(m.requestId));
  else if(m.guide==='documents')openPanel('documentsPanel','documentsQuery');
  else if(m.guide==='project'){openPanel('projectPanel');if(!window.NoyauProjectWork?.prepare)throw Error('Les projets ne sont pas encore disponibles.');window.NoyauProjectWork.prepare(text);}
  else if(m.guide==='agent'){stageAgentDraft(localStorage,text);location.assign('/demandes.html');}
 }catch(e){status(e.message);}
}
function renderChat(){
 const box=$('conversation');box.replaceChildren();box.hidden=!dialogue.length;
 if(dialogue.length>100){const note=document.createElement('p');note.textContent='Les 100 derniers messages sont affichés. Les '+dialogue.length+' messages restent conservés dans la sauvegarde.';box.append(note);}
 for(const m of dialogue.slice(-100)){
  const p=document.createElement('p'),name=document.createElement('b');p.className='message-'+m.role;name.textContent=m.role==='user'?'Toi : ':'Aster : ';p.append(name,document.createTextNode(m.content));box.append(p);
  if(m.role!=='assistant'||m!==dialogue.at(-1))continue;
  const i=dialogue.indexOf(m),text=dialogue[i-1]?.content||'';
  if(Object.hasOwn(GUIDE_ACTIONS,m.guide)){
   const actions=document.createElement('div');actions.className='guide-actions';
   const button=document.createElement('button');button.textContent=GUIDE_ACTIONS[m.guide].label;button.onclick=()=>guideAction(m,text);actions.append(button);
   const discuss=document.createElement('button');discuss.className='secondary';discuss.textContent='En parler avec Aster';discuss.onclick=()=>{if(busy||pilot.active()||!restoreComposer(text))return;if(complete)launch(text);else{status('Installe le modèle pour en discuter localement. Ta demande reste conservée.');$('question').focus();}};actions.append(discuss);box.append(actions);
   const note=document.createElement('small');note.textContent='Outil proposé pour cette demande. Le travail attend ton choix.';box.append(note);continue;
  }
  const button=document.createElement('button');button.className='quiet';button.textContent='Corriger ou mémoriser';button.onclick=()=>{$('learnQuestion').value=text;$('learnAnswer').value=m.content.length<=400?m.content:'';openPanel('learnPanel','learnAnswer');};box.append(button);
  if(m.memoryIds?.length){const note=document.createElement('small');note.textContent=m.memoryIds.length+' mémoire(s) transmise(s) au modèle ; réponse à vérifier.';box.append(note);}
 }
 box.scrollTop=box.scrollHeight;
}
async function sendMessage(){
 const text=$('question').value.trim();if(!text||busy||pilot.active()||!db||document.hidden)return;
 const kind=suggestAction(text);
 if(!kind){if(!complete){status('Pour discuter librement, installe le modèle local. Les raccourcis vers un pack, un projet ou l’agent restent disponibles.');return;}return launch(text);}
 try{
  await window.NoyauLocalMaintenance.run(async()=>{
   const saved=await appendGuidance(db,text,kind,crypto.randomUUID());
   dialogue=readDialogue(await read(CHAT));if(JSON.stringify(saved)!==JSON.stringify(dialogue))throw Error('Enregistrement non confirmé. Ton texte reste affiché.');
   clearComposerAfterSave(text);renderChat();renderContinuity();
  });status('Demande conservée. Choisis la prochaine étape proposée dans la conversation.');
 }catch(e){status(e.message);}
}
// Read the previously validated runtime profile; this page cannot start test campaigns.
const pilot=createLocalPilot({model:MODEL.id,revision:MODEL.revision,read:()=>read(PILOT_KEY+'-'+MODEL.revision+'-v2'),write:v=>write(PILOT_KEY+'-'+MODEL.revision+'-v2',v),canRun:()=>false,pauseWork:()=>{},resumeWork:()=>{},render:p=>{const a=p.assessment;activity({correct:a.correct,attempted:a.attempted});}});
// Retain the exclusive engine lock with the loaded model, for at most one visible idle minute.
function release(keepModel=false){
 clearTimeout(timer);clearTimeout(idleTimer);idleTimer=null;busy=false;serial++;
 if(keepModel&&worker&&resident&&!document.hidden){
  const own=worker;own.onmessage=()=>{};own.onerror=own.onmessageerror=()=>{if(worker===own)release();};
  idleTimer=setTimeout(()=>{if(worker===own&&!busy)release();},60000);
 }else{worker?.terminate();worker=null;resident=null;unlock?.();unlock=null;}
 technical();controls();renderContinuity();
}
function stop(reason='USER'){
 if(maintenanceActive){window.NoyauProjectWork?.stop(reason);window.NoyauResearchWork?.stop(reason);return;}
 if(!busy&&!pilot.active()){if(worker){release();if(reason==='USER')status('Modèle libéré. Réponses et mémoire conservées.');}return;}
 if(busy)trace?.mark('PAUSED',{outcome:'PAUSED'});release();
 status(reason==='HIDDEN'?'Page passée hors écran : opération mise en pause. Fichiers conservés. Reviens puis utilise Reprendre pour une demande, ou Télécharger pour une installation.':'Pause demandée. Fichiers et demande conservés.');
}
function failure(message){$('allowFullTransfer').hidden=!message.includes('MODEL_RESUME_UNSUPPORTED');if(message.includes('MODEL_RESUME_UNSUPPORTED'))message='le serveur refuse la reprise partielle. Segments conservés. Tu peux autoriser une seule retransmission complète ci-dessous';if(message.startsWith('MODEL_STORAGE_REQUIRED_'))message='espace disponible insuffisant : prévoir '+message.split('_').at(-1)+' Mo avant de reprendre';trace?.mark('FAILED',{outcome:'FAIL'});release();status('Arrêt : '+message+'. La demande reste conservée. Reprise manuelle.');}
function deadline(ms,label){clearTimeout(timer);timer=setTimeout(()=>failure(label),ms);}
async function inspect(){const r=await cacheReport();complete=r.complete;const estimate=await navigator.storage?.estimate?.().catch(()=>null),space=storagePlan(r,estimate);$('cacheState').textContent=Math.round((r.bytes+r.partialBytes)/1000000)+' / '+Math.round(r.totalBytes/1000000)+' Mo présents · '+Math.round(space.missingBytes/1000000)+' Mo manquants.';$('spaceState').textContent=space.availableBytes===null?'Espace libre non communiqué par le navigateur.':'Espace disponible estimé : '+Math.floor(space.availableBytes/1000000)+' Mo'+(space.missingBytes?' ; prévoir au moins '+Math.ceil(space.requiredBytes/1000000)+' Mo.':'.');$('model').textContent=complete?'Modèle local prêt dans cet appareil.':'Installation du modèle à terminer.';$('install').textContent='Télécharger le modèle';$('switch').value=MODEL_MODE;$('modelStatus').textContent=(MODEL_MODE==='compact'?'Qwen 0,5B':'Qwen 1,5B')+' · '+Math.round(MODEL.modelBytes/1000000)+' Mo · moteur d’Aster. Ce nom d’application ne change pas l’origine ni la licence du modèle.';$('install').hidden=complete;$('installHint').hidden=complete;controls();return r;}
async function prepared(){try{await inspect();if(!complete)throw Error('fichiers du modèle sélectionné encore incomplets');status('Modèle prêt. Tu peux envoyer un message.');}catch(e){status('Préparation interrompue : '+e.message);}}
async function launch(text=null,resuming=false,allowFullRestart=false){
 if(busy||pilot.active()||document.hidden||!db)return;
 if(!text&&worker)release();clearTimeout(idleTimer);idleTimer=null;
 busy=true;$('allowFullTransfer').hidden=true;controls();status('Vérification des fichiers du modèle sélectionné… Un seul appui suffit.');const token=++serial;let own;
 try{
  if(!unlock){const reservation=await reserveEngine();if(token!==serial){reservation?.();return;}if(!reservation)throw Error('un autre onglet utilise le modèle ; mets cet onglet en pause');unlock=reservation;}
  const local=await readLocalState(db);if(token!==serial)return;acceptLocal(local);renderChat();
  if(resuming&&!job?.text){release();status('La demande est déjà terminée. Aucun nouveau calcul.');return;}
  const cached=await inspect();if(token!==serial)return;
  if(text&&!cached.complete)throw Error('modèle absent : utilise Télécharger');
  if(!text&&cached.complete){$('networkState').textContent='Vérification depuis le cache : 0 Mo de poids téléchargés.';release();await prepared();return;}
  if(text){reserveDialogueAnswer(dialogue,text);learning=learningState(await read(LEARNING_KEY));const passages=recallLessons(learning,text);if(!resuming)await saveNewJob({text,checkpoint:null,history:dialogue.slice(-6),passages,memoryIds:[],startedAt:new Date().toISOString()},token);else{await commitConversation(current=>({job:{...current.job,passages,memoryIds:[]}}),token);}if(token!==serial)return;activity({event:'QUESTION',active:true,phase:'Demande reçue ; mémoire pertinente recherchée.'});}
  const reused=!!(text&&worker&&resident?.profile===pilot.profile());trace=createLlmTrace();trace.mark('ATTEMPT_STARTED');if(reused)own=worker;else{worker?.terminate();resident=null;own=new Worker(workerModelURL(MODEL_MODE),workerModelOptions(MODEL_MODE));worker=own;trace.mark('WORKER_CREATED');}
  let acknowledged=false,ready=false,delivering=false;const nonce=String(token)+':'+Date.now();
  const current=()=>worker===own&&token===serial;
  const sendChat=()=>{deadline(120000,'réponse trop longue');own.postMessage({type:'CHAT',text:job.text,localLearning:true,context:{localOnly:true,history:job.history||[],facts:{available:false},passages:job.passages||[]},mode:'direct',checkpoint:job.checkpoint});};
  own.onerror=()=>{if(current())failure('moteur interrompu');};own.onmessageerror=()=>{if(current())failure('échange avec le moteur interrompu');};
  own.onmessage=async({data:p})=>{if(!current())return;try{
   if(p.type==='TECHNICAL'){trace.mark(p.event,p);technical();}
   else if(p.type==='HELLO_ACK'){
    if(acknowledged||p.nonce!==nonce)return;
    if(p.protocol!==ENGINE_PROTOCOL||p.model!==MODEL.id||p.revision!==MODEL.revision)throw Error('le moteur ne correspond pas au modèle sélectionné ; ferme les autres onglets et rouvre Aster');
    acknowledged=true;trace.mark('WORKER_ACK');
    if(text&&reused){ready=true;trace.mark('MODEL_REUSED');status('Modèle déjà prêt dans cet appareil. Calcul de la réponse…');sendChat();}
    else if(text){trace.mark('LOAD_SENT');deadline(480000,'chargement trop long');status('Lecture du modèle dans cet appareil. Ce n’est pas un téléchargement.');own.postMessage({type:'LOAD',profile:pilot.profile()});}
    else{status('Téléchargement du modèle sélectionné confirmé… Garde cette page visible.');trace.mark('DOWNLOAD_STARTED');deadline(120000,'installation sans progression');own.postMessage({type:'PREPARE',allowFullRestart});}
   }else if(p.type==='READY'){
    if(!acknowledged||ready||p.model!==MODEL.id||p.revision!==MODEL.revision)throw Error('modèle non confirmé');ready=true;resident={profile:pilot.profile()};trace.mark('MODEL_READY');sendChat();
   }else if(p.type==='CONTEXT'){const ids=(p.retainedSources||[]).filter(x=>x.source==='OWNER_VALIDATED_MEMORY'&&(job.passages||[]).some(y=>y.id===x.id)).map(x=>x.id);job.memoryIds=[...new Set([...(job.memoryIds||[]),...ids])];if(ids.length)activity({event:'CONTEXT',phase:ids.length+' méthode(s) conservée(s) dans le contexte du modèle.'});
   }else if(p.type==='DOWNLOAD'){
    const received=Math.round((p.networkBytes||0)/1000000),verified=Math.round((p.verifiedBytes||0)/1000000);$('networkState').textContent='Cette installation : '+received+' Mo reçus du réseau · '+(p.requests||0)+' requête(s).';status(p.phase==='VERIFY'?'Vérification locale · '+verified+' Mo confirmés.':p.phase==='STORAGE'?'Vérification de l’espace disponible…':p.phase==='RESUME_BLOCKED'?'Reprise partielle refusée par le serveur ; arrêt.':'Installation · '+verified+' Mo vérifiés · '+received+' Mo reçus'+(p.transferKind==='full'?' · réponse complète du serveur.':'.'));deadline(120000,'installation sans progression');
   }else if(p.type==='PREPARED'){
    if(!acknowledged||p.model!==MODEL.id||p.revision!==MODEL.revision||!p.report?.complete)throw Error('installation du modèle sélectionné non confirmée');trace.mark('FILES_READY');$('networkState').textContent='Installation terminée : '+Math.round((p.report.networkBytes||0)/1000000)+' Mo reçus · '+(p.report.requests||0)+' requête(s).';release();await prepared();
   }else if(p.type==='STAGE'){status(String(p.label||'Calcul local').slice(0,200));}
   else if(p.type==='CHECKPOINT'){
    if(!ready||!job||JSON.stringify(p.checkpoint).length>64000)throw Error('point de reprise invalide');const next={...job,checkpoint:p.checkpoint};await commitConversation(()=>({job:next}),token);if(!current())return;own.postMessage({type:'CHECKPOINT_ACK',id:p.id,ok:true,checkpoint:p.checkpoint});
   }else if(p.type==='ANSWER'){
    if(!ready||delivering||typeof p.answer!=='string'||p.answer.length>12000)throw Error('réponse invalide');delivering=true;clearTimeout(timer);
    const answeredText=job.text;await commitAnswer(p.answer,job.memoryIds||[],token);if(!current())return;
    trace.mark('ANSWER_SAVED');release(true);renderChat();renderLearning();renderContinuity();clearComposerAfterSave(answeredText);activity({event:'SAVED',active:false});status('Réponse sauvegardée dans cet appareil. Son contenu reste à vérifier.');
   }else if(p.type==='ERROR')throw Error(String(p.message||'calcul interrompu').slice(0,180));
  }catch(e){if(current())failure(e.message);}};
  status('Connexion au moteur '+(MODEL_MODE==='compact'?'0,5B':'1,5B')+'…');deadline(20000,'moteur sans réponse');own.postMessage({type:'HELLO',nonce});
 }catch(e){if(token===serial)failure(e.message);}
}

function renderLearning(){
 $('learnCount').textContent=learning.lessons.length+' méthode(s) conservée(s) · '+learning.contextUses+' réponse(s) avec mémoire transmise. Ce compteur ne mesure pas leur exactitude.';
 activity({memories:learning.lessons.length,uses:learning.contextUses});const list=$('learnList');list.replaceChildren();
 for(const row of learning.lessons){const p=document.createElement('p');p.textContent=row.question+' → '+row.answer;const button=document.createElement('button');button.className='secondary';button.textContent='Oublier cette méthode';button.onclick=()=>changeLearning(state=>({...state,lessons:state.lessons.filter(x=>x.id!==row.id)}));list.append(p,button);}
}
async function changeLearning(transform){
 if(!db||busy||pilot.active())return;busy=true;clearTimeout(idleTimer);const token=++serial;controls();
 try{
  if(!unlock){const reservation=await reserveEngine();if(token!==serial){reservation?.();return;}if(!reservation)throw Error('Un autre onglet travaille.');unlock=reservation;}
  const local=await readLocalState(db);if(token!==serial)return;acceptLocal(local);
  await commitConversation(current=>({learning:transform(current.learning)}),token);if(token!==serial)return;
  renderLearning();renderContinuity();activity({event:'LEARNED',phase:'Mémoire locale sauvegardée et relue.'});$('learnState').textContent='Mémoire sauvegardée. Les méthodes pertinentes seront retrouvées automatiquement.';
 }catch(e){if(token===serial)$('learnState').textContent=e.message;}finally{if(token===serial)release(true);}
}
$('learnSave').onclick=()=>changeLearning(state=>retainLesson(state,$('learnQuestion').value,$('learnAnswer').value,crypto.randomUUID()));

async function storageStatus(){try{const yes=await navigator.storage?.persisted?.();$('storageState').textContent=yes===true?'Conservation persistante accordée par le navigateur. Garde aussi une sauvegarde.':'Conservation persistante non confirmée. Le navigateur peut libérer des fichiers ; garde une sauvegarde.';}catch{$('storageState').textContent='État de conservation non disponible.';}}
$('keepStorage').onclick=async()=>{try{if(!navigator.storage?.persist){$('storageState').textContent='Ce navigateur ne propose pas cette demande.';return;}await navigator.storage.persist();await storageStatus();}catch{$('storageState').textContent='Demande de conservation non confirmée. Les fichiers existants sont conservés.';}};
$('allowFullTransfer').onclick=()=>{launch(null,false,true);};
$('install').onclick=()=>{return launch();};
$('ask').onclick=sendMessage;
$('question').addEventListener('input',rememberComposer);
window.addEventListener('beforeunload',e=>{if(unsavedComposer){e.preventDefault();e.returnValue='';}});
function revealHash(){const id=location.hash.slice(1);if(['workPanel','continuity','documentsPanel','projectPanel','researchPanel','settingsPanel','restorePanel'].includes(id))openPanel(id);}
window.addEventListener('hashchange',revealHash);
$('resume').onclick=()=>{if(job?.text)launch(job.text,true);};
$('stop').onclick=()=>stop('USER');
$('switch').onchange=()=>{if(busy||pilot.active())return;const mode=$('switch').value;if(!['compact','standard'].includes(mode)||mode===MODEL_MODE)return;if(worker)release();try{localStorage.setItem(MODEL_CHOICE_KEY,mode);}catch{}const u=new URL(location.href);u.searchParams.set('llm',mode);location.assign(u.href);};
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop('HIDDEN');});window.addEventListener('pagehide',()=>stop('HIDDEN'));
window.NoyauLocalMaintenance={async run(task){if(!db||busy||pilot.active())throw Error('Mets le calcul en pause avant cette opération.');release();busy=true;maintenanceActive=true;controls();try{unlock=await reserveEngine();if(!unlock)throw Error('Un autre onglet utilise le modèle.');return await task(db);}finally{maintenanceActive=false;release();}}};
document.addEventListener('noyau-learning-changed',async()=>{if(!db||busy)return;try{learning=learningState(await read(LEARNING_KEY));renderLearning();renderContinuity();}catch(e){status(e.message);}});
const initialization=(async()=>{try{db=await memory.open();try{composerStore=createComposerDraftStore(localStorage);$('question').value=composerStore.read();$('draftState').textContent=$('question').value?'Brouillon retrouvé. Tu peux le compléter.':'';}catch{$('draftState').textContent='Brouillon local non disponible. Copie ton texte avant de fermer.';}acceptLocal(await readLocalState(db));dossierCount=(await read('noyau.workshop.v1'))?.dossiers?.length||0;renderLearning();renderContinuity();await pilot.init();await storageStatus();await inspect();renderChat();const old=await read('assistantPersonal-v1');$('memory').textContent='Mémoire existante conservée'+(old?.threads?' · '+old.threads.length+' ancien(s) échange(s) dans la sauvegarde.':'.');status(job?.text?'Une demande interrompue est conservée. Reprise uniquement par le bouton.':complete?'Prêt. Décris ce que tu veux faire.':'Décris ta demande pour trouver l’outil utile. Installe le modèle si tu veux discuter localement.');}catch(e){db=null;status('Stockage indisponible : '+e.message);}
controls();technical();revealHash();})();

import {studyState} from '/aster-study-core.js?v=A112';
import {STUDY_CASES,STUDY_SUITE,studyCase,studyMessages} from '/aster-study-cases.js?v=A106';
import {imageHash} from '/aster-image-core.js?v=A107';
// Only fictitious exercises whose exact correction was individually reviewed.
// Images, client projects, free-form notes and model outputs are never exported.
export function trainingCandidates(raw){
 const state=studyState(raw),seen=new Set(),out=[];
 for(const s of state.sessions){if(!s.grade||s.kind!=='study'||s.status!=='graded')continue;
  for(const row of s.items){const c=studyCase(row.caseId);if(c.split!=='study'||row.status!=='done'||!row.attempts.some(a=>a.status==='answer')||seen.has(c.id))continue;
   seen.add(c.id);out.push({caseId:c.id,sessionId:s.id,question:c.task,answer:c.expected,family:c.family,split:c.id.endsWith('-5')?'validation':'train'});
  }
 }return out;
}
export async function trainingBundle(raw,selected,at=new Date().toISOString()){
 if(!Array.isArray(selected)||!selected.length||selected.length>36||new Set(selected).size!==selected.length)throw Error('Sélectionne les corrections relues, sans doublon.');
 const available=trainingCandidates(raw),examples=[];
 for(const id of selected){const c=available.find(c=>c.caseId===id);if(!c)throw Error('Exemple non relu ou réservé à l’évaluation.');
  const messages=studyMessages({caseId:id}).map(({role,content})=>({role,content}));messages.push({role:'assistant',content:c.answer});
  examples.push({...c,messages,contentSha256:await imageHash(JSON.stringify(messages)),source:'aster-authored-synthetic',reviewedAt:at,trainingConsent:true});
 }
 const holdout=[];for(const c of STUDY_CASES.filter(c=>c.split==='evaluation')){const messages=studyMessages({caseId:c.id}).map(({role,content})=>({role,content}));messages.push({role:'assistant',content:c.expected});holdout.push({caseId:c.id,family:c.family,messages,contentSha256:await imageHash(JSON.stringify(messages)),split:'holdout'});}
 return{schema:'aster-training-bundle-v1',suite:STUDY_SUITE,createdAt:at,source:'author-written synthetic curriculum; not customer data',purpose:'pilot-text-lora',weightsTrained:false,examples,holdout,limits:'Petit programme fictif : ne démontre ni qualité générale ni apprentissage de génération d’images. Les réponses guidées ne sont pas des réussites autonomes.'};
}
export function studyTimeEstimate(raw,session){
 const values=studyState(raw).sessions.filter(s=>s.model===session.model&&s.modelRevision===session.modelRevision).flatMap(s=>s.items.flatMap(r=>r.attempts)).filter(a=>a.status==='answer'&&a.wallMs>0).map(a=>a.wallMs).slice(-40).sort((a,b)=>a-b);
 if(values.length<3)return null;
 const remaining=session.items.filter(r=>r.status==='pending'||r.status==='running').length;
 return{samples:values.length,lowSeconds:Math.floor(remaining*values[Math.floor((values.length-1)*.1)]/1000),highSeconds:Math.ceil(remaining*values[Math.ceil((values.length-1)*.9)]/1000),budgetSeconds:Math.max(0,Math.ceil((session.minutes*60000-session.activeMs)/1000))};
}

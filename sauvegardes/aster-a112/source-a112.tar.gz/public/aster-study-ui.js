import {STUDY_KEY,studyState,validateStudy,studyCommand,newStudy,recoverStudy,studySummary,studyCandidates,studyReport} from '/aster-study-core.js?v=A112';
import {studyCase} from '/aster-study-cases.js?v=A106';
import {LEARNING_KEY,learningState} from '/noyau-learning.js?v=A91';
import {MODEL} from '/blob-assistant-model.js?v=A83';
import {commitStudy} from '/aster-study-store.js?v=A106';
import {runStudy} from '/aster-study-runner.js?v=A106';
import {trainingCandidates,trainingBundle,studyTimeEstimate} from '/aster-training-data.js?v=A107';
export async function initStudyUI({db,root,execute,status,onAccepted,onBusy=()=>{}}){
 const memory=window.BlobLocalMemory;
 let state,openingError=null;
 try{state=studyState(await memory.setting(db,STUDY_KEY));}catch(e){openingError=e;state=studyState(null);}
 let selected=state.sessions.at(-1)?.id,controller=null,blocked=!!openingError;
 let draftQueue=Promise.resolve(),pendingDrafts=0,draftFailed=false;
 const urls=[],stamp=()=>new Date().toISOString(),current=()=>state.sessions.find(s=>s.id===selected);
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 function button(label,fn){const b=el('button',label,'secondary');b.type='button';b.onclick=()=>execute(async()=>{await flushDrafts();await fn();});return b;}
 function link(blob,name,label){const a=el('a',label,'button secondary');a.href=URL.createObjectURL(blob);urls.push(a.href);a.download=name;return a;}
 async function commit(transform,options){if(blocked)throw Error('Étude à relire après restauration.');try{state=await commitStudy(db,state.revision,transform,options);}catch(e){blocked=true;throw e;}}
 async function flushDrafts(){await draftQueue;if(blocked)throw Error('Enregistrement de l’étude non confirmé. Récupère les preuves avant de recharger.');}
 function queueDraft(change){const id=selected;pendingDrafts++;draftQueue=draftQueue.then(async()=>{await commit(st=>{const s=st.sessions.find(s=>s.id===id);if(!s)throw Error('Séance introuvable.');change(s);s.updatedAt=stamp();return st;});}).catch(e=>{blocked=true;draftFailed=true;status(e.message+' Dernière saisie non confirmée.',true);}).finally(()=>pendingDrafts--);}
 async function save(s){await commit(st=>{const i=st.sessions.findIndex(x=>x.id===s.id);if(i<0)st.sessions.push(s);else st.sessions[i]=s;return st;});render();}
 async function run(){
  if(controller)throw Error('Une séance travaille déjà.');
  controller=new AbortController();onBusy(true);render();
  try{await runStudy(current(),{save,signal:controller.signal,onProgress:t=>{const p=document.getElementById('studyProgress');if(p)p.textContent=t;}});status(current()?.status==='waiting'?'Une question t’attend dans l’étude.':'Bilan d’étude enregistré. Tu peux le relire et le noter.');}
  finally{controller=null;onBusy(false);render();}
 }
 async function resume(){let s=recoverStudy(current());if(s.status==='waiting'){for(const q of s.questions)if(q.status==='pending'){q.status='answered';q.answer='Continuer avec les autres exercices.';}s.status='paused';}await save(s);await run();}
 async function finish(){let s=recoverStudy(current());for(const q of s.questions)if(q.status==='pending'){q.status='answered';q.answer='Terminer et rendre le bilan.';}s.status=s.grade?'graded':'review';s.reason='Arrêt demandé. Les résultats partiels sont conservés.';await save(s);status('Bilan prêt à relire, même si certains exercices restent non traités.');}
 function render(){
  for(const url of urls)URL.revokeObjectURL(url);urls.length=0;root.replaceChildren();
  const s=current();root.hidden=!s&&!openingError;if(!s){if(openingError)root.append(el('p','Étude indisponible : '+openingError.message+' Tes projets restent accessibles ; aucune donnée n’a été effacée.','status error'));return;}
  const r=studySummary(s);root.append(el('h2','Mon étude'),el('p',s.goal,'helper'));
  const p=el('p',controller?'Étude en cours…':s.status==='waiting'?'Une question pour continuer.':['review','graded'].includes(s.status)?'Bilan enregistré.':'Séance conservée. Reprise manuelle.','status');p.id='studyProgress';p.setAttribute('role','status');p.setAttribute('aria-live','polite');root.append(p);
  root.append(el('p',r.attempted+'/'+r.total+' exercices abordés · '+r.activeSeconds+' s actives · budget maximal '+s.minutes+' min.','helper'));
  const estimate=studyTimeEstimate(state,s);
  if(!['review','graded'].includes(s.status))root.append(el('p',estimate?'Étapes restantes : environ '+estimate.lowSeconds+'–'+estimate.highSeconds+' s d’inférence, sur '+estimate.samples+' mesures de ce modèle. Chargement et éventuelles corrections en plus. Budget restant : '+estimate.budgetSeconds+' s.':'Durée des exercices encore inconnue : il faut d’abord des mesures avec ce modèle. La séance s’arrête au budget ou dès le travail terminé.','helper'));
  if(controller){const pause=el('button','Mettre l’étude en pause','secondary');pause.type='button';pause.onclick=()=>controller?.abort();root.append(pause);return;}
  if(s.reason)root.append(el('p',s.reason,'helper'));
  if(blocked){root.append(el('p','Dernier état connu conservé. Rouvre la page pour relire les données.','status error'));}
  const question=s.questions.find(q=>q.status==='pending');if(question)root.append(el('p',question.text));
  const done=['review','graded'].includes(s.status),actions=el('div',null,'downloads');
  if(!done&&!blocked){actions.append(button(question?'Continuer les autres exercices':'Reprendre mon étude',resume),button('Terminer et voir le bilan',finish));}root.append(actions);
  root.append(el('p',s.kind==='study'?'Premiers essais exacts : '+r.correct+'/'+r.first+'. Après correction guidée : '+r.guidedCorrect+'/'+r.guided+'.':'Cas nouveaux comparés : '+r.pairs+'. Sans méthodes : '+r.without+' exacts ; avec méthodes : '+r.with+'. Régressions : '+r.regressions+'.'));
  root.append(el('p','Exercices fictifs du programme pratique. Les essais guidés ne prouvent pas un progrès. Une comparaison sur quelques cas reste indicative. Aucun poids du modèle n’est entraîné.','helper'));
  const details=el('details'),summary=el('summary','Voir mes exercices et leurs corrections');details.append(summary);
  for(const row of s.items){const c=studyCase(row.caseId),box=el('article',null,'caption');box.append(el('strong',c.title+(row.phase==='without'?' · sans méthode':row.phase==='with'?' · avec méthodes':'')),el('p',c.task));
   for(const [i,a]of row.attempts.entries())box.append(el('p','Essai '+(i+1)+' : '+(a.status==='answer'?a.text:'Interrompu sans réponse enregistrée')+(a.status==='answer'?(a.correct?' — exact':' — à corriger'):'')));
   if(row.attempts.some(a=>a.status==='answer'))box.append(el('p','Corrigé : '+c.expected,'helper'));else box.append(el('p','Non traité.','helper'));details.append(box);
  }root.append(details);
  if(done&&!blocked){
   const form=el('form',null,'study-grade'),label=el('label','Ta note'),select=el('select');select.id='studyGrade';label.htmlFor=select.id;select.setAttribute('aria-label','Note du bilan de un à cinq');
   for(const [v,t]of [['','Choisir une note'],['1','1 — incorrect'],['2','2 — grosses corrections'],['3','3 — utile après correction'],['4','4 — presque prêt'],['5','5 — utile pour ce travail']]){const o=el('option',t);o.value=v;select.append(o);}select.value=s.reviewDraft?.score??(s.grade?String(s.grade.score):'');
   const note=el('textarea');note.maxLength=800;note.value=s.reviewDraft?.comment??s.grade?.comment??'';note.placeholder='Ta correction ou ton avis (facultatif)';note.setAttribute('aria-label','Ton avis sur le travail');
   const submit=el('button',s.grade?'Mettre à jour ma note':'Enregistrer ma note');submit.type='submit';form.append(label,select,note,submit);form.oninput=()=>{const draft={score:select.value,comment:note.value};queueDraft(s=>{s.reviewDraft=draft;});};form.onsubmit=e=>{e.preventDefault();return execute(async()=>{await flushDrafts();if(!/^[1-5]$/.test(select.value))throw Error('Choisis une note de 1 à 5.');const value=validateStudy({...current(),status:'graded',reviewDraft:{score:select.value,comment:note.value},grade:{score:Number(select.value),comment:note.value,at:stamp()}});await save(value);status('Ta note est enregistrée. Tu peux maintenant choisir une méthode à conserver.');});};root.append(form);
   const candidates=studyCandidates(s);if(candidates.length){const panel=el('details');panel.append(el('summary','Méthodes à retenir après ta relecture'));
    panel.append(el('p','Ces règles viennent des corrigés du programme. Elles sont proposées après une erreur, puis réutilisées seulement si tu les acceptes.','helper'));
    for(const c of candidates){const box=el('article',null,'caption'),input=el('textarea');input.value=s.methodDrafts?.find(m=>m.family===c.family)?.text??c.answer;input.maxLength=400;input.setAttribute('aria-label','Méthode pour '+studyCase(c.sourceCaseIds[0]).title);input.oninput=()=>{const text=input.value;queueDraft(s=>{s.methodDrafts=(s.methodDrafts||[]).filter(m=>m.family!==c.family);s.methodDrafts.push({family:c.family,text});});};box.append(input);
     if(s.retained.some(m=>m.family===c.family))box.append(el('p','Méthode retenue. La prochaine étude pourra en mesurer l’effet sur de nouveaux cas.','helper'));
     else {const b=button('Conserver cette méthode',async()=>{await commit(st=>st,{retain:{sessionId:s.id,family:c.family,id:crypto.randomUUID(),answer:input.value}});render();status('Méthode enregistrée. Son utilité reste à vérifier sur un nouveau cas.');});b.disabled=!s.grade;box.append(b);}panel.append(box);
    }root.append(panel);
   }
  }
  const exports=el('div',null,'downloads');exports.append(link(new Blob([studyReport(s)],{type:'text/plain;charset=utf-8'}),'aster-bilan-etude.txt','Récupérer le bilan'));root.append(exports);
  const archive=el('details');archive.append(el('summary','Mes séances enregistrées'));
  for(const past of state.sessions){const b=button(new Date(past.at).toLocaleString('fr-FR')+' · '+({ready:'prête',running:'interrompue',paused:'en pause',waiting:'question en attente',review:'à relire',graded:'notée'}[past.status]),async()=>{selected=past.id;render();});archive.append(b);}
  archive.append(el('p',state.sessions.length+'/20 séances. Aucune suppression automatique. Les sauvegardes complètes incluent ces séances.','helper'));
  archive.append(link(new Blob([JSON.stringify({schema:'aster-study-evidence-v1',study:state})],{type:'application/json'}),'aster-etudes-preuves.json','Exporter les preuves des séances'));
  root.append(archive);
  const candidates=trainingCandidates(state);
  if(done&&candidates.length&&!blocked){
   const panel=el('details');panel.append(el('summary','Préparer des exemples pour un futur entraînement'));
   panel.append(el('p','Relis et coche chaque corrigé que tu autorises à utiliser. Seuls ces exercices fictifs sont exportés, jamais tes photos ni tes dossiers client. Cet export ne modifie aucun poids.','helper'));
   const selection=[];
   for(const c of candidates){const label=el('label',null,'training-example'),check=el('input');check.type='checkbox';selection.push({check,id:c.caseId});label.append(check,el('span',c.question+' → '+c.answer+(c.split==='validation'?' (réservé à la validation)':'')));panel.append(label);}
   const destination=el('div',null,'downloads');panel.append(button('Préparer les exemples sélectionnés',async()=>{const bundle=await trainingBundle(state,selection.filter(x=>x.check.checked).map(x=>x.id));destination.replaceChildren(link(new Blob([JSON.stringify(bundle,null,2)],{type:'application/json'}),'aster-exemples-relus.json','Télécharger les exemples relus'));status('Données d’entraînement préparées. Aucun modèle n’a été entraîné.');}),destination);root.append(panel);
  }
 }
 async function handle(text){const command=studyCommand(text);if(!command)return false;await flushDrafts();
  if(command.kind==='start'){const mem=learningState(await memory.setting(db,LEARNING_KEY));const s=newStudy(state,command,MODEL,mem,crypto.randomUUID());selected=s.id;await save(s);await onAccepted();root.scrollIntoView({block:'start'});await run();}
  else {const unfinished=state.sessions.find(s=>!['review','graded'].includes(s.status));if(unfinished)selected=unfinished.id;if(!current())throw Error('Demande par exemple « Étudie 5 minutes sur les demandes client ».');await onAccepted();if(command.kind==='resume')await resume();else await finish();}
  return true;
 }
 render();return{handle,pending:()=>pendingDrafts>0||draftFailed,pause:()=>controller?.abort(),invalidate:()=>{controller?.abort();blocked=true;render();}};
}

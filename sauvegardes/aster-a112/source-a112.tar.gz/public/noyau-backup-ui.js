import {snapshot,validateBackup,serializeBackup,previewBackup,restoreBackup,ROLLBACK_KEY,MAX_BACKUP_BYTES} from '/noyau-backup.js?v=A112';
import {MODEL_CHOICE_KEY} from '/blob-model-choice.js?v=A100';
import {PROJECT_DRAFT_KEY,projectDrafts} from '/noyau-project-core.js?v=A100';
import {DOCUMENT_DRAFT_KEY,documentDraft} from '/noyau-documents-core.js?v=A100';
import {RESEARCH_DRAFT_KEY,researchDrafts} from '/noyau-research-core.js?v=A100';
import {COMPOSER_DRAFT_KEY,composerDraft} from '/aster-request-core.js?v=A110';
const $ = id => document.getElementById(id), memory = window.BlobLocalMemory;
let candidate = null, running = false, reopening = false, loading = false, selection = 0;
const notice = text => { $('restoreState').textContent = text; if($('backupState'))$('backupState').textContent=text; };
function controls() {
  const busy = running || reopening;
  for (const id of ['backup','restoreFile','restorePrevious','restoreExportPrevious']) $(id).disabled = busy;
  $('restoreConfirm').disabled = busy || loading || !candidate;
  $('restoreApply').disabled = busy || loading || !candidate || !$('restoreConfirm').checked;
}
const preferences = () => ({modelChoice:localStorage.getItem(MODEL_CHOICE_KEY)||'compact',projectDrafts:projectDrafts(JSON.parse(localStorage.getItem(PROJECT_DRAFT_KEY)||'null')),documentDraft:documentDraft(JSON.parse(localStorage.getItem(DOCUMENT_DRAFT_KEY)||'null')),researchDrafts:researchDrafts(JSON.parse(localStorage.getItem(RESEARCH_DRAFT_KEY)||'null')),composerDraft:composerDraft(JSON.parse(localStorage.getItem(COMPOSER_DRAFT_KEY)||'null'))});
function download(name, data) {
  const blob = new Blob([serializeBackup(data)],{type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url),60000);
  return blob.size;
}
async function run(task) {
  if (running || reopening) return;
  running = true; controls();
  try {
    await window.NoyauLocalMaintenance.run(db => navigator.locks?.request
      ? navigator.locks.request('noyau-data-maintenance',() => task(db)) : task(db));
  } catch (e) { notice(e.name === 'QuotaExceededError' ? 'Espace insuffisant. Restauration annulée ; données précédentes conservées.' : e.message); }
  finally { running = false; controls(); }
}
async function apply(db,data) {
  const result = await restoreBackup(db,data,preferences());
  const mode = result.preferences.modelChoice;
  if (mode) { try { localStorage.setItem(MODEL_CHOICE_KEY,mode); } catch {} }
  let draftsRestored=true;
  try{localStorage.setItem(PROJECT_DRAFT_KEY,JSON.stringify(projectDrafts(result.preferences.projectDrafts)));}catch{draftsRestored=false;}
  try{localStorage.setItem(DOCUMENT_DRAFT_KEY,JSON.stringify(documentDraft(result.preferences.documentDraft)));}catch{draftsRestored=false;}
  try{localStorage.setItem(RESEARCH_DRAFT_KEY,JSON.stringify(researchDrafts(result.preferences.researchDrafts)));}catch{draftsRestored=false;}
  try{localStorage.setItem(COMPOSER_DRAFT_KEY,JSON.stringify(composerDraft(result.preferences.composerDraft)));}catch{draftsRestored=false;}
  // This reload starts no model and prevents stale in-memory state from overwriting recovery.
  reopening = true;
  notice(draftsRestored?'Restauration confirmée. Réouverture avec les données récupérées…':'Données restaurées. Les brouillons de formulaire n’ont pas pu être rétablis ; ils restent dans le fichier de sauvegarde. Réouverture…');
  try { const channel = new BroadcastChannel('noyau-recovery'); channel.postMessage('RESTORED'); channel.close(); } catch {}
  const url = new URL(location.href); if (mode) url.searchParams.set('llm',mode); location.replace(url.href);
}
$('backup').onclick = () => run(async db => { const size=download('Aster-sauvegarde-privee-A102.json',await snapshot(db,preferences())); notice('Copie préparée ('+(size/1048576).toFixed(1)+' / 40 Mio). Enregistre le fichier dans Fichiers : il contient tes échanges, méthodes, projets, documents, recherches, brouillons, demandes mises de côté et dossiers photo. Le site ne peut pas confirmer son enregistrement hors du navigateur.'); });
$('restoreFile').onchange = async () => {
  if (running || reopening) return;
  const selected = ++selection, file = $('restoreFile').files?.[0];
  candidate = null; loading = !!file; $('restoreConfirm').checked = false; controls();
  if (!file) { notice('Aucune sauvegarde sélectionnée.'); return; }
  notice('Lecture de la sauvegarde sélectionnée…');
  try {
    if (file.size > MAX_BACKUP_BYTES) throw Error('Fichier supérieur à 40 Mio.');
    const data = validateBackup(await file.text());
    if (selected !== selection) return;
    candidate = data; const p = previewBackup(candidate);
    notice('À restaurer : '+p.messages+' messages, '+p.methods+' méthodes, '+p.projects+' projets, '+p.documents+' documents, '+p.research+' recherches, '+p.dossiers+' dossiers et '+p.settings+' réglages. Export : '+(p.date || 'date inconnue')+'. Les données actuelles seront remplacées et conservées dans une copie de retour. Aucun calcul ne sera lancé.');
  } catch (e) { if (selected === selection) { candidate = null; notice('Fichier refusé : '+e.message); } }
  finally { if (selected === selection) { loading = false; controls(); } }
};
$('restoreConfirm').onchange = controls;
$('restoreApply').onclick = () => {
  if (running || reopening || loading || !candidate || !$('restoreConfirm').checked) return;
  const selected = structuredClone(candidate);
  return run(db => apply(db,selected));
};
$('restorePrevious').onclick = () => {
  if (running || reopening) return;
  ++selection; loading = false; candidate = null; $('restoreConfirm').checked = false; $('restoreFile').value = '';
  return run(async db => {
    const previous = await memory.setting(db,ROLLBACK_KEY);
    if (!previous) throw Error('Aucune copie de retour disponible.');
    candidate = validateBackup(previous);
    const p = previewBackup(candidate); notice('Copie avant restauration sélectionnée : '+p.messages+' messages et '+p.dossiers+' dossiers. Confirme ci-dessous pour revenir à cet état.');
  });
};
$('restoreExportPrevious').onclick = () => run(async db => {
  const previous = await memory.setting(db,ROLLBACK_KEY); if (!previous) throw Error('Aucune copie de retour disponible.');
  download('Noyau-avant-restauration.json',previous); notice('Copie précédente préparée pour sauvegarde.');
});
controls();
try { const channel = new BroadcastChannel('noyau-recovery'); channel.onmessage = e => { if (e.data === 'RESTORED') location.reload(); }; } catch {}

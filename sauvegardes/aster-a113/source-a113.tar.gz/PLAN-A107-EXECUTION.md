# Suivi du plan de 120 actions approuvé par Fabien

Le découpage ci-dessous conserve l’ordre des douze lots de dix actions du
plan approuvé. Il ne marque pas un lot complet sur la seule existence de code.

| Lot | État A107 | Condition suivante |
|---|---|---|
| 1–10 : audit, périmètre, réussite, matériel | Source et accès examinés ; matériel du téléphone non mesuré | Mesurer un usage utile sur l’iPhone 17 Pro Max |
| 11–20 : moteur, accès, licence, budget | Connecteur OpenAI Images écrit ; aucun accès actif | Connexion sécurisée et plafond approuvé, une vraie génération et une vraie retouche |
| 21–30 : passerelle et travaux | Identité, quotas, clés, résultats privés, interruption testés en simulation | Test amont réel ; service durable distinct si travail après fermeture requis |
| 31–40 : création et édition | Préparation dans la conversation, aperçu/PNG et source préservée | Évaluer avant/après sur photos autorisées ; itérations et masque d’édition |
| 41–50 : qualité et coût | Format, taille, reprise et mesure de durée contrôlés | Qualité visuelle humaine, coût réel, correction bornée, pas de faux équivalent grand modèle |
| 51–60 : mémoire et interface | Pas de nouvel onglet ; 20 travaux distants ; suppression récupérable ; brouillons sauvegardés | Sauvegardes au-delà de 40 Mio et ancien dialogue toujours à traiter séparément |
| 61–70 : exemples relus | Sélection individuelle, provenance synthétique, empreintes, trois ensembles séparés | Enrichir avec des tâches autorisées nouvelles ; ne pas généraliser depuis 36 cas |
| 71–80 : premier entraînement | Validateur opérationnel, pilote LoRA écrit hors ligne | Qualifier GPU/dépendances/base, exécuter et constater des poids réellement modifiés |
| 81–90 : candidat réversible | Budget, baseline/candidat, checkpoints et refus de promotion écrits | Tests GPU ; reprise exacte optimiseur/budget non implémentée |
| 91–100 : comparaisons et téléphone | Non exécuté | Quatre conditions, cas indépendants, quantification, chargement explicite et retour arrière |
| 101–110 : mode étudiant utile | A106 conservé ; estimations mesurées et export A107 ajoutés | Relecture réelle, exemple nouveau et comparaison sur iPhone |
| 111–120 : image spécialisée et offre | Le pack local reste utilisable ; image/vidéo/distribution non validées | Trois démonstrations autorisées, coût/marge/temps réels, essai client avant marché de puissance |

Prochain ordre d’exécution : activer le moteur avec un budget défini → une
génération + une retouche réelles → valider leur qualité et coût → constituer
un jeu utile relu → qualifier le GPU et exécuter un seul pilote → comparer et
rejeter/promouvoir manuellement → valider l’offre avec un client consentant.
Ne jamais compenser un accès manquant par une simulation présentée comme réelle.

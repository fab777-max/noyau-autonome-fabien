# A108 — continuité de la discussion locale

17 octobre 2026. Base consultée et ouverte par le workflow Sites : A107,
version native 22, commit `be717b2715dd19055e012d1fdb441ba9b53f90cf`.
Même site privé : `appgprj_6ac867d9813081918708ab8424b79ca3`.

## Constats et corrections

| Constat dans le code précédent | Conséquence possible | Correction |
|---|---|---|
| `commitAnswer` et les points de reprise écrivaient sans vérifier une révision de conversation | Une écriture tardive pouvait remplacer une demande ou un historique restauré si l’onglet n’avait pas encore reçu la notification | Révision monotone vérifiée dans la transaction ; chaque restauration l’incrémente, même pour un ancien fichier ou un contenu identique |
| La réponse réécrivait la mémoire de méthodes lue avant le calcul | Une méthode ajoutée entre-temps pouvait disparaître | Lecture de la mémoire actuelle et mise à jour du compteur d’utilisation dans la même transaction que la réponse |
| Les réponses locales s’ajoutaient sans plafond ; les orientations toléraient 50 000 messages sans limite d’octets dédiée | Croissance du dialogue, copies et sauvegardes de plus en plus coûteuses | Nouveaux échanges limités à 1 000 messages et 2 Mio UTF-8 ; contrôle et réserve pour la réponse avant le lancement du Worker |

`noyau-dialogue-store.js` centralise ces écritures. Dialogue, demande terminée,
mémoire actualisée et révision sont validés et enregistrés atomiquement, puis
relus. Les points de reprise ne sont acquittés qu’après cette vérification.
Un arrêt intervenant avant la mutation l’annule. Aucun nouvel essai automatique.
La réservation de taille est prudente : elle prévoit l’échappement JSON d’une
réponse de 12 000 caractères et peut bloquer un calcul un peu avant les 2 Mio.

Les échanges déjà plus nombreux restent lisibles et exportables dans les
limites du format de sauvegarde existant. Aucune purge, synthèse destructrice,
suppression de mémoire ou modification de cache de modèle. Au plafond, la
discussion refuse les ajouts ; elle ne crée pas automatiquement une nouvelle
archive pour contourner la borne. Le classement manuel/rotation de l’ancien
historique reste à concevoir avant un usage intensif au-delà de cette limite.

## Vérifications réalisées

- `qa/a108-conversation.json` : **35/35** contrôles. Gestionnaires et modules
  réels, IndexedDB/DOM/Worker simulés. Cas : historique plein, taille UTF-8,
  brouillon conservé, échec de quota, réponse et checkpoint après restauration,
  même contenu restauré, arrêt avant écriture, méthode ajoutée pendant calcul,
  sauvegarde ancienne, retour arrière, compteur maximal, checkpoint puis réponse,
  restauration avec étude, dossier, document et méthodes.
- `qa/a108-shell.json` : **4/4** contrôles. Nouvel asset disponible, fichiers
  cohérents, ouverture hors ligne simulée, mise à jour interrompue et conservation
  des caches de modèles. Les marqueurs de l’interface passent à A108.
- Syntaxe JavaScript et `git diff --check` contrôlés ; compilation et paquet de
  production préparés par le workflow Sites. Le résultat natif de déploiement
  fait foi pour la publication, pas ce fichier.

Pas de navigateur rendu ni d’iPhone physique disponibles pour ces vérifications.
Pas de nouvelle inférence réelle, de mesure de batterie/température, de séance
réelle de trente minutes ou de preuve de progression du modèle. Ces tests ne
garantissent pas l’absence de tous les bugs.

## État du produit après cet audit

L’interface principale reste une conversation. Cette livraison ne rajoute ni
onglet ni bouton de test ; les précisions de capacité restent dans l’espace
local avancé. Les projets photo, le mode étudiant et les caches de poids sont
conservés. La transaction de restauration continue de préserver les révisions
propres aux projets, documents, recherches et études.

Le mode étudiant relu conserve ses limites : 1–30 minutes, 12 étapes, 24 appels,
6 démarrages par séance, 20 séances et 2 Mio. Il utilise les poids déjà installés,
s’arrête si la page est cachée et ne reprend que sur demande. Son fonctionnement
n’a pas été modifié ici. Une méthode mémorisée n’est pas un poids entraîné.

Contrôle actuel de configuration : OpenAI Developers est disponible, mais aucun
`OPENAI_API_KEY` utilisable n’a été trouvé dans l’environnement de travail ni
dans la configuration du site (révision 0, moteur image désactivé). Aucun secret
n’a été créé ni utilisé ; aucun appel image facturable n’a été lancé. L’audit
A108 a donc porté sur les composants locaux indépendants de l’API. Le connecteur
image A107 et le pilote d’entraînement GPU n’ont pas été modifiés ni exécutés.

## Prochaines actions concrètes

1. Vérifier sur l’iPhone une sauvegarde, une fermeture/réouverture et la reprise
   d’une séance courte ; garder une copie dans Fichiers. Le site ne peut pas
   certifier l’enregistrement effectif hors du navigateur.
2. Traiter les sauvegardes complètes volumineuses : le plafond global reste
   40 Mio ; cet audit ne borne pas toutes les données historiques de tous les
   modules et ne fournit pas encore de sauvegarde multipartie.
3. Pour l’image IA réelle : décision explicite de création/utilisation de clé
   via OpenAI Developers, budget API, accès au modèle puis un essai mesuré avant
   toute offre commerciale de génération. Le crédit ChatGPT ne démontre pas à
   lui seul un budget API utilisable par le site.
4. Pour modifier des poids : vérifier les fichiers du modèle de base et les
   dépendances, disposer du matériel autorisé, exécuter le pilote puis comparer
   sur des cas réservés. Aucun gain n’est acquis avant cette mesure.

Le service de présentation à partir de photos peut toujours être accompagné
manuellement. L’autonomie générale, la vidéo, le partage de GPU et la qualité
équivalente à un grand modèle ne sont pas établis par cette livraison.

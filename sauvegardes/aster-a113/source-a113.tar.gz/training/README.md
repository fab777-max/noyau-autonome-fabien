# A107 — pilote de modification de poids, préparé mais non exécuté

Le site prépare des exemples **fictifs relus individuellement** dans le bilan
d’étude. Il ne télécharge ni n’entraîne un nouveau modèle. Les exercices
`evaluation-*` sont exclusivement dans `holdout`. L’exemple `study-*-5` de
chaque famille est réservé à la validation. Les autres cas peuvent entraîner
un adaptateur seulement après sélection explicite. Le petit jeu synthétique
ne prouve pas une amélioration générale. Une note de séance ne vaut pas
consentement pour chaque réponse.

`python training/pilot.py chemin/aster-exemples-relus.json` vérifie le format,
les corrigés exacts, empreintes, doublons, consentements et séparations. Cette
commande utilise seulement la bibliothèque standard et ne lance aucun modèle.

Le chemin `--train` est un **candidat de code non éprouvé sur GPU**. Il exige
PyTorch, Transformers et PEFT installés dans un environnement dédié, une
version compatible vérifiée, un GPU CUDA disponible, une copie locale
Safetensors du modèle Qwen2.5 0.5B/1.5B et sa révision amont immuable.
Le cache GGUF de l’iPhone ne suffit pas. Les fichiers ne sont jamais téléchargés
par ce script (`local_files_only`, mode hors ligne, pas de code distant).
Au moins 12 exemples d’entraînement, trois familles et deux de validation
sont requis. Exemple de commande à adapter et **à ne lancer qu’après accès et
budget de calcul autorisés** :

    python training/pilot.py exemples.json --train --model /modele/local \
      --base-revision <revision-amont-complete> --output /resultats/nouveau-pilote \
      --minutes 30 --steps 40

Seuls les poids LoRA q_proj/v_proj sont optimisés (rang 8). Les poids de base
restent figés ; pas de fusion, de remplacement du modèle servi ni d’envoi à
l’iPhone. La perte est masquée sur les consignes et calculée sur la réponse.
Les paquets trop longs sont refusés, jamais coupés. La baseline et le candidat
sont évalués sans mémoire sur les mêmes 24 cas réservés. Changements des
paramètres, régressions, exactitude, perte et durée figurent dans le rapport.
Un candidat reste à relire même s’il passe les conditions numériques.

La durée couvre chargement, mesures, optimisation et vérification. Le contrôle
du budget est coopératif entre opérations : un noyau GPU déjà lancé peut le
dépasser. Les checkpoints sont des adaptateurs partiels ; **la reprise exacte
de l’optimiseur n’est pas implémentée**. Un arrêt ne promeut rien. Une reprise
devra conserver budget et état d’optimiseur avant d’être proposée à Fabien.

Limites restantes : qualifier les versions des bibliothèques et le GPU,
vérifier l’origine et les empreintes du modèle téléchargé, enrichir les données
au-delà de ces exercices, tester les quatre conditions original/mémoire/
entraîné/entraîné+mémoire, quantifier et revalider pour le moteur du téléphone.
L’entraînement d’images LoRA nécessite un modèle et des données d’image
distincts. Ce pilote textuel ne peut pas apprendre à générer des pixels.

Références primaires :
- https://huggingface.co/docs/peft/main/en/developer_guides/lora
- https://huggingface.co/docs/transformers/main/en/chat_templating
- https://github.com/ggml-org/llama.cpp/blob/master/tools/export-lora/README.md

"""Offline, opt-in text LoRA pilot. Nothing here runs in the deployed website.

Default: validate an explicitly reviewed synthetic bundle. --train additionally
requires a local safetensors base, installed libraries and an available CUDA GPU.
No model download, remote code, automatic promotion, or change to the phone cache.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def validate_bundle(path):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Bundle exceeds 2 MiB")
    data = json.loads(path.read_text())
    if data.get("schema") != "aster-training-bundle-v1" or data.get("suite") != "aster-practical-v1":
        raise ValueError("Unknown dataset schema/suite")
    catalog = json.loads(Path(__file__).with_name("curriculum-v1.json").read_text())
    known = {row["caseId"]: row for row in catalog}
    groups = {"train": [], "validation": [], "holdout": []}
    seen, contents = set(), set()
    rows = data.get("examples", []) + data.get("holdout", [])
    if not 25 <= len(rows) <= 60:
        raise ValueError("Expected 1–36 selected examples and 24 held-out cases")
    for row in rows:
        case = known.get(row.get("caseId"))
        if not case or row["caseId"] in seen:
            raise ValueError("Unknown or duplicate case")
        seen.add(row["caseId"])
        split = case["split"]
        if row.get("split") != split or row.get("family") != case["family"] or row.get("messages") != case["messages"]:
            raise ValueError("Changed correction or train/evaluation leakage")
        fingerprint = digest(row["messages"])
        if fingerprint != row.get("contentSha256") or fingerprint in contents:
            raise ValueError("Dataset fingerprint mismatch or duplicate text")
        contents.add(fingerprint)
        if split != "holdout" and (row.get("trainingConsent") is not True or not row.get("reviewedAt") or not row.get("sessionId")):
            raise ValueError("Individual review and consent required")
        groups[split].append(row)
    if len(groups["holdout"]) != 24:
        raise ValueError("The 24 held-out cases must remain intact")
    return groups, hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    temp.replace(path)


def train(args, groups, bundle_hash):
    if len(groups["train"]) < 12 or len(groups["validation"]) < 2:
        raise ValueError("Pilot requires at least 12 training and 2 validation examples")
    if len({r["family"] for r in groups["train"]}) < 3:
        raise ValueError("Pilot requires at least three task families")
    if not args.model or not args.output or not re.fullmatch(r"[a-f0-9]{40}", args.base_revision or ""):
        raise ValueError("A local model path, immutable upstream revision and NEW output directory are required")
    base, out = Path(args.model).resolve(), Path(args.output).resolve()
    if not base.is_dir() or not list(base.glob("*.safetensors")) or not (base / "config.json").is_file():
        raise ValueError("A local Transformers safetensors model is required; a cached GGUF is not trainable here")
    if out.exists() or base == out or base in out.parents:
        raise ValueError("Use a new output directory outside the original model")
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, get_peft_model, TaskType
    if not torch.cuda.is_available():
        raise RuntimeError("No available CUDA GPU; no CPU fallback or download will be started")
    torch.manual_seed(107)
    started = time.monotonic()
    def remaining():
        return args.minutes * 60 - (time.monotonic() - started)
    tokenizer = AutoTokenizer.from_pretrained(base, local_files_only=True, trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(base, local_files_only=True, trust_remote_code=False, use_safetensors=True, torch_dtype=torch.float32)
    if model.config.model_type != "qwen2" or not 300_000_000 <= model.num_parameters() <= 2_000_000_000:
        raise ValueError("This pilot supports only the Qwen2/Qwen2.5 text family, 0.3–2B parameters")
    model.to("cuda")
    # Build every packet first. No truncation; loss is computed only on the answer.
    packets = {}
    for row in sum(groups.values(), []):
        prefix = tokenizer.apply_chat_template(row["messages"][:-1], tokenize=True, add_generation_prompt=True)
        full = tokenizer.apply_chat_template(row["messages"], tokenize=True, add_generation_prompt=False)
        if full[:len(prefix)] != prefix or len(full) > 384 or len(full) <= len(prefix):
            raise ValueError("Chat-template boundary or 384-token budget mismatch")
        packets[row["caseId"]] = (full, len(prefix), prefix)
    out.mkdir(parents=True)
    report = {"schema": "aster-lora-pilot-v1", "status": "running", "bundleSha256": bundle_hash,
              "baseRevisionDeclared": args.base_revision, "basePath": str(base), "steps": 0,
              "seed": 107, "budgetSeconds": args.minutes * 60, "weightsChanged": False,
              "promoted": False, "scope": "Small synthetic text pilot; no image capability or general quality claim"}
    atomic_json(out / "report.json", report)
    def check_time():
        if remaining() <= 0:
            raise TimeoutError("Time budget exhausted between operations")
    def normalize(s):
        return re.sub(r"\s*,\s*", ",", s.strip().lower().rstrip(".!"))
    def evaluate():
        model.eval()
        scores = []
        with torch.no_grad():
            for row in groups["holdout"]:
                check_time()
                prefix = packets[row["caseId"]][2]
                inputs = torch.tensor([prefix], device="cuda")
                generated = model.generate(inputs, attention_mask=torch.ones_like(inputs), max_new_tokens=64, do_sample=False, pad_token_id=tokenizer.eos_token_id)
                answer = tokenizer.decode(generated[0, len(prefix):], skip_special_tokens=True)
                scores.append({"caseId": row["caseId"], "answer": answer, "correct": normalize(answer) == normalize(row["messages"][-1]["content"])})
        return scores
    def loss(row):
        full, boundary, _ = packets[row["caseId"]]
        ids = torch.tensor([full], device="cuda")
        labels = ids.clone(); labels[:, :boundary] = -100
        return model(input_ids=ids, attention_mask=torch.ones_like(ids), labels=labels).loss
    def validation_loss():
        model.eval()
        with torch.no_grad():
            values = []
            for row in groups["validation"]:
                check_time(); values.append(float(loss(row)))
        return sum(values) / len(values)
    try:
        report["baseline"] = evaluate()
        report["baselineValidationLoss"] = validation_loss()
        model = get_peft_model(model, LoraConfig(task_type=TaskType.CAUSAL_LM, r=8, lora_alpha=16, lora_dropout=0, target_modules=["q_proj", "v_proj"], bias="none"))
        params = {n: p for n, p in model.named_parameters() if p.requires_grad}
        if not params or any("lora_" not in n for n in params):
            raise RuntimeError("Only LoRA parameters may be trainable")
        before = {n: p.detach().cpu().clone() for n, p in params.items()}
        optimizer = torch.optim.AdamW(params.values(), lr=1e-4)
        model.config.use_cache = False
        for step in range(args.steps):
            check_time(); model.train(); optimizer.zero_grad(set_to_none=True)
            value = loss(groups["train"][step % len(groups["train"])] )
            if not torch.isfinite(value):
                raise RuntimeError("Non-finite loss; candidate will not be promoted")
            value.backward(); torch.nn.utils.clip_grad_norm_(list(params.values()), 1.0); optimizer.step()
            report["steps"] = step + 1
            report["lastTrainingLoss"] = float(value.detach())
            report["weightsChanged"] = any(not torch.equal(before[n], p.detach().cpu()) for n, p in params.items())
            if (step + 1) % 10 == 0:
                model.save_pretrained(out / "checkpoint", safe_serialization=True)
                atomic_json(out / "report.json", report)
        model.save_pretrained(out / "candidate", safe_serialization=True)
        report["candidateValidationLoss"] = validation_loss()
        report["candidate"] = evaluate()
        b, c = report["baseline"], report["candidate"]
        report["regressions"] = [x["caseId"] for x, y in zip(b, c) if x["correct"] and not y["correct"]]
        report["reviewEligible"] = bool(report["weightsChanged"] and not report["regressions"] and sum(x["correct"] for x in c) > sum(x["correct"] for x in b) and report["candidateValidationLoss"] <= report["baselineValidationLoss"])
        report["status"] = "needs_human_review" if report["reviewEligible"] else "rejected_or_inconclusive"
    except BaseException as error:
        report["status"] = "interrupted"
        report["error"] = str(error)[:400]
        raise
    finally:
        report["elapsedSeconds"] = round(time.monotonic() - started, 2)
        atomic_json(out / "report.json", report)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("bundle")
    p.add_argument("--train", action="store_true")
    p.add_argument("--model")
    p.add_argument("--base-revision")
    p.add_argument("--output")
    p.add_argument("--minutes", type=int, default=30, choices=range(1, 31))
    p.add_argument("--steps", type=int, default=40, choices=range(1, 101))
    args = p.parse_args()
    groups, sha = validate_bundle(args.bundle)
    print(json.dumps({"validated": True, "counts": {k: len(v) for k, v in groups.items()}, "bundleSha256": sha, "trainingRequested": args.train}))
    if args.train:
        train(args, groups, sha)


if __name__ == "__main__":
    main()

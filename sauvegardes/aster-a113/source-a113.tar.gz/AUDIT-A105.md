# Audit A105 — photo modifiée, mémoire et progrès réel

17 octobre 2026. Base examinée : A104, version Sites 19, commit `fea6031d43af545c9b81a3c04f575e5d17155d09`. Même site privé et même origine. Ce document décrit la source livrable ; seul le résultat de publication Sites prouve sa mise en ligne.

## Réponses vérifiées

| Question de Fabien | Constat dans le code | Résultat A105 |
|---|---|---|
| Une image envoyée est-elle modifiée ? | A104 réduit la photo importée puis la place dans deux compositions. Le modèle de texte ne reçoit aucun pixel. | De vraies retouches de pixels sont ajoutées : luminosité, contraste, noir et blanc, rotation et carré centré. PNG de la photo seule récupérable. |
| Peut-elle changer un décor ou supprimer un objet ? | Aucun moteur d’image génératif, modèle de vision ou service d’inférence image n’est connecté. | Non. Les commandes détectées hors capacité sont expliquées et conservées dans le brouillon, sans devenir des faits du projet. La détection reste une grammaire limitée. |
| Apprend-elle en restant ouverte ? | Pas d’optimiseur, de rétropropagation ou de mise à jour des poids dans ce parcours. | Non. Les demandes calculent un résultat ; attendre ne déclenche aucun entraînement. |
| La mémoire améliore-t-elle les réponses ? | `noyau-learning.js` conserve au plus 64 méthodes approuvées ; `noyau-local.js` peut en rappeler deux dans l’ancien dialogue. | C’est une réutilisation de contexte. Le rédacteur du studio A104 n’injecte pas ces méthodes. Aucun gain de qualité autonome n’a été mesuré. |
| Ralentir transforme-t-il le petit modèle en grand modèle ? | Les tâches de rédaction ont des étapes et des points de reprise ; le modèle, ses poids et le contexte restent bornés. | Non. Le découpage rend certains travaux réalisables et reprenables ; il n’ajoute ni capacités générales ni paramètres. |

## Modification concrète

`aster-photo-core.js` interprète des commandes explicites, valide les réglages et prépare une nouvelle version du dossier. Exemples : « Éclaircis la photo », « Mets la photo 2 en noir et blanc », « Recadre la photo au carré », « Tourne la photo à droite », « Rétablis la photo d’origine ». Ce traitement déterministe n’est pas présenté comme du raisonnement ou de la vision.

`noyau-workshop-render.js` applique ces réglages avec Canvas. La copie importée reste intacte dans le dossier. Attention : l’import existant réduit déjà le fichier à 1 600 pixels maximum et le convertit en JPEG ; cette copie n’est donc pas le fichier original pleine résolution de l’iPhone. L’export PNG ne recrée pas les détails perdus lors de cet import.

La conversation montre le rendu et un lien pour télécharger la photo seule, avec comparaison repliable à la copie importée. La couverture des deux visuels et les photos de la fiche HTML utilisent aussi les retouches. Une fiche qui reçoit des réglages non matérialisés est refusée, afin de ne pas exporter silencieusement la photo non retouchée.

## Mémoire, calcul et reprise

- Chaque photo conserve une seule copie JPEG importée et, si nécessaire, six champs de réglage strictement validés. Les PNG sont temporaires et ne sont pas ajoutés à IndexedDB. Les anciens liens Blob sont révoqués. Cent changements de réglage ne créent pas cent copies d’image.
- Répéter « Éclaircis la photo » applique le même niveau : cela n’ajoute ni nouvelle photo ni nouvelle paire de messages. Une rotation répétée reste une action successive intentionnelle.
- La luminosité et le contraste sont bornés, les rotations limitées aux quarts de tour. Le traitement des pixels cède la main toutes les 32 lignes et peut être annulé. Cela ne constitue pas une mesure de température, de batterie ou de performances iPhone.
- L’écriture transactionnelle et sa relecture précèdent le message de réussite. Les sauvegardes privées et complètes conservent la source et ses réglages. Les imports privés réinitialisent la validation de livraison.
- Une retouche invalide la précédente validation et les liens du pack. Une restauration dans un autre onglet bloque les anciennes écritures, interrompt le rendu et retire les téléchargements obsolètes.
- Les messages restent bornés à 120 par dossier, avec refus explicite quand ils sont pleins. Les six dossiers, six photos par dossier et vingt travaux de rédaction par dossier restent les limites existantes. Aucun historique n’est effacé automatiquement.
- Limites non résolues : croissance de l’ancien dialogue, sauvegarde complète limitée à 40 Mio, import privé limité à 8 Mio. Ne pas annoncer que toute la mémoire est compactée ou protégée contre toute perte.

## Preuves et limites de la recette

- `qa/a105-studio.json` : 49 scénarios passent. Modules et gestionnaires UI réels, DOM/IndexedDB/modèle simulés, PNG réels produits par Canvas natif Node. Vérifie pixels, dimensions, retour à la source, répétitions, sélection de photo, échec de stockage, reprise, sauvegardes, commandes hors capacité et cohérence des fichiers livrés.
- `qa/a105-shell.json` : 4 contrôles passent. Nouveau module présent hors ligne, copie interrompue refusée, anciens caches de modèles conservés.
- `qa/a105-structure.json` : structure des quatre pages, dépendances locales, syntaxe des fichiers JavaScript modifiés et intégrité du ZIP.
- Les premiers échecs des nouveaux scénarios provenaient de deux défauts des fixtures : une photo partagée modifiée par un test d’import invalide et un générateur d’URL de test réutilisant ses identifiants. Les fixtures ont été isolées et les URL rendues uniques avant de rejouer la suite. La restauration a aussi reçu un contrôle dédié.
- Aucune photo privée du téléphone n’a été lue. Aucun Safari réel, iPhone physique, moteur d’image génératif, résultat réel du LLM ou fonctionnement sur plusieurs heures n’a été testé ici. Les contrôles logiciels ne prouvent pas ces points.

## Recherche ciblée et prochain résultat utile

Sources primaires consultées le 17 octobre 2026 :

1. [OpenAI — Image generation / edits](https://developers.openai.com/api/docs/guides/image-generation) décrit une API capable de modifier une image avec une consigne et, selon le parcours, un masque. C’est une voie vers le changement de décor ou la suppression d’un objet, pas une capacité actuellement connectée au site. Cette documentation ne prouve aucun crédit API ni droit d’accès disponible sur le compte de Fabien.
2. [Qwen — Qwen-Image-Edit-2511](https://huggingface.co/Qwen/Qwen-Image-Edit-2511) présente un modèle de retouche sous licence Apache 2.0 et un exemple Diffusers/PyTorch en BF16 sur CUDA. Candidat à étudier sur serveur équipé ; aucun chemin de production Safari/iPhone ni mesure matérielle de ce projet n’a été établi. Ce modèle est distinct du petit modèle de texte installé.
3. [MDN — Canvas getImageData](https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/getImageData) documente l’accès aux pixels retenu pour la retouche simple sans nouveau téléchargement de modèle.

Priorité produit : vérifier un vrai dossier autorisé sur l’iPhone, récupérer sa photo et son pack, puis mesurer le temps de correction humaine et l’utilité du résultat. Le service démontrable est une préparation accompagnée de photos et de présentations. La demande commerciale et les revenus restent à valider.

Pour une étape générative : choisir un moteur et un hébergement réellement accessibles, fixer une limite de coût par tâche, obtenir l’accord explicite pour transmettre les photos, préserver la source, enregistrer chaque résultat et traiter les erreurs sans relances illimitées. Aucun paiement ou transfert d’image n’est activé par A105.

Pour mesurer un apprentissage utile : constituer des exemples autorisés avec résultats attendus, séparer les tâches de validation des exemples mémorisés et comparer avec/sans mémoire sur des tâches nouvelles. Mesurer exactitude, retouches humaines, temps et coût ; ne promouvoir une méthode qu’après validation. Les corrections ne doivent pas être recyclées automatiquement en entraînement général. Le partage de calcul et l’entraînement distribué restent des chantiers séparés.

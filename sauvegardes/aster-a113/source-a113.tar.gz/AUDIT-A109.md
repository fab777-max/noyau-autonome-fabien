# A109 — dialogue général dans l’accueil privé

18 octobre 2026. Fabien a validé le plan général et demande une version à essayer,
avec conversation personnelle, mémoire limitée et travail utile pendant l’attente.
Base ouverte et vérifiée : A108, version native 23,
`dc317c23134621be97b67618ba74d4f053333c90`.
Site inchangé : `appgprj_6ac867d9813081918708ab8424b79ca3`, accès propriétaire seul.
Le résultat natif Sites fait foi pour la publication.

## Livraison concrète

- Le champ d’accueil transmet maintenant les questions ordinaires au modèle local.
  Une présentation démarre explicitement par « Prépare une présentation » ou
  « Nouveau projet ». Les corrections de champs déjà demandées restent prioritaires.
  Une question incidente quitte la saisie des faits sans les remplacer.
- Même historique général que l’espace avancé, même base IndexedDB, même révision
  de conversation. Aucun nouveau dépôt, site, modèle ou copie de l’historique.
  Les 40 derniers messages sont affichés ; les précédents restent accessibles.
- « Retiens que… », « Que sais-tu de moi ? » et « Oublie… » fonctionnent même
  sans modèle. Les 32 notes explicites existantes sont réutilisées, éditables et
  oubliables, sans modifier les anciens fils personnels. Note et confirmation sont
  enregistrées atomiquement. Les dialogues seuls ne deviennent pas des notes.
- Pour répondre, sélection d’au plus six messages récents, trois notes pertinentes
  et deux méthodes validées. Les méthodes utilisées sont comptées au commit depuis
  leur état courant. Aucune ingestion automatique de données.
- Une option permet la recherche dans les documents locaux déjà importés. Recherche
  lexicale, deux extraits au plus, nom et lignes disponibles. Aucune recherche web,
  lecture de photo ou lecture exhaustive de fichier n’est prétendue. Sans passage
  correspondant, réponse explicite sans appel du modèle.
- Les demandes de comparaison, analyse ou plan, ainsi que le choix « Prendre le
  temps », utilisent le circuit existant : plan court, réponse, au plus une correction
  de forme. Pour ce nouveau parcours, le plan et le texte à corriger sont obligatoires
  dans l’étape suivante ; ils ne peuvent plus être évincés silencieusement.
- Temps écoulé réel, phase réellement reçue du Worker, pause et reprise manuelle.
  Fourchette indicative seulement après deux réponses comparables terminées sans
  reprise, avec le même modèle et sa même révision. Aucun pourcentage fictif, délai
  garanti, boucle pour occuper le temps ou nouveau score de qualité.
- Le modèle déjà installé est réutilisé. S’il manque, la demande reste enregistrée et
  un bouton propose explicitement son installation, avec la taille affichée. Les
  segments vérifiés et le mécanisme de reprise du téléchargement restent inchangés.
- Les présentations, retouches, ZIP, rédaction et étude sont conservés. Le moteur
  d’images connecté reste soumis à sa configuration et à son budget distincts.

## Bornes et reprise

Un message général est limité à 1 000 caractères ; une sortie à 256 jetons. Le
profil prudent reste un fil, batch 64, contexte 1 024, pauses coopératives. L’ancien
dialogue avancé conserve son profil existant. La demande obligatoire trop longue
est refusée entière ; les échanges/extraits facultatifs retirés pour tenir dans le
contexte sont signalés. Contexte plus grand et recherche locale ne changent pas
le nombre de paramètres ni les poids du modèle.

Un lancement est limité à dix minutes, chargement inclus. Il s’arrête en cas de
pause, page cachée, erreur, absence de stockage confirmé ou expiration. Une reprise
est un nouveau lancement explicite, réutilisant les étapes durables compatibles.
Un arrêt brutal ne permet pas de mesurer les secondes non enregistrées : la durée
conservée n’est donc pas une mesure garantie de tout le travail avant un crash.
Le Worker est libéré à la fin ; ses poids sont relus localement au prochain envoi.

Chaque checkpoint est acquitté après écriture et relecture. Réponse et achèvement
sont atomiques. La révision protège contre un résultat tardif après restauration.
Une nouvelle demande archive l’ancienne, avec un plafond de 50, jamais une purge.
Le dialogue reste limité à 1 000 messages et 2 Mio ; l’ancien historique plus gros
reste lisible. Les notes personnelles gardent leurs limites existantes. Modifier
une préférence invalide le contexte et les checkpoints de la demande en pause.

La sauvegarde complète inclut notes, historique et reprise ; les notes sont aussi
validées avant restauration. La copie d’une présentation seule ne remplace pas
cette sauvegarde générale. Aucun cache de modèle ni donnée utilisateur n’a été
effacé. La mise à jour hors ligne conserve le processus existant : interface copiée,
puis proposition de réouverture ; aucun rechargement imposé pendant le travail.

## Vérifications

126 contrôles logiciels passants, zéro échec dans les rapports conservés :

| Rapport | Cas | Couverture |
|---|---:|---|
| `qa/a109-conversation.json` | 25 | Intention, notes, limites, transactions, protocole, pause, contexte, circuit et reprise |
| `qa/a109-preserved-studio.json` | 62 | Accueil général intégré et parcours existants photo/présentation/étude/rédaction/sauvegarde |
| `qa/a109-shared-dialogue.json` | 35 | Conversation avancée, révision de restauration et écritures tardives |
| `qa/a109-shell.json` | 4 | Assets, copie hors ligne, interruption, conservation des caches de modèles |

Les modules et gestionnaires sont réels ; les PNG de régression utilisent Canvas
natif Node. IndexedDB, DOM, réseau, Worker, horloge et inférence sont simulés selon
les suites. Pas de contrôle navigateur rendu : contrôle navigateur requis absent
dans cet environnement. Pas de test iPhone/Safari, poids disponibles pour une
inférence réelle ici, mesure de qualité, batterie, température ou vitesse réelle.
La compilation et le paquet de publication sont produits par le workflow Sites.

## Limites et suite

Cette livraison est la première tranche conversation/continuité du plan général,
avec les protections mémoire/temps nécessaires. Elle n’achève pas les 96 actions.
Le contrôle de forme ne prouve ni la vérité des faits ni une qualité supérieure à
un grand modèle. L’apprentissage actuel consiste en notes explicites et méthodes
validées ; aucun entraînement de poids n’a été exécuté.

Restent notamment : exécution générale de projets avec outils vérifiés, recherche
web autorisée, import direct de documents dans le même échange, qualification
iPhone, qualité mesurée sur tâches inédites, mémoire longue mieux sélectionnée,
moteur image réellement activé, entraînement GPU qualifié, équipes, réseau de
calcul et points. Aucun appel payant, publication publique, contact extérieur ou
nouvelle automatisation n’a été lancé.

Essai utilisateur utile : une préférence → deux questions de suivi → rechargement
→ rappel ; puis une demande approfondie → pause après le plan → reprise → lecture
du résultat. Vérifier une photo et sa livraison habituelle. Noter ce qui est juste,
faux ou peu clair avant d’augmenter le contexte ou d’ajouter de nouveaux moteurs.

import shell from "../public/index.html?raw";
export function GET() {
  return new Response(shell, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache", "x-content-type-options": "nosniff" } });
}

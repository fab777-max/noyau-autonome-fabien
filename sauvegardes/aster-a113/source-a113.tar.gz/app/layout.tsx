import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Noyau — Atelier de Fabien",
  description: "Atelier local et suivi privé des améliorations de Noyau.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="antialiased">{children}</body>
    </html>
  );
}

import { env } from "cloudflare:workers";
import { mcpAPI } from "../../server/tasks.mjs";
export const dynamic = "force-dynamic";
export function POST(request: Request) { return mcpAPI(request, env.DB); }
export function GET() { return new Response(null, { status: 405, headers: { Allow: "POST", "Cache-Control": "no-store" } }); }
export function DELETE() { return new Response(null, { status: 405, headers: { Allow: "POST", "Cache-Control": "no-store" } }); }

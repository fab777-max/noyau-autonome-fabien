import { env } from "cloudflare:workers";
import { browserAPI } from "../../../server/tasks.mjs";
export const dynamic = "force-dynamic";
export function GET(request: Request) { return browserAPI(request, env.DB); }
export function POST(request: Request) { return browserAPI(request, env.DB); }

import { env } from 'cloudflare:workers';
import { imageAPI } from '../../../server/image-jobs.mjs';
export const dynamic = 'force-dynamic';
export function GET(request: Request) { return imageAPI(request, env); }
export function POST(request: Request) { return imageAPI(request, env); }

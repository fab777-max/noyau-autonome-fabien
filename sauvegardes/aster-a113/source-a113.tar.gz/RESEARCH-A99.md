# Aster A99 — research decision, 15 October 2026

## Selected improvement

Make existing client briefs and notes useful immediately: import bounded text, find an exact passage, inspect its origin, and optionally attach it to one reviewed project step. The search itself works without loading the local LLM. It supports preparing grounded content briefs and checking facts, but does not make the small model's eventual answer reliable by itself.

The existing workshop still creates visual layouts from supplied photos/facts, texts and export packs. A99 does not add image synthesis, video generation, a paid API, autonomous customer replies or weight training. It does not establish a market willingness to pay; that still needs a real useful deliverable and customer feedback.

## Sources consulted and their actual implications

| Primary source | Finding used | A99 decision |
| --- | --- | --- |
| [MiniSearch repository](https://github.com/lucaong/minisearch) | Browser-side, in-memory full-text retrieval can work offline with a small footprint. | Use a bounded local lexical approach. MiniSearch code/package was not imported; A99's small matcher is its own implementation. |
| [Anthropic, Contextual Retrieval](https://www.anthropic.com/engineering/contextual-retrieval), 19 September 2024 | Context and lexical/semantic retrieval can complement each other; retrieval quality needs evaluation. | Preserve original text and source provenance. A99 does not implement the full hybrid method and claims none of its published benchmark gains. |
| [Anthropic, Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents), 9 January 2026 | Evaluate actual outcomes with appropriate deterministic and human judgments. | Check exact excerpts, persistence, interruption and refusal behavior; keep human approval of LLM drafts. Software checks do not prove model intelligence. |
| [wllama releases](https://github.com/ngxson/wllama/releases) and [official Safari compatibility notes](https://github.com/ngxson/wllama/blob/master/compat/README.md) | The newer v3 series has a Safari compatibility path with different WASM assumptions and costs. | Retain the installed 2.3.7 runtime/model for this change. A newer engine alone does not establish an improvement on this iPhone. A migration needs separate device evidence. |
| [Google, Gemma 3 270M announcement](https://developers.googleblog.com/introducing-gemma-3-270m/), 14 August 2025 | A small model can be useful for task-specific adaptation; its size is not proof of better general-purpose results. | Do not replace Qwen or download another model without measured benefit for the actual task. |
| [French government business-search API](https://www.data.gouv.fr/dataservices/api-recherche-dentreprises) | A possible official source for a later business-information workflow. | Research lead only: no connector, lead collection, outreach or data feed was added. |

## Scope and known limits

- TXT/MD UTF-8 and pasted text only; no PDF parser, OCR or image analysis.
- Up to 12 documents / 144,000 total characters, 24,000 each. Search returns up to six exact excerpts of at most 360 characters with accent/case normalization. Ranking is a relevance heuristic, not a confidence percentage.
- Exact words are needed; synonyms and differently phrased concepts can be missed. Selecting a matching excerpt does not establish the truth of its content.
- An explicitly attached excerpt consumes the existing project context budget. If it does not fit, the operation refuses without silent truncation or another automatic attempt.
- Device storage is not an external backup. The full export now includes documents, draft and project source snapshots, but the user must save the file outside the browser.
- Safari/iPhone performance, actual local model responses and long-duration behavior remain unmeasured by this release. Foreground execution and human review remain necessary.

## Acceptance evidence

`qa/a99-documents.json`: 21 checks. `qa/a99-projects-regressions.json`: 38 checks. `qa/a99-recovery-regressions.json`: 10 checks. All pass using simulated browser/worker/storage environments and actual product modules. These are functional software checks, not evidence of sales readiness, phone benchmarking or autonomous learning.

Next decision should come from one real brief: can Fabien find the right fact, attach it and obtain an acceptable reviewed deliverable with less effort? If the local model fails, use the existing explicit agent handoff rather than repeated background generation.

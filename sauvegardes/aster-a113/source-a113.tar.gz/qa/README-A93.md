# A93 — atelier de réalisations et restauration

Implémentation du 15 octobre 2026, sur la base A92 `3d8b2fba145f8a26706248d61941f8221297c53b`.

## Fonctionnement livré

- L'atelier `/atelier.html` conserve au maximum six dossiers de six photos. Il produit une fiche HTML imprimable en PDF, deux PNG (1080 × 1350 et 1080 × 1920), trois textes et un ZIP contenant aussi les faits confirmés. Les originaux restent inchangés. Le PDF est obtenu par l'impression du navigateur ; ce n'est pas un export PDF binaire natif.
- Les textes de base sont composés à partir des faits saisis, sans appel au modèle. La reformulation LLM facultative utilise uniquement le modèle déjà installé, garde les tentatives et demande une adoption explicite puis une validation humaine. Le contrôle des chiffres ne certifie pas la véracité de toutes les affirmations.
- La sauvegarde complète A92/A93 se restaure après aperçu et confirmation. Les cinq magasins IndexedDB sont remplacés dans une transaction ; une copie de retour est créée dans cette même transaction. Un échec de quota annule la transaction. Les poids du modèle sont exclus.
- L'installation affiche les octets réseau et le cache disponible. Une réponse HTTP 200 à une reprise partielle provoque un arrêt ; une retransmission complète exige un nouvel appui explicite. Un cache complet ne déclenche aucun téléchargement de poids.
- Le panneau Codex prépare un fichier de demande sans données client jointes. L'exécution directe reste non connectée : hôte Codex et authentification ChatGPT manquants. Aucun accès à un forfait ou agent distant n'est simulé.

## Vérification réalisée

| Contrôle | Résultat | Portée |
|---|---|---|
| `node qa/test-a93-regression.mjs` | 59 réussis, 0 échec | Régressions moteur, cache, mémoire, verrous et contrôles de la page principale, avec doubles de test |
| `node qa/test-a93-production.mjs` | 55 réussis, 0 échec | Restauration atomique simulée, conflits de dossiers, 30 cas de données de référence, téléchargements sur 12 octets factices, parcours des gestionnaires UI, vrais rendus Canvas/ZIP |
| Archive ZIP issue du parcours UI | CRC valides, cinq fichiers attendus | Lecture indépendante par `zipfile` de Python |
| Deux images de sortie | Dimensions correctes, inspection visuelle effectuée | Photo synthétique de test, pas une prestation client |
| Entrées HTML | Identifiants uniques, scripts locaux présents | Page principale et atelier |

Les simulations ne constituent pas une validation de Safari ni du matériel. Aucun navigateur n'est disponible dans cet environnement ; aucun test physique sur l'iPhone 17 Pro Max, aucune vraie inférence du nouveau parcours LLM et aucun nouveau téléchargement de poids n'ont été effectués. Les rendus d'images ont utilisé Canvas natif sous Node. Les fichiers de sortie se régénèrent dans `qa/a93-output/`, exclu du suivi Git et de la publication.

Les nouveaux modules ont passé la vérification de syntaxe Node. Les bibliothèques, révisions et poids du modèle local existant restent inchangés. La carte A92 reste dans la page principale.

## Réception ciblée sur iPhone

1. Dans Safari, ouvrir l'atelier, saisir une vraie réalisation et importer une photo autorisée.
2. Préparer les trois textes, les relire, confirmer les droits et le contenu, puis télécharger le ZIP.
3. Vérifier l'ouverture des deux PNG, du fichier texte et de la fiche ; essayer l'impression/enregistrement en PDF.
4. Fermer puis rouvrir l'atelier : retrouver le dossier, sans calcul automatique. Exporter la sauvegarde complète avant tout essai de restauration et fermer les autres onglets Noyau.
5. La reformulation LLM est facultative : un seul essai, après installation complète confirmée depuis le Blob, suffit à vérifier ce parcours. Conserver le bilan avec durée et résultat, y compris en cas d'échec.

Le caractère commercial de l'offre et le gain de temps restent à établir sur des prestations réelles. La vidéo, la génération de nouvelles images et un agent Codex connecté ne font pas partie de cette livraison.

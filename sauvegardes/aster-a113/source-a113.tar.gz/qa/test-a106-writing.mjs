import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
import {TestDB} from './memory-double.mjs';
const root=new URL('../public/',import.meta.url),src=n=>fs.readFileSync(new URL(n,root),'utf8'),urls=new Map();
function mod(n){if(!urls.has(n))urls.set(n,'data:text/javascript;base64,'+Buffer.from(src(n).replace(/from ['"]\/([^'"?]+)(?:\?[^'"]*)?['"]/g,(_,f)=>'from '+JSON.stringify(mod(f)))).toString('base64'));return urls.get(n);}
const core=await import(mod('aster-writing-core.js')),shop=await import(mod('noyau-workshop-core.js')),store=await import(mod('noyau-workshop-store.js')),backup=await import(mod('noyau-backup.js')),studio=await import(mod('aster-studio-core.js')),learn=await import(mod('noyau-learning.js'));
const studyCases=await import(mod('aster-study-cases.js'));
const contextBudget=await import(mod('blob-context-budget.js')),cooperative=await import(mod('blob-cooperative-decode.js'));
const facts=shop.cleanFacts({business:'Atelier Démo',title:'Terrasse',details:'Pose de lames en bois. Finitions à confirmer.',city:'Vienne'}),model={id:'test-model',revision:'rev-1'};
const initial=()=>core.newWritingRun('writing-1',facts,model.id,model.revision,'2026-10-17T00:00:00Z');
const tests=[];
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.stack});process.exitCode=1;}}
function harness(options={}){
 const calls=[],saves=[],events=new Map(),timers=new Map();let tid=0,released=0,workers=0,terminated=0,cacheReads=0,current=structuredClone(options.initial||initial()),saveCount=0;
 const doc={hidden:false,addEventListener:(k,f)=>events.set(k,f),removeEventListener:(k,f)=>{if(events.get(k)===f)events.delete(k);}};
 class Worker{
  constructor(){workers++;this.dead=false;}
  terminate(){this.dead=true;terminated++;}
  postMessage(m){calls.push(m);if(options.throwAt===m.type)throw Error('Canal Worker indisponible');queueMicrotask(()=>{if(this.dead)return;
   if(m.type==='HELLO')this.onmessage({data:{type:'HELLO_ACK',nonce:m.nonce,protocol:'ENGINE',writingProtocol:options.oldWorker?'old':core.WRITING_PROTOCOL,model:model.id,revision:model.revision}});
   else if(m.type==='LOAD')this.onmessage({data:{type:'READY',model:model.id,revision:model.revision,actual:{n_ctx:1024,n_batch:64,n_threads:1,sliceMs:25,pauseMs:50,...options.actual}}});
   else if(m.type==='STUDIO_COMPOSE'){
    if(options.hideAt===m.stepId){doc.hidden=true;events.get('visibilitychange')?.();return;}
    if(options.cancelAt===m.stepId){options.controller.abort();return;}
    if(options.timeoutAt===m.stepId){[...timers.values()].find(x=>x.ms===core.WRITING_LIMITS.stepMs)?.fn();return;}
    if(options.budgetAt===m.stepId){[...timers.values()].find(x=>x.ms===core.WRITING_LIMITS.sessionMs)?.fn();return;}
    if(options.failAt===m.stepId){this.onmessage({data:{type:'ERROR',message:'Échec simulé'}});return;}
    // A result from an older request must not settle the current one.
    this.onmessage({data:{type:'STUDIO_COMPOSED',requestId:'stale',answer:'Faux 999',outputTokens:2,elapsedMs:3}});
    this.onmessage({data:{type:'STUDIO_COMPOSED',requestId:m.requestId,answer:options.answer||({presentation:'Atelier Démo présente une terrasse à Vienne. Finitions à confirmer.',publication:'Découvrez cette pose de lames en bois à Vienne. Les finitions restent à confirmer.',message:'Pose de lames en bois : finitions à confirmer.'}[m.stepId]),outputTokens:18,elapsedMs:90}});
   }
  });}
 }
 const c=vm.createContext({...core,MODEL:model,MODEL_MODE:'compact',ENGINE_PROTOCOL:'ENGINE',Worker,crypto:webcrypto,structuredClone,AbortController,Error,Promise,Date,performance,console,
   cacheReport:async()=>{cacheReads++;return{complete:options.cache!==false};},workerModelOptions:()=>({type:'module'}),reserveEngine:async()=>options.lock===false?null:()=>released++,navigator:options.noLocks?{}:{locks:{request(){}}},document:doc,
   setTimeout:(fn,ms)=>{timers.set(++tid,{fn,ms});return tid;},clearTimeout:i=>timers.delete(i),addEventListener:(k,f)=>events.set(k,f),removeEventListener:(k,f)=>{if(events.get(k)===f)events.delete(k);}});
 vm.runInContext(src('aster-writing-runner.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function')+'\nglobalThis.run=runLocalWriting;',c);
 const save=async value=>{saveCount++;if(options.failSave===saveCount)throw Error('storage failure');options.beforeSave?.(value,saveCount);current=structuredClone(value);saves.push(current);await options.persist?.(value);};
 return{start:()=>c.run(options.initial||initial(),{save,signal:options.controller?.signal}),read:()=>({current,saves,calls,released,workers,terminated,cacheReads,timers:timers.size,listeners:events.size}),doc};
}
await test('trois commandes distinctes au Worker simulé, un seul chargement, commits entre étapes',async()=>{const h=harness(),r=await h.start(),s=h.read();assert.equal(r.status,'COMPLETED');assert.equal(s.calls.filter(x=>x.type==='LOAD').length,1);assert.deepEqual(s.calls.filter(x=>x.type==='STUDIO_COMPOSE').map(x=>x.stepId),core.WRITING_STEPS.map(x=>x.id));assert.equal(s.saves.length,7);assert(s.saves[2].writing.steps[0].status==='done');assert.equal(s.released,1);assert.equal(s.terminated,1);assert.equal(s.timers,0);assert.equal(s.listeners,0);});
await test('rejouer un résultat complet ne lit pas les poids et ne crée aucun travail',async()=>{const r=await harness().start(),h=harness({initial:r});await h.start();assert.equal(h.read().workers,0);assert.equal(h.read().cacheReads,0);assert.equal(h.read().saves.length,0);});
await test('page masquée : arrêt, première étape conservée, reprise des deux restantes',async()=>{const h=harness({hideAt:'publication'});await assert.rejects(h.start(),/pause/);const r=h.read().current;assert.equal(r.writing.steps[0].status,'done');assert.equal(r.writing.steps[1].status,'pending');assert.equal(r.status,'INTERRUPTED');assert.equal(h.read().workers,h.read().terminated);const next=harness({initial:r});await next.start();assert.deepEqual(next.read().calls.filter(x=>x.type==='STUDIO_COMPOSE').map(x=>x.stepId),['publication','message']);assert.equal(next.read().current.writing.starts,2);});
await test('erreur du modèle : aucune relance automatique, diagnostic conservé',async()=>{const h=harness({failAt:'publication'});await assert.rejects(h.start(),/simulé/);assert.equal(h.read().calls.filter(x=>x.type==='STUDIO_COMPOSE').length,2);assert.equal(h.read().current.writing.errors.length,1);assert.equal(h.read().current.writing.errors[0].step,'publication');});
await test('échec sauvegarde initiale : aucun chargement ni écrasement',async()=>{const h=harness({failSave:1});await assert.rejects(h.start(),/storage/);assert.equal(h.read().workers,0);assert.equal(h.read().saves.length,0);assert.equal(h.read().released,1);});
await test('échec sauvegarde du résultat : étape suivante jamais lancée, pas de nouvelle écriture',async()=>{const h=harness({failSave:3});await assert.rejects(h.start(),/storage/);assert.equal(h.read().calls.filter(x=>x.type==='STUDIO_COMPOSE').length,1);assert.equal(h.read().saves.length,2);assert.equal(h.read().current.writing.steps[0].status,'running');});
await test('reprise après fermeture brute conserve l’essai et borne les tentatives',()=>{let r=core.beginWritingStep(core.startWriting(initial()),0);r=core.beginWritingStep(core.startWriting(r),0);assert.equal(r.writing.steps[0].attempts,2);assert.throws(()=>core.startWriting(r),/Deux essais/);});
await test('trois lancements maximum sans croissance infinie du journal',()=>{let r=initial();for(let i=0;i<3;i++){r=core.startWriting(r);r=core.interruptWriting(r,'Chargement indisponible');}assert.equal(r.writing.errors.length,3);assert.throws(()=>core.startWriting(r),/Trois lancements/);});
await test('modèle absent : aucun téléchargement, aucune écriture, aucun Worker',async()=>{const h=harness({cache:false});await assert.rejects(h.start(),/Modèle absent/);assert.equal(h.read().calls.length,0);assert.equal(h.read().saves.length,0);assert.equal(h.read().timers,0);});
await test('autre onglet ou verrou absent : aucun calcul concurrent',async()=>{for(const opts of [{lock:false},{noLocks:true}]){const h=harness(opts);await assert.rejects(h.start(),/onglet/);assert.equal(h.read().workers,0);}});
await test('moteur ancien ou configuration invalide : refus avant génération',async()=>{for(const opts of [{oldWorker:true},{actual:{n_ctx:512}}]){const h=harness(opts);await assert.rejects(h.start(),/incompatible|confirmée/);assert.equal(h.read().calls.filter(x=>x.type==='STUDIO_COMPOSE').length,0);}});
await test('arrêt utilisateur libère le moteur et préserve les étapes déjà confirmées',async()=>{const controller=new AbortController(),h=harness({controller,cancelAt:'publication'});await assert.rejects(h.start(),/pause/);assert.equal(h.read().current.writing.steps[0].status,'done');assert.equal(h.read().released,1);});
await test('délai et budget global bornent le travail sans relance',async()=>{for(const opts of [{timeoutAt:'publication'},{budgetAt:'publication'}]){const h=harness(opts);await assert.rejects(h.start(),/dépassé|dix minutes/);assert.equal(h.read().calls.filter(x=>x.type==='STUDIO_COMPOSE').length,2);assert.equal(h.read().timers,0);}});
await test('chiffres ou contacts inventés refusés sans promotion dans la mémoire',async()=>{for(const answer of ['Une terrasse de 80 mètres.','Contactez test@example.com','Voir https://example.com']){const h=harness({answer});await assert.rejects(h.start(),/chiffre|contact/);assert.equal(h.read().current.writing.steps[0].text,'');assert.equal(h.read().current.status,'INTERRUPTED');}});
await test('réserves et promesses : signaux de relecture, pas de certification sémantique',()=>{const a=core.assessWriting('Une terrasse exceptionnelle.',facts);assert.equal(a.verifiedFacts,false);assert.equal(a.flags.length,2);});
await test('doublon exact réutilisé ; changement de faits ou de modèle crée une autre identité',async()=>{const r=await harness().start();assert(core.matchingWriting([r],facts,model.id,model.revision));assert.equal(core.matchingWriting([r],{...facts,city:'Lyon'},model.id,model.revision),null);assert.equal(core.matchingWriting([r],facts,'another-model',model.revision),null);});
await test('travail sauvegardé dans le dossier et la sauvegarde complète, sans copier les photos dans les étapes',async()=>{const db=new TestDB();let d=studio.newStudioDossier('dossier-1');d.facts=facts;let state=await store.saveDossier(db,shop.workshopState(null),d);const h=harness({persist:async run=>{d={...d,runs:[run]};state=await store.saveDossier(db,state,d);}});await h.start();const payload=backup.serializeBackup(await backup.snapshot(db));const target=new TestDB();await backup.restoreBackup(target,payload);const saved=target.data.settings.get(shop.WORKSHOP_KEY).dossiers[0];assert.equal(saved.runs[0].status,'COMPLETED');assert.equal(saved.factsConfirmed,false);assert(!JSON.stringify(saved.runs).includes('data:image'));assert(JSON.stringify(saved.runs).length<14000);const imported=studio.importPrivateProject(studio.exportPrivateProject(saved),'copy');assert.deepEqual(imported.runs,saved.runs);assert.equal(imported.factsConfirmed,false);});
await test('faux états terminés ou textes trop grands refusés dans les imports',()=>{const d=studio.newStudioDossier('d-1');d.facts=facts;d.runs=[initial()];d.runs[0].status='COMPLETED';assert.throws(()=>shop.workshopState({schema:1,revision:0,dossiers:[d]}),/terminée/);const r=initial();r.writing.steps[0].text='a'.repeat(1201);assert.throws(()=>core.validateWriting(r.writing),/incompatible/);});
await test('mémoire : deux méthodes distinctes rappelées, aucun ancien enregistrement effacé',()=>{let m=learn.learningState(null);m=learn.retainLesson(m,'préparer présentation terrasse','Vérifier les faits.','1',1);m=learn.retainLesson(m,'préparer présentation entreprise','Vérifier les faits.','2',2);m=learn.retainLesson(m,'préparer présentation client','Relire les coordonnées.','3',3);const before=JSON.stringify(m),recalled=learn.recallLessons(m,'préparer présentation');assert.equal(recalled.length,2);assert.equal(new Set(recalled.map(x=>x.text)).size,2);assert.equal(JSON.stringify(m),before);for(let i=0;i<100;i++)m=learn.retainLesson(m,'préparer présentation terrasse','Vérifier les faits.','new'+i,i);assert.equal(m.lessons.length,3);m.contextUses=Number.MAX_SAFE_INTEGER;assert.equal(learn.recordContextUse(m,['1']).contextUses,Number.MAX_SAFE_INTEGER);});
await test('commande simple reconnue sans prendre une demande de recherche pour de la rédaction',()=>{assert(core.writingRequest('Améliore les textes'));assert(core.writingRequest('reformule mes textes avec le modèle local'));assert.equal(core.writingRequest('recherche des textes sur internet'),false);});
await test('canal Worker en échec : minuterie, écouteurs et verrou libérés',async()=>{const h=harness({throwAt:'STUDIO_COMPOSE'});await assert.rejects(h.start(),/Canal Worker/);assert.equal(h.read().timers,0);assert.equal(h.read().listeners,0);assert.equal(h.read().released,1);});

function workerHarness(options={}){
 const messages=[],calls=[];let intervals=0;
 class Engine{
  static getLibllamaVersion(){return cooperative.SUPPORTED_LLAMA;}
  getLoadedContextInfo(){return{n_ctx:1024,n_batch:64};}
  isEncoderDecoderArchitecture(){return false;}
  getCachedTokens(){return [];}
  tokenize(){return new Uint32Array(options.overflow?2000:100);}
  async decode(tokens){return tokens.length;}
  async createCompletion(prompt,params){calls.push({prompt,max:params.nPredict});await this.decode(new Uint32Array(70));for(let i=0;i<4;i++)params.onNewToken();return 'Texte proposé à relire.';}
 }
 const c=vm.createContext({...core,...studyCases,...contextBudget,cooperate:cooperative.withCooperativeDecode,ENGINE_PROTOCOL:'ENGINE',PROJECT_PROTOCOL:'PROJECT',SERVICE_SUITE:'SERVICE',MODEL:model,PROFILES:[{id:'safe-64',sliceMs:25,pauseMs:50}],self:{postMessage:m=>messages.push(m)},fake:new Engine(),performance,Error,Map,Promise,diagnosticCode:()=> 'UNKNOWN',setInterval:()=>++intervals,clearInterval:()=>intervals--,setTimeout,clearTimeout});
 const code=src('blob-assistant-worker.js').replace(/^import .*;\s*$/gm,'').replace("const {withCooperativeDecode}=await import('/blob-cooperative-decode.js?v=A72.3');",'const withCooperativeDecode=cooperate;');
 vm.runInContext(code+'\ngenerator=fake;',c);
 return{send:data=>c.self.onmessage({data}),read:()=>({messages,calls,intervals})};
}
await test('Worker réel : profil coopératif, plafonds de sortie et identifiant du résultat conservés',async()=>{
 const h=workerHarness();await h.send({type:'HELLO',nonce:'check'});assert.equal(h.read().messages.at(-1).writingProtocol,core.WRITING_PROTOCOL);
 for(const [i,step]of core.WRITING_STEPS.entries()){
  const prompt=core.writingPrompt(initial().writing,i);await h.send({type:'STUDIO_COMPOSE',stepId:step.id,requestId:step.id,prompt});const r=h.read().messages.at(-1);assert.equal(r.type,'STUDIO_COMPOSED');assert.equal(r.requestId,step.id);assert.equal(r.outputTokens,4);assert.equal(r.verifiedFacts,false);assert.equal(h.read().calls.at(-1).max,step.tokens);assert(h.read().calls.at(-1).prompt.includes(prompt));
 }
 assert.equal(h.read().calls.length,3);assert.equal(h.read().intervals,0);assert(h.read().messages.some(m=>m.type==='PACE'));
});
await test('Worker réel : contexte dépassé refusé avant calcul et jamais coupé silencieusement',async()=>{
 const h=workerHarness({overflow:true});await h.send({type:'STUDIO_COMPOSE',stepId:'presentation',requestId:'x',prompt:core.writingPrompt(initial().writing,0)});assert.equal(h.read().messages.at(-1).message,'DIALOGUE_CONTEXT_TOO_LONG');assert.equal(h.read().calls.length,0);assert.equal(h.read().intervals,0);
});
await test('Worker réel : demande de rédaction hors contrat refusée sans génération',async()=>{
 const h=workerHarness();for(const extra of [{stepId:'unknown'},{requestId:null},{prompt:'a'.repeat(1601)}]){await h.send({type:'STUDIO_COMPOSE',stepId:'presentation',requestId:'x',prompt:'texte',...extra});assert.equal(h.read().messages.at(-1).message,'COMPOSITION_INPUT_INVALID');}assert.equal(h.read().calls.length,0);
});


await test('méthode optionnelle trop longue omise entière, tous les faits conservés',()=>{
 const f={...facts,details:'Fait confirmé. '.repeat(46)};
 const r=core.newWritingRun('long',f,model.id,model.revision,undefined,[{id:'m1',source:'OWNER_VALIDATED_MEMORY',text:'Une méthode relue. '.repeat(21)},{id:'m2',source:'OWNER_VALIDATED_MEMORY',text:'Conserver les faits.'}]);
 assert.equal(r.writing.omittedMethodIds[0],'m1');assert.equal(r.writing.methods[0].id,'m2');assert(core.writingPrompt(r.writing,0).includes(JSON.stringify(f)));assert(!core.writingPrompt(r.writing,0).includes('Une méthode relue.'));
});

const report={release:'A106',scope:'Core, sauvegardes et runner réels ; moteur LLM, horloge et visibilité simulés. Aucune mesure de qualité du modèle ni essai iPhone.',passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length,tests};fs.writeFileSync(new URL('./a106-writing.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({...report,tests:tests.filter(t=>!t.passed)},null,2));

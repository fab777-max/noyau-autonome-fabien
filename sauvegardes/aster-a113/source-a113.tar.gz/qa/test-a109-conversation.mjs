import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
import {TestDB} from './memory-double.mjs';
const root=new URL('../public/',import.meta.url),src=n=>fs.readFileSync(new URL(n,root),'utf8'),memo=new Map(),tests=[];
function moduleURL(n){if(!memo.has(n))memo.set(n,'data:text/javascript;base64,'+Buffer.from(src(n).replace(/from ['"]\/([^'"?]+)(?:\?[^'"]*)?['"]/g,(_,f)=>'from '+JSON.stringify(moduleURL(f)))).toString('base64'));return memo.get(n);}
const core=await import(moduleURL('aster-conversation-core.js')),store=await import(moduleURL('noyau-dialogue-store.js')),personal=await import(moduleURL('blob-personal-core.js')),learning=await import(moduleURL('noyau-learning.js')),docs=await import(moduleURL('noyau-documents-core.js')),backup=await import(moduleURL('noyau-backup.js')),budget=await import(moduleURL('blob-context-budget.js'));
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.stack});process.exitCode=1;}}
const MODEL={id:'model',revision:'revision',modelBytes:1000000},JOB='noyauStandaloneJob-v1',CHAT='noyauStandaloneDialogue-v1',PERSONAL='assistantPersonal-v1';
const pipeline=await import(moduleURL('blob-response-pipeline.js'));
const fresh=()=>({dialogue:[],archive:[],personal:personal.personalState(null),learning:learning.learningState(null),revision:0,job:null});
const baseJob=()=>({id:'job1',homeProtocol:core.HOME_PROTOCOL,text:'Compare ces deux idées',mode:'deep',model:MODEL.id,modelRevision:MODEL.revision,context:{localOnly:true},elapsedMs:0,checkpoint:null});
function element(tag='div',all=[]){const e={tagName:tag.toUpperCase(),children:[],value:'',textContent:'',hidden:false,disabled:false,checked:false,attributes:{},className:'',append(...nodes){this.children.push(...nodes);},replaceChildren(...nodes){this.children=[];this.append(...nodes);},setAttribute(k,v){this.attributes[k]=v;},scrollIntoView(){},get lastElementChild(){return this.children.at(-1);}};all.push(e);return e;}
function uiHarness({db=new TestDB(),run=async(job,{saveCheckpoint,onContext})=>{await saveCheckpoint({answer:{plan:'Comparer les contraintes',final:'Une réponse locale simulée.'}});onContext({inputTokens:120,budget:736,droppedTurns:0,droppedEvidence:0,retainedSources:[]});return{answer:'Une réponse locale simulée.',review:{passed:true}};}}={}){
 const all=[],root=element('section',all),events={},statuses=[],drafts=[],timers=new Map();let accepted=0,calls=0,time=1000,timer=0;
 const c={...core,...store,...personal,...learning,...docs,MODEL,console,structuredClone,crypto:webcrypto,Date,Number,String,Error,Promise,AbortController,
  window:{BlobLocalMemory:{setting:async(_,k)=>structuredClone(db.data.settings.get(k))}},document:{createElement:t=>element(t,all),createTextNode:t=>t,addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n],hidden:false},
  navigator:{storage:{estimate:async()=>({quota:1e9,usage:0})}},performance:{now:()=>time},setInterval:fn=>{timers.set(++timer,fn);return timer;},clearInterval:id=>timers.delete(id),
  runHomeDialogue:async(...a)=>{calls++;time+=350;return run(...a);},cacheReport:async()=>({complete:false}),storagePlan:()=>({availableBytes:null}),prepareModel:async()=>{throw Error('Unexpected download');}};
 vm.createContext(c);vm.runInContext(src('aster-conversation-ui.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function'),c);
 const ready=c.initConversationUI({db,root,execute:fn=>fn(),status:(...a)=>statuses.push(a),onAccepted:async()=>{accepted++;},onDraft:t=>drafts.push(t)});
 return{ready,db,all,root,c,statuses,drafts,get accepted(){return accepted;},get calls(){return calls;},button:s=>all.filter(x=>x.tagName==='BUTTON'&&x.textContent===s).at(-1),text:()=>all.flatMap(x=>[x.textContent,...x.children.filter(y=>typeof y==='string')]).filter(Boolean).join('\n')};
}
function runnerHarness({cached=true,failSave=false,wrongProtocol=false,hidden=false,hold=false,signal}={}){
 const workers=[],saved=[],events={},stages=[],contexts=[];let released=0,locks=0;
 const c={MODEL,MODEL_MODE:'compact',HOME_LIMITS:core.HOME_LIMITS,HOME_PROTOCOL:core.HOME_PROTOCOL,ENGINE_PROTOCOL:'engine',AbortController,Error,Promise,structuredClone,crypto:webcrypto,setTimeout,clearTimeout,
  navigator:{locks:{request(){}}},document:{hidden,addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n]},addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n],cacheReport:async()=>({complete:cached}),reserveEngine:async()=>{locks++;return()=>released++;},workerModelOptions:()=>({type:'module'}),
  Worker:class{constructor(){this.sent=[];workers.push(this);}postMessage(m){this.sent.push(m);queueMicrotask(()=>{if(this.dead)return;const emit=data=>this.onmessage({data});if(m.type==='HELLO')emit({type:'HELLO_ACK',nonce:m.nonce,protocol:'engine',homeProtocol:wrongProtocol?'old':core.HOME_PROTOCOL,model:MODEL.id,revision:MODEL.revision});if(m.type==='LOAD')emit({type:'READY',model:MODEL.id,revision:MODEL.revision,actual:{n_ctx:1024,n_batch:64,n_threads:1,sliceMs:25,pauseMs:50}});if(m.type==='CHAT'&&!hold){emit({type:'STAGE',label:'Plan en cours',phase:'GENERATE',tokens:3});emit({type:'CONTEXT',retainedSources:[]});emit({type:'CHECKPOINT',id:1,checkpoint:{answer:{plan:'P',final:'F'}}});}if(m.type==='CHECKPOINT_ACK'&&m.ok)emit({type:'ANSWER',answer:'F',review:{passed:true}});});}terminate(){this.dead=true;}}
 };
 vm.createContext(c);vm.runInContext(src('aster-conversation-runner.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function'),c);
 return{workers,saved,events,stages,contexts,get released(){return released;},get locks(){return locks;},run:job=>c.runHomeDialogue(job,{signal,saveCheckpoint:async x=>{if(failSave)throw Error('storage-failure');saved.push(x);},onProgress:x=>stages.push(x),onContext:x=>contexts.push(x)})};
}

await test('questions ordinaires et préférences ne deviennent pas des faits de présentation',()=>{
 for(const text of ['Bonjour, je suis Fabien','Je voudrais discuter de mon entreprise','Comment vas-tu ?','Aide-moi à préparer demain','Retiens que je préfère le français'])assert.equal(core.homeRoute(text),'dialogue');
 assert.equal(core.homeRoute('Comment faire ?', {presentationActive:true}),'dialogue');
 assert.equal(core.homeRoute('Pose de terrasse',{presentationActive:true}),'presentation');
 assert.equal(core.homeRoute('Prépare une présentation de mon atelier'),'start-presentation');
 assert.equal(core.homeRoute('Bonjour',{editing:true}),'presentation');
});
await test('le temps supplémentaire dépend de la tâche ou d’un choix explicite',()=>{
 assert.equal(core.workMode('Salut'),'direct');assert.equal(core.workMode('Compare ces idées'),'deep');assert.equal(core.workMode('Un message',true),'deep');
 assert.equal(core.timingEstimate([], 'deep','m','r'),null);
 const rows=[10000,20000].map(wallMs=>({work:{mode:'deep',model:'m',revision:'r',wallMs}}));assert.equal(core.timingEstimate(rows,'deep','m','r').samples,2);assert.equal(core.timingEstimate(rows,'deep','other','r'),null);
});
await test('notes explicites dédupliquées, bornées, listées et retirables sans effacer l’historique',()=>{
 let s=fresh();for(let i=0;i<32;i++)s.personal=core.applyMemoryCommand(s.personal,{kind:'remember',text:'Préférence '+i+' '+'.'.repeat(450)}).personal;
 assert.throws(()=>core.applyMemoryCommand(s.personal,{kind:'remember',text:'Une autre note'}),/QUOTA/);
 assert.ok(core.applyMemoryCommand(s.personal,{kind:'list'}).answer.length<12000);
 const note=s.personal.notes[0].text;s.personal=core.applyMemoryCommand(s.personal,{kind:'remember',text:note}).personal;assert.equal(s.personal.notes.length,32);
 s.personal=core.applyMemoryCommand(s.personal,{kind:'forget',text:note}).personal;assert.equal(s.personal.notes.length,31);assert.equal(s.personal.forgotten.length,1);
});
await test('une préférence oubliée invalide le contexte et le plan de reprise',()=>{
 const s=fresh();s.personal=personal.rememberPersonalNote(s.personal,'je préfère le rouge');s.job={...baseJob(),checkpoint:{answer:{plan:'rouge'}},context:{notes:s.personal.notes}};
 const changed=core.applyMemoryCommand(s.personal,{kind:'forget',text:'je préfère le rouge'}).personal,p=core.preferencePatch(s,changed);assert.equal(p.job.checkpoint,null);assert.equal(p.job.context.notes.length,0);
 s.dialogue=[{role:'user',content:'je préfère le rouge'},{role:'assistant',content:'Le rouge sera utilisé.'}];assert.equal(core.dialogueContext({...s,personal:changed},'Et ensuite ?').history.length,0);
});
await test('notes et confirmation sont atomiques en cas de quota',async()=>{
 const h=uiHarness();const api=await h.ready;h.db.failAfter=2;await assert.rejects(()=>api.handle('Retiens que je préfère le français'),/quota/);assert.equal(h.db.data.settings.has(PERSONAL),false);assert.equal(h.db.data.settings.has(CHAT),false);assert.equal(h.accepted,0);
});
await test('mémoire sans modèle, réouverture et sauvegarde complète conservent les préférences',async()=>{
 const h=uiHarness(),api=await h.ready;await api.handle('Retiens que je préfère les explications simples');assert.equal(h.calls,0);assert.equal(h.db.data.settings.get(PERSONAL).notes.length,1);
 const restored=new TestDB();await backup.restoreBackup(restored,backup.serializeBackup(await backup.snapshot(h.db)));const h2=uiHarness({db:restored}),api2=await h2.ready;await api2.handle('Que sais-tu de moi ?');assert.match(h2.text(),/explications simples/);assert.equal(h2.calls,0);
});
await test('sauvegarde refuse une note malformée avant toute mutation',async()=>{
 const data=await backup.snapshot(new TestDB());data.settings[PERSONAL]={schema:personal.PERSONAL_SCHEMA,threads:[],notes:[{text:'x',source:'MODEL',at:1}]};assert.throws(()=>backup.validateBackup(data),/NOTE_INVALID/);
});
await test('envoi général : checkpoint puis réponse, même historique que l’espace avancé',async()=>{
 const h=uiHarness(),api=await h.ready;await api.handle('Explique une façon de préparer un projet');assert.equal(h.calls,1);assert.equal(h.db.data.settings.get(CHAT).length,2);assert.equal(h.db.data.settings.get(JOB),null);assert.equal(h.accepted,1);assert.match(h.text(),/Une réponse locale simulée/);
});
await test('réponse basée sur préférences et derniers échanges, sans anciennes affirmations A65',async()=>{
 let received;const h=uiHarness({run:async job=>{received=job;return{answer:'Réponse',review:{passed:true}};}}),api=await h.ready;
 await api.handle('Retiens que je préfère les réponses courtes');await api.handle('Parlons de mon atelier');await api.handle('Et demain ?');assert.equal(received.context.history.length,2);assert.equal(received.context.notes.length,1);assert.equal(received.context.localOnly,true);assert.deepEqual(received.context.facts,{available:false});
});
await test('commande de capacités annonce explicitement les moteurs non actifs',async()=>{
 const h=uiHarness(),api=await h.ready;await api.handle('Que peux-tu faire ?');assert.equal(h.calls,0);assert.match(h.text(),/activation distincte/);assert.match(h.text(),/Non actifs/);
});
await test('demande trop longue, conversation pleine et anciens échanges ne sont pas supprimés',async()=>{
 const h=uiHarness(),api=await h.ready;await assert.rejects(()=>api.handle('x'.repeat(1001)),/1 000/);assert.equal(h.accepted,0);
 const db=new TestDB();db.data.settings.set(CHAT,Array.from({length:1000},(_,i)=>({role:i%2?'assistant':'user',content:'Conserver'})));const h2=uiHarness({db}),a2=await h2.ready;await assert.rejects(()=>a2.handle('Bonjour'),/pleine/);assert.equal(db.data.settings.get(CHAT).length,1000);assert.equal(h2.calls,0);
});
await test('modèle absent : demande durable, installation explicite et aucun lancement à la réouverture',async()=>{
 const h=uiHarness({run:async()=>{throw Object.assign(Error('Modèle absent'),{code:'MODEL_MISSING'});}}),api=await h.ready;await api.handle('Bonjour');assert.equal(h.db.data.settings.get(JOB).missingModel,true);assert.equal(h.db.data.settings.get(CHAT),undefined);assert.equal(h.button('Installer le modèle · 1 Mo').hidden,false);
 const h2=uiHarness({db:h.db});await h2.ready;assert.equal(h2.calls,0);assert.equal(h2.button('Reprendre ce travail').hidden,false);
});
await test('une nouvelle demande conserve la précédente et refuse la 51e archive',async()=>{
 const h=uiHarness({run:async()=>{throw Error('Pause');}}),api=await h.ready;await api.handle('Travail un');await api.handle('Travail deux');assert.equal(h.db.data.settings.get('noyauStandalonePendingArchive-v1')[0].text,'Travail un');
 const db=new TestDB();db.data.settings.set(JOB,baseJob());db.data.settings.set('noyauStandalonePendingArchive-v1',Array.from({length:50},()=>({text:'Conservé'})));const h2=uiHarness({db}),a2=await h2.ready;await assert.rejects(()=>a2.handle('Autre travail'),/50 demandes/);assert.equal(db.data.settings.get(JOB).id,'job1');
});
await test('restauration pendant calcul : aucune réponse tardive ne remplace les données',async()=>{
 let api;const h=uiHarness({run:async()=>{const newer=await backup.snapshot(h.db);newer.settings[CHAT]=[{role:'assistant',content:'Restauré'}];await backup.restoreBackup(h.db,backup.serializeBackup(newer));return{answer:'Réponse ancienne'};}});api=await h.ready;await api.handle('Ancienne demande');assert.equal(h.db.data.settings.get(CHAT)[0].content,'Restauré');assert.equal(h.db.data.settings.get(CHAT).length,1);
});
await test('lecture des méthodes actuelles au commit, sans écraser une méthode ajoutée pendant le calcul',async()=>{
 const h=uiHarness({run:async(_job,{onContext})=>{h.db.data.settings.set(learning.LEARNING_KEY,learning.retainLesson(null,'Parlons de mon atelier','Une méthode','method1'));onContext({retainedSources:[{source:'OWNER_VALIDATED_MEMORY',id:'method1'}]});return{answer:'Réponse'};}}),api=await h.ready;await api.handle('Parlons de mon atelier');const s=h.db.data.settings.get(learning.LEARNING_KEY);assert.equal(s.lessons.length,1);assert.equal(s.contextUses,1);
});
await test('documents locaux recherchés seulement après sélection explicite, passages traçables',async()=>{
 let received;const h=uiHarness({run:async job=>{received=job;return{answer:'Réponse'};}});h.db.data.settings.set(docs.DOCUMENTS_KEY,docs.addDocument(null,{title:'Projet','text':'Le budget prévu du projet est de cinquante unités.'},'doc1'));
 const api=await h.ready;await api.handle('Quel budget pour mon projet ?');assert.equal(received.context.passages.length,0);
 h.all.filter(e=>e.tagName==='INPUT')[1].checked=true;await api.handle('Quel budget pour mon projet ?');assert.equal(received.context.passages[0].source,'LOCAL_DOCUMENT');assert.match(received.context.passages[0].title,/lignes/);
});
await test('absence de passage correspondant ne fabrique pas une lecture documentaire',async()=>{
 const h=uiHarness(),api=await h.ready;h.all.filter(e=>e.tagName==='INPUT')[1].checked=true;await api.handle('Quel est le budget ?');assert.equal(h.calls,0);assert.match(h.text(),/Aucun passage correspondant/);
});
await test('calibrage du vrai prompt conserve la demande et signale les retraits facultatifs',async()=>{
 const messages=[{role:'system',content:'Aster',evidence:[{source:'OWNER',text:'x'.repeat(1000),priority:5}]},{role:'user',content:'Historique'.repeat(300)},{role:'assistant',content:'Ancienne réponse'},{role:'user',content:'Demande actuelle entière',required:true}];
 const r=await budget.fitDialogueContext(messages,s=>Array.from(s),30,200);assert.match(r.text,/Demande actuelle entière/);assert(r.droppedEvidence>0&&r.droppedTurns>0);await assert.rejects(()=>budget.fitDialogueContext([{role:'user',content:'x'.repeat(1000),required:true}],s=>Array.from(s),30,100),/CONTEXT_TOO_LONG/);
});
await test('runner réel : protocole, modèle local, un Worker, ACK après sauvegarde et libération',async()=>{
 const h=runnerHarness(),r=await h.run(baseJob());assert.equal(r.answer,'F');assert.equal(h.workers.length,1);assert.equal(h.saved.length,1);const sent=h.workers[0].sent;assert.equal(sent.find(x=>x.type==='CHAT').localLearning,false);assert.equal(sent.find(x=>x.type==='LOAD').projectWork,true);assert.equal(sent.find(x=>x.type==='CHECKPOINT_ACK').ok,true);assert.equal(h.released,1);assert(h.workers[0].dead);assert(h.stages.some(s=>s.label==='Plan en cours'));
});
await test('runner refuse ancien protocole et modèle absent sans téléchargement',async()=>{
 const h=runnerHarness({wrongProtocol:true});await assert.rejects(()=>h.run(baseJob()),/Mise à jour/);assert.equal(h.released,1);const h2=runnerHarness({cached:false});await assert.rejects(()=>h2.run(baseJob()),/installé/);assert.equal(h2.workers.length,0);assert.equal(h2.locks,0);
});
await test('échec du checkpoint bloque ACK positif et résultat',async()=>{
 const h=runnerHarness({failSave:true});await assert.rejects(()=>h.run(baseJob()),/storage-failure/);assert.equal(h.workers[0].sent.some(m=>m.type==='CHECKPOINT_ACK'&&m.ok),false);assert.equal(h.released,1);
});
await test('page cachée ou pause explicite arrêtent le Worker et libèrent la réservation',async()=>{
 const hidden=runnerHarness({hidden:true});await assert.rejects(()=>hidden.run(baseJob()),/pause/);assert.equal(hidden.workers.length,0);
 const ac=new AbortController(),h=runnerHarness({hold:true,signal:ac.signal}),pending=h.run(baseJob());await new Promise(r=>setImmediate(r));ac.abort();await assert.rejects(()=>pending,/pause/);assert.equal(h.released,1);assert(h.workers[0].dead);
});
await test('pipeline approfondi réel : le plan est requis dans la réponse, jamais silencieusement évincé',async()=>{
 let calls=0,last,seen;const data={homeProtocol:core.HOME_PROTOCOL,text:'Prépare un plan simple',mode:'deep',context:{localOnly:true}},messages=[{role:'user',content:data.text,required:true}];
 const result=await pipeline.runAnswerPipeline(data,messages,{model:MODEL,generate:async m=>{calls++;seen=m;return calls===1?'Recueillir les contraintes. Comparer. Proposer.':'Une proposition à relire.';},save:async x=>{last=structuredClone(x);return true;}});
 assert.equal(calls,2);assert(seen.some(m=>m.role==='assistant'&&m.required===true&&/Recueillir/.test(m.content)));assert.equal(result.answer,'Une proposition à relire.');
 const resumed=await pipeline.runAnswerPipeline({...data,checkpoint:last},messages,{model:MODEL,generate:async()=>{throw Error('Génération inutile');},save:async()=>true});assert.equal(resumed.review.reusedFinal,true);
});
await test('pipeline interrompu après plan : une reprise calcule seulement la réponse manquante',async()=>{
 const data={homeProtocol:core.HOME_PROTOCOL,text:'Prépare un plan simple',mode:'deep',context:{localOnly:true}},messages=[{role:'user',content:data.text,required:true}];let last,calls=0;
 await assert.rejects(()=>pipeline.runAnswerPipeline(data,messages,{model:MODEL,generate:async()=>{if(++calls===2)throw Error('pause');return 'Plan utile';},save:async x=>{last=structuredClone(x);return true;}}),/pause/);
 let resumed=0;await pipeline.runAnswerPipeline({...data,checkpoint:last},messages,{model:MODEL,generate:async()=>{resumed++;return 'Voici une proposition à relire.';},save:async()=>true});assert.equal(resumed,1);
});
await test('pipeline refuse les fausses déclarations persistantes après au plus une correction',async()=>{
 let calls=0;await assert.rejects(()=>pipeline.runAnswerPipeline({homeProtocol:core.HOME_PROTOCOL,text:'Qui es-tu ?',context:{localOnly:true}},[{role:'user',content:'Qui es-tu ?'}],{model:MODEL,generate:async()=>{calls++;return 'Je suis Claude.';},save:async()=>true}),/REJECTED/);assert.equal(calls,2);
});
const report={release:'A109',scope:'Modules et gestionnaires réels ; IndexedDB, DOM, temps, cache et inférence simulés. Aucun test physique iPhone ni mesure réelle de qualité du modèle.',passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length,tests};fs.writeFileSync(new URL('./a109-conversation.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,failed:report.failed,failures:tests.filter(t=>!t.passed)},null,2));

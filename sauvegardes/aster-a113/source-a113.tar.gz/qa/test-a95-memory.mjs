import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import {webcrypto} from 'node:crypto';
const root=new URL('../public/',import.meta.url),src=n=>fs.readFileSync(new URL(n,root),'utf8'),memo=new Map(),tests=[];
function moduleURL(name){if(!memo.has(name))memo.set(name,'data:text/javascript;base64,'+Buffer.from(src(name).replace(/from ['"]\/([^'"?]+)(?:\?[^'"]*)?['"]/g,(_,file)=>'from '+JSON.stringify(moduleURL(file)))).toString('base64'));return memo.get(name);}
const core=await import(moduleURL('noyau-workshop-core.js')),backup=await import(moduleURL('noyau-backup.js')),store=await import(moduleURL('noyau-workshop-store.js'));
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.message});process.exitCode=1;}}
const clone=x=>x===undefined?undefined:structuredClone(x),keys={strategies:'key',strategy_archive:'key',proofs:'proofHash',run_summaries:'runId'};
// Transactional IndexedDB test double. Real browser persistence is explicitly outside this run.
class TestDB{
 constructor(){this.data=Object.fromEntries(backup.STORES.map(k=>[k,new Map()]));this.failAfter=null;}
 transaction(names,mode='readonly'){
  names=Array.isArray(names)?names:[names];const staged=Object.fromEntries(names.map(k=>[k,new Map([...this.data[k]].map(([a,b])=>[a,clone(b)]))]));let pending=0,aborted=false,complete=false,writes=0;
  const tx={error:null,abort:()=>{if(aborted||complete)return;aborted=true;tx.error=tx.error||Error('ABORT');queueMicrotask(()=>tx.onabort?.());}};
  const finish=()=>setImmediate(()=>{if(pending||aborted||complete)return;complete=true;if(mode==='readwrite')for(const n of names)this.data[n]=staged[n];tx.oncomplete?.();});
  const operation=(fn,write=false)=>{const req={result:undefined};pending++;queueMicrotask(()=>{try{if(!aborted){if(write&&mode!=='readwrite')throw Error('readonly');if(write&&this.failAfter!==null&&++writes===this.failAfter)throw Error('simulated quota failure');req.result=fn();req.onsuccess?.({target:req});}}catch(e){tx.error=e;tx.abort();}finally{pending--;finish();}});return req;};
  tx.objectStore=name=>({get:key=>operation(()=>clone(staged[name].get(key))),getAll:()=>operation(()=>[...staged[name].entries()].sort(([a],[b])=>a.localeCompare(b)).map(([,v])=>clone(v))),getAllKeys:()=>operation(()=>[...staged[name].keys()].sort((a,b)=>a.localeCompare(b))),put:(value,key)=>operation(()=>{const k=key??value[keys[name]];if(typeof k!=='string')throw Error('bad key');staged[name].set(k,clone(value));return k;},true),clear:()=>operation(()=>staged[name].clear(),true)});finish();return tx;
 }
}

await test('un ancien onglet ne peut pas écraser le dossier restauré ayant la même révision',async()=>{
 const db=new TestDB(),d=core.freshDossier('same-id');d.facts.title='Dossier avant restauration';const stale={schema:1,revision:5,dossiers:[d]};db.data.settings.set(core.WORKSHOP_KEY,clone(stale));const snapshot=await backup.snapshot(db);snapshot.settings[core.WORKSHOP_KEY].dossiers[0].facts.title='Dossier restauré';await backup.restoreBackup(db,snapshot);await assert.rejects(()=>store.saveDossier(db,stale,d),/autre onglet|restaur/i);assert.equal(db.data.settings.get(core.WORKSHOP_KEY).dossiers[0].facts.title,'Dossier restauré');
});
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return{promise,resolve,reject};}
const emptyBackup=label=>({schema:backup.BACKUP_SCHEMA,at:'2026-10-15T00:00:00Z',weightsIncluded:false,settings:{label},preferences:{},memory:{schema:'blob-local-memory-export-v1',canonicalBrainIncluded:false,creditsSpendable:false,records:{strategies:[],strategy_archive:[],proofs:[],run_summaries:[]}}});
function backupUI({gate=null,previous=null}={}){
 const ids=['backup','restoreState','restoreFile','restoreConfirm','restoreApply','restorePrevious','restoreExportPrevious'],e=Object.fromEntries(ids.map(id=>[id,{disabled:false,checked:false,files:[],textContent:''}])),restored=[],downloads=[];
 const doc={getElementById:id=>e[id],createElement:()=>({click(){},remove(){}}),body:{append(){}}};
 const c={document:doc,console,structuredClone,Blob,URL,MAX_BACKUP_BYTES:backup.MAX_BACKUP_BYTES,ROLLBACK_KEY:backup.ROLLBACK_KEY,MODEL_CHOICE_KEY:'mode',validateBackup:backup.validateBackup,previewBackup:backup.previewBackup,snapshot:async()=>emptyBackup('export'),restoreBackup:async(_,data)=>{restored.push(clone(data));return{preferences:{}};},navigator:{},localStorage:{getItem:()=>null},location:{href:'https://test.invalid/',replace(){}},setTimeout(){},BroadcastChannel:class{postMessage(){}close(){}}};
 c.window={BlobLocalMemory:{setting:async()=>previous},NoyauLocalMaintenance:{run:async fn=>{if(gate)await gate.promise;return fn({});}}};
 vm.createContext(c);vm.runInContext(src('noyau-backup-ui.js').replace(/^import .*;\s*$/gm,''),c);
 return{e,restored,downloads,choose(file){e.restoreFile.files=file?[file]:[];return e.restoreFile.onchange();},confirm(){e.restoreConfirm.checked=true;e.restoreConfirm.onchange();},click:id=>e[id].onclick()};
}
const backupFile=label=>({size:100,text:async()=>JSON.stringify(emptyBackup(label))});
await test('la dernière sélection gagne même si le premier fichier finit de se lire après elle',async()=>{
 const h=backupUI(),slow=deferred();const first=h.choose({size:100,text:()=>slow.promise});await h.choose(backupFile('deuxième'));slow.resolve(JSON.stringify(emptyBackup('premier')));await first;h.confirm();await h.click('restoreApply');assert.equal(h.restored[0].settings.label,'deuxième');
});
await test('un ancien fichier illisible ne désactive pas le nouveau fichier valide',async()=>{
 const h=backupUI(),slow=deferred();const first=h.choose({size:100,text:()=>slow.promise});await h.choose(backupFile('valide'));slow.reject(Error('ancien fichier illisible'));await first;h.confirm();assert.equal(h.e.restoreApply.disabled,false);await h.click('restoreApply');assert.equal(h.restored[0].settings.label,'valide');
});
await test('la restauration fige la sélection pendant l’attente du verrou',async()=>{
 const gate=deferred(),h=backupUI({gate});await h.choose(backupFile('confirmé'));h.confirm();const applying=h.click('restoreApply');
 const disabled=['restoreFile','restoreConfirm','backup','restorePrevious','restoreExportPrevious'].map(id=>h.e[id].disabled);
 await h.choose(backupFile('non confirmé'));gate.resolve();await applying;assert.deepEqual(disabled,[true,true,true,true,true]);assert.equal(h.restored[0].settings.label,'confirmé');
});
await test('choisir la copie de retour annule toute lecture de fichier antérieure',async()=>{
 const h=backupUI({previous:emptyBackup('copie de retour')}),slow=deferred();const first=h.choose({size:100,text:()=>slow.promise});await h.click('restorePrevious');slow.resolve(JSON.stringify(emptyBackup('ancien fichier')));await first;h.confirm();await h.click('restoreApply');assert.equal(h.restored[0].settings.label,'copie de retour');
});
await test('une sauvegarde sans atelier invalide aussi un onglet initialement vide',async()=>{
 const db=new TestDB(),stale=core.workshopState(null);await backup.restoreBackup(db,emptyBackup('ancien format'));await assert.rejects(()=>store.saveDossier(db,stale,core.freshDossier('new')),/autre onglet/);assert.deepEqual(db.data.settings.get(core.WORKSHOP_KEY).dossiers,[]);
});
await test('les restaurations et retours arrière gardent un compteur croissant',async()=>{
 const db=new TestDB();db.data.settings.set(core.WORKSHOP_KEY,{schema:1,revision:20,dossiers:[core.freshDossier('original')]});const target=emptyBackup('restauré');target.settings[core.WORKSHOP_KEY]={schema:1,revision:2,dossiers:[core.freshDossier('restored')]};await backup.restoreBackup(db,target);assert.equal(db.data.settings.get(core.WORKSHOP_KEY).revision,21);const previous=clone(db.data.settings.get(backup.ROLLBACK_KEY));await backup.restoreBackup(db,previous);assert.equal(db.data.settings.get(core.WORKSHOP_KEY).revision,22);assert.equal(db.data.settings.get(core.WORKSHOP_KEY).dossiers[0].id,'original');target.settings[core.WORKSHOP_KEY].revision=50;await backup.restoreBackup(db,target);assert.equal(db.data.settings.get(core.WORKSHOP_KEY).revision,51);
});
await test('un compteur hors capacité annule la restauration avant toute suppression',async()=>{
 const db=new TestDB();db.data.settings.set('private','à conserver');const before=clone(db.data),target=emptyBackup('invalide');target.settings[core.WORKSHOP_KEY]={schema:1,revision:Number.MAX_SAFE_INTEGER,dossiers:[]};await assert.rejects(()=>backup.restoreBackup(db,target),/Compteur/);assert.deepEqual(db.data,before);
});
await test('une erreur de restauration rend les contrôles utilisables pour une reprise manuelle',async()=>{
 const gate=deferred(),h=backupUI({gate});await h.choose(backupFile('confirmé'));h.confirm();const applying=h.click('restoreApply');gate.reject(Error('Écriture annulée'));await applying;assert.equal(h.e.restoreApply.disabled,false);assert.equal(h.e.restoreFile.disabled,false);assert.match(h.e.restoreState.textContent,/Écriture annulée/);assert.equal(h.restored.length,0);
});
await test('une restauration confirmée ne se répète pas en attendant la réouverture',async()=>{
 const h=backupUI();await h.choose(backupFile('confirmé'));h.confirm();await Promise.all([h.click('restoreApply'),h.click('restoreApply')]);await h.click('restoreApply');assert.equal(h.restored.length,1);assert.equal(h.e.restoreApply.disabled,true);
});
const report={release:'A95',passed:tests.filter(x=>x.passed).length,failed:tests.filter(x=>!x.passed).length,tests};fs.writeFileSync(new URL('./a95-memory.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));

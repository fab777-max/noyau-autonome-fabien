// Transactional IndexedDB double; no real browser or model execution.
const STORES=['settings','strategies','strategy_archive','proofs','run_summaries'];
const clone=x=>x===undefined?undefined:structuredClone(x),keys={strategies:'key',strategy_archive:'key',proofs:'proofHash',run_summaries:'runId'};
// Transactional persistence double. These checks do not run a real iPhone or LLM.
export class TestDB{
 constructor(){this.data=Object.fromEntries(STORES.map(k=>[k,new Map()]));this.failAfter=null;}
 transaction(names,mode='readonly'){
  names=Array.isArray(names)?names:[names];const staged=Object.fromEntries(names.map(k=>[k,new Map([...this.data[k]].map(([a,b])=>[a,clone(b)]))]));let pending=0,aborted=false,complete=false,writes=0;
  const tx={error:null,abort:()=>{if(aborted||complete)return;aborted=true;tx.error=tx.error||Error('ABORT');queueMicrotask(()=>tx.onabort?.());}};
  const finish=()=>setImmediate(()=>{if(pending||aborted||complete)return;complete=true;if(mode==='readwrite')for(const n of names)this.data[n]=staged[n];tx.oncomplete?.();});
  const operation=(fn,write=false)=>{const req={result:undefined};pending++;queueMicrotask(()=>{try{if(!aborted){if(write&&mode!=='readwrite')throw Error('readonly');if(write&&this.failAfter!==null&&++writes===this.failAfter)throw Error('simulated quota failure');req.result=fn();req.onsuccess?.({target:req});}}catch(e){tx.error=e;tx.abort();}finally{pending--;finish();}});return req;};
  tx.objectStore=name=>({get:key=>operation(()=>clone(staged[name].get(key))),getAll:()=>operation(()=>[...staged[name].entries()].sort(([a],[b])=>a.localeCompare(b)).map(([,v])=>clone(v))),getAllKeys:()=>operation(()=>[...staged[name].keys()].sort((a,b)=>a.localeCompare(b))),put:(value,key)=>operation(()=>{const k=key??value[keys[name]];staged[name].set(k,clone(value));return k;},true),clear:()=>operation(()=>staged[name].clear(),true)});finish();return tx;
 }
}

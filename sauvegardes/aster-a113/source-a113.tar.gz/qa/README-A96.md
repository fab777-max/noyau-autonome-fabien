# A96 — iPhone installation and offline recovery

Date: 2026-10-15. Same owner-private Site, origin, database and model-cache identities as A95.

## Delivered

- A visible installation guide distinguishes the connected ChatGPT app, the Safari home-screen icon, the cached interface and the local model. Standalone mode is detected without asserting that model weights have been downloaded.
- The existing download-only action is now visible in the model section. It does not start a study campaign or inference. A missing model is no longer described as ready at initial opening.
- Offline preparation reports files present and transfer progress. Registration, activation and copy failures offer an explicit retry; there is no timer-based retry loop.
- Missing interface assets are fetched with a 45-second inactivity deadline covering response headers and streaming bodies. Incoming chunks extend the deadline, so a slow but progressing transfer is not cancelled solely for its duration. The UI reports a stalled preparation after 60 seconds without progress.
- Retrying reuses completed interface files. Existing model manifests, weight caches, memory formats and recovery modules are unchanged.

## Evidence

- `a96-offline.json`: 12 checks passed for manual retry, progress, activation failure, standalone mode, stale release messages, partial-copy reuse, stalled headers and bodies, progressing slow transfers and unique page control IDs.
- `a96-local-regression.json`: 62 checks passed, including the 59 existing affected Blob/SW cases and 3 first-launch/download-only cases.
- Five installation usability checks were demonstrated to fail against A95 before the improvements. These represent the prior missing retry/progress/onboarding behavior, not five independent data-loss defects.
- The A95 storage/restore and A94 server mutation suites were not repeated: their production modules and database migrations are unchanged. No real model weights were downloaded and no LLM was executed during this validation.

Browser DOM, service-worker lifecycle, storage and network are simulated in these checks. No physical iPhone Safari or browser visual QA was performed. Actual first response and offline reopening on the phone remain the acceptance steps.

## References and first use

Apple's current instructions: https://support.apple.com/fr-lu/guide/iphone/iphea86e5236/ios — Safari, Share, Add to Home Screen, enable Open as Web App, Add. The Site repeats this sequence and recommends reopening the icon before inspecting/preparing the local model.

OpenAI Sites overview: https://learn.chatgpt.com/docs/sites — the published address is a hosted Site. Connecting its private MCP tools in ChatGPT is separate from caching its browser interface or model.

Open the existing Site in Safari, add the icon if desired, reopen it, wait for interface-copy confirmation, and inspect model availability. Download only if missing. Run **TEST COURT : BONJOUR** with the page visible. The workshop's template-based photo pack does not require a model. Agent requests require connectivity.

Keep a full backup separately in Files. Do not erase browser storage to resolve an installation problem. Rollback uses the prior Site version without deleting memory or model caches.

import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
import {TestDB} from './memory-double.mjs';
const root=new URL('../public/',import.meta.url),src=n=>fs.readFileSync(new URL(n,root),'utf8'),memo=new Map(),tests=[];
function moduleURL(name){if(!memo.has(name))memo.set(name,'data:text/javascript;base64,'+Buffer.from(src(name).replace(/from ['"]\/([^'"?]+)(?:\?[^'"]*)?['"]/g,(_,file)=>'from '+JSON.stringify(moduleURL(file)))).toString('base64'));return memo.get(name);}
const core=await import(moduleURL('noyau-workshop-core.js')),backup=await import(moduleURL('noyau-backup.js')),context=await import(moduleURL('blob-context-budget.js'));
const project=await import(moduleURL('noyau-project-core.js')),documents=await import(moduleURL('noyau-documents-core.js')),research=await import(moduleURL('noyau-research-core.js'));
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.message});process.exitCode=1;}}
const facts=core.cleanFacts({business:'Atelier exemple',title:'Entretien de façade',city:'Clonas-sur-Varèze',date:'Octobre 2026',details:'Description de la réalisation. '.repeat(15)+' ATTENTION : sans garantie décennale ni certification.',price:'120 euros',contact:'Contact à confirmer'});
const fullFacts=prompt=>JSON.parse(prompt.slice(prompt.indexOf('<faits>')+7,prompt.lastIndexOf('</faits>')));
const oversized=()=>Object.fromEntries(Object.entries(core.FIELDS).map(([k,n])=>[k,'"'.repeat(n)]));
await test('F1 : réserve après le caractère 420 et tous les champs conservés',()=>{
 const sent=fullFacts(core.captionPrompt(facts));assert.ok(facts.details.indexOf('sans garantie')>420);
 assert.deepEqual(sent,{professionnel:facts.business,realisation:facts.title,ville:facts.city,date:facts.date,faits:facts.details,prix:facts.price,contact:facts.contact});
});
await test('entrée avec échappements trop longue refusée, jamais raccourcie',()=>{assert.throws(()=>core.captionPrompt(oversized()),/aucune information n’a été coupée/);});
await test('budget en jetons : entrée obligatoire gardée entière ou refusée',async()=>{
 const prompt=core.captionPrompt(facts),tokens=async text=>new Array(text.length).fill(1);
 await assert.rejects(()=>context.fitDialogueContext([{role:'user',content:prompt}],tokens,96,512),/DIALOGUE_CONTEXT_TOO_LONG/);
 const fit=await context.fitDialogueContext([{role:'user',content:prompt}],tokens,96,2048);assert.ok(fit.text.includes(prompt));assert.equal(fit.droppedTurns,0);
});
function llmHarness({failure=null}={}){
 const sent=[],counts={cache:0,reservations:0,workers:0,terminated:0,released:0};
 class Worker{constructor(){counts.workers++;}terminate(){counts.terminated++;}postMessage(p){sent.push(p);queueMicrotask(()=>{if(p.type==='HELLO')this.onmessage({data:{type:'HELLO_ACK',nonce:p.nonce,protocol:'test',model:'test',revision:'1'}});if(p.type==='LOAD')this.onmessage({data:{type:'READY',model:'test',revision:'1'}});if(p.type==='COMPOSE')this.onmessage({data:failure?{type:'ERROR',message:failure}:{type:'COMPOSED',answer:'Proposition à relire.',outputTokens:5}});});}}
 const c={captionPrompt:core.captionPrompt,MODEL:{id:'test',revision:'1'},MODEL_MODE:'compact',ENGINE_PROTOCOL:'test',cacheReport:async()=>{counts.cache++;return{complete:true};},reserveEngine:async()=>{counts.reservations++;return()=>counts.released++;},workerModelURL:()=>'/fixture',workerModelOptions:()=>({}),Worker,document:{hidden:false},crypto:webcrypto,performance,setTimeout,clearTimeout};
 vm.createContext(c);vm.runInContext(src('noyau-workshop-llm.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function')+';globalThis.run=composeLocalCaption;',c);return{run:c.run,sent,counts};
}
await test('refus de taille avant cache, réservation ou création du moteur',async()=>{const h=llmHarness();await assert.rejects(()=>h.run(oversized()),/capacité/);assert.deepEqual(h.counts,{cache:0,reservations:0,workers:0,terminated:0,released:0});});
await test('le moteur reçoit le brief figé entier et libère ses ressources',async()=>{const h=llmHarness(),input={...facts},task=h.run(input);input.details='MODIFICATION TARDIVE';const result=await task;assert.equal(fullFacts(h.sent.find(p=>p.type==='COMPOSE').prompt).faits,facts.details);assert.equal(result.verifiedFacts,false);assert.equal(h.counts.terminated,1);assert.equal(h.counts.released,1);});
await test('refus du budget modèle expliqué sans relance',async()=>{const h=llmHarness({failure:'DIALOGUE_CONTEXT_TOO_LONG'});await assert.rejects(()=>h.run(facts),/aucune information n’a été coupée/);assert.equal(h.sent.filter(p=>p.type==='COMPOSE').length,1);assert.equal(h.counts.terminated,1);assert.equal(h.counts.released,1);});
function envelope(){return{schema:backup.BACKUP_SCHEMA,at:'2026-10-15T00:00:00Z',weightsIncluded:false,settings:{},preferences:{},memory:{schema:'blob-local-memory-export-v1',canonicalBrainIncluded:false,creditsSpendable:false,records:{strategies:[],strategy_archive:[],proofs:[],run_summaries:[]}}};}
await test('F4 : 44 500 messages, fichier réellement produit sous 40 Mio et relisible',async()=>{
 const data=envelope();data.settings['noyauStandaloneDialogue-v1']=Array.from({length:44500},(_,i)=>({role:i%2?'assistant':'user',content:'a'.repeat(900)}));
 assert.ok(Buffer.byteLength(JSON.stringify(data,null,2))>backup.MAX_BACKUP_BYTES);
 const blob=new Blob([backup.serializeBackup(data)],{type:'application/json'});assert.ok(blob.size<=backup.MAX_BACKUP_BYTES);
 const reloaded=backup.validateBackup(await blob.text());assert.equal(reloaded.settings['noyauStandaloneDialogue-v1'].length,44500);assert.equal(reloaded.settings['noyauStandaloneDialogue-v1'][44499].content,'a'.repeat(900));
});
await test('limite UTF-8 réelle : dernier caractère multioctet accepté ou refus explicite',()=>{
 const data=envelope(),base=Buffer.byteLength(JSON.stringify({...data,settings:{large:''}}));
 data.settings.large='é'.repeat(Math.floor((backup.MAX_BACKUP_BYTES-base)/2));assert.ok(Buffer.byteLength(backup.serializeBackup(data))<=backup.MAX_BACKUP_BYTES);
 data.settings.large+='é';assert.throws(()=>backup.serializeBackup(data),/volumineuse|40 Mio/);
});
await test('export normalisé relisible, pilote restauré désarmé, entrée intacte',()=>{
 const data=envelope();data.settings['assistantLocalPilot-example']={enabled:true};const before=structuredClone(data),text=backup.serializeBackup(data);
 assert.equal(backup.validateBackup(text).settings['assistantLocalPilot-example'].enabled,false);assert.deepEqual(data,before);
});
await test('restauration du fichier exporté et retour arrière atomique',async()=>{
 const db=new TestDB();db.data.settings.set('precious','original');const data=envelope();data.settings['noyauStandaloneDialogue-v1']=[{role:'user',content:'Réserve à conserver : pas de garantie.'}];
 await backup.restoreBackup(db,backup.serializeBackup(data));assert.equal(db.data.settings.get('noyauStandaloneDialogue-v1')[0].content,data.settings['noyauStandaloneDialogue-v1'][0].content);
 const previous=db.data.settings.get(backup.ROLLBACK_KEY);await backup.restoreBackup(db,backup.serializeBackup(previous));assert.equal(db.data.settings.get('precious'),'original');
});
function backupUI(data,previous=data){
 const ids=['backup','backupState','restoreState','restoreFile','restoreConfirm','restoreApply','restorePrevious','restoreExportPrevious'],e=Object.fromEntries(ids.map(id=>[id,{disabled:false,checked:false,files:[],textContent:''}])),blobs=[],links=[];
 const c={...backup,...project,...documents,...research,MODEL_CHOICE_KEY:'mode',document:{getElementById:id=>e[id],createElement:()=>({click(){links.push(this.download);},remove(){}}),body:{append(){}}},structuredClone,Blob,URL:{createObjectURL:blob=>{blobs.push(blob);return'blob:fixture';},revokeObjectURL(){}},snapshot:async()=>data,localStorage:{getItem:()=>null},navigator:{},setTimeout(){},BroadcastChannel:class{}};
 c.window={BlobLocalMemory:{setting:async()=>previous},NoyauLocalMaintenance:{run:async fn=>fn({})}};vm.createContext(c);vm.runInContext(src('noyau-backup-ui.js').replace(/^import .*;\s*$/gm,''),c);return{e,blobs,links,click:id=>e[id].onclick()};
}
await test('les deux boutons d’export passent par le contenu validé',async()=>{const d=envelope();d.settings.message='À conserver 🍀';const h=backupUI(d);await h.click('backup');await h.click('restoreExportPrevious');assert.equal(h.blobs.length,2);for(const blob of h.blobs)assert.equal(backup.validateBackup(await blob.text()).settings.message,d.settings.message);assert.match(h.e.backupState.textContent,/Copie précédente/);assert.match(h.links[0],/A101/);});
await test('sauvegarde invalide : aucun faux lien de téléchargement',async()=>{const h=backupUI({bad:true});await h.click('backup');await h.click('restoreExportPrevious');assert.equal(h.blobs.length,0);assert.equal(h.links.length,0);assert.match(h.e.restoreState.textContent,/compatible/);assert.equal(h.e.backup.disabled,false);});
// Retain the ten established recovery scenarios, without overwriting their old evidence.
let regression=fs.readFileSync(new URL('./test-a98-recovery.mjs',import.meta.url),'utf8').replaceAll('import.meta.url',JSON.stringify(new URL('./test-a98-recovery.mjs',import.meta.url).href));
regression=regression.replace('const project=',"const documents=await import(moduleURL('noyau-documents-core.js')),research=await import(moduleURL('noyau-research-core.js'));\nconst project=");
regression=regression.replace('const c={...project,','const c={...backup,...project,...documents,...research,');
regression=regression.replaceAll("release:'A98'","release:'A101'").replaceAll('a98-recovery.json','a101-recovery-regressions.json').replace('console.log(JSON.stringify(report,null,2));',"console.log(JSON.stringify({suite:'recovery',passed:report.passed,failed:report.failed,failures:tests.filter(x=>!x.passed)}));");
await import('data:text/javascript;base64,'+Buffer.from(regression).toString('base64'));
const report={release:'A101',date:new Date().toISOString(),scope:'Code réel ; DOM, Worker et IndexedDB simulés ; Blob UTF-8 réel. Aucune inférence, aucun iPhone.',passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length,tests};
fs.writeFileSync(new URL('./a101-reliability.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({suite:'reliability',passed:report.passed,failed:report.failed,failures:tests.filter(t=>!t.passed)}));

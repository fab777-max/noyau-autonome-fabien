# A101 — facts and backup round trips

Run `node qa/test-a101-reliability.mjs`.

12 targeted reliability checks and 10 retained recovery checks pass against the current modules. These cover full-field caption prompts, a qualifier after character 420, explicit character/token budget refusal, frozen prompt, no retry and Worker cleanup; compact UTF-8 export near 40 MiB, Unicode boundary refusal, normalization, actual Blob parsing, both export UI actions, transactional restore/rollback, stale tabs and pending file reads.

DOM, Worker and IndexedDB are test doubles. No model, physical iPhone or browser was run. The tokenizer in the budget test is a deterministic stand-in; it proves refusal logic, not the capacity of Qwen for a given brief.

Five changed JS modules passed `node --check`; all 58 offline assets and local imports were present; three pages have distinct IDs and A101 markers. Model cache configuration and model manifests were unchanged. Source packaging/build and native deployment supply the separate publication evidence.

Open audit findings: F2 semantic factual checks; F3 backups above 40 MiB. See `PLAN-EXECUTION.md`. A101 does not increase context/model memory, retrain Qwen, merge old browser storage spaces or certify long-duration operation.

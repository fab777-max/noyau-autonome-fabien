# A97 — simpler daily UI, preserved work

User requested removal of test-launch controls after exercising A96 on iPhone. The everyday pages now share three navigation entries. Download, pause and resume actions are conditional; complete backup stays directly accessible. Diagnostic history remains in settings, while campaigns are not runnable from the home screen.

The substantive safety change is transactional preservation of an interrupted request before a new request replaces it. Its stored checkpoint is retained. Archival actions can retrieve the text without launching work. No old archive is automatically deleted. Full-backup validation handles this added archive setting; storage identity and the restore transaction remain unchanged.

Checks: `node qa/test-a97.mjs` (37 passed), `node qa/test-a95-memory.mjs` (10 passed). These execute production entry/recovery functions with simulated browser/worker/IndexedDB/network boundaries. A97's test file retains relevant regression cases from A96 and adds archive transaction/failure/recovery and retired-control checks. Historical test scripts continue documenting their earlier release interfaces; their removed controls are not restored merely to make obsolete tests pass.

HTML structure/control references were checked. Complete static imports remain in the service-worker shell. No model download or actual inference was necessary for these changes. There is no browser visual QA or physical iPhone verification of A97 in this environment. User screenshots validate aspects of A96, including real output errors; they do not certify commercial output quality.

# A100 — source-backed research dossiers

Run the affected checks:

```sh
node qa/test-a100-research.mjs
node qa/test-a100-regressions.mjs
```

The first runs 28 queue, persistence, source-integrity, review/export and UI cases against actual research modules. The second reuses 69 affected retained document, project and restoration scenarios against the current modules, saving separate A100 reports. All 97 pass. Historical reports are retained.

The UI harness deliberately supplies no Worker or fetch implementation. It covers real UI handlers using simulated DOM, locks and transactional IndexedDB. Tests include interruption after a confirmed write, aborted launch while waiting for the lock, no replay on reopening, quota failure without retry, stale revisions after restore, maximum corpus size, text-only display of hostile source markup, explicit attachment and confirmed deletion.

No physical iPhone, browser-rendered layout, network research, LLM inference or multi-hour background operation is claimed. The research operation is deterministic and may finish quickly. The new 30-second between-step budget prevents continuing a batch indefinitely; it cannot override browser suspension or make storage calls real-time.

The export separates copied source passages from the owner's saved judgments and marks pending questions. Search absence is not evidence that a fact is absent. Source correctness is not established merely by preserving exact citations.

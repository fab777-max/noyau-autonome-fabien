import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
import {TestDB} from './memory-double.mjs';
const root=new URL('../public/',import.meta.url),src=n=>fs.readFileSync(new URL(n,root),'utf8'),memo=new Map(),tests=[];
function moduleURL(n){if(!memo.has(n))memo.set(n,'data:text/javascript;base64,'+Buffer.from(src(n).replace(/from ['"]\/([^'"?]+)(?:\?[^'"]*)?['"]/g,(_,f)=>'from '+JSON.stringify(moduleURL(f)))).toString('base64'));return memo.get(n);}
const core=await import(moduleURL('aster-conversation-core.js')),store=await import(moduleURL('noyau-dialogue-store.js')),personal=await import(moduleURL('blob-personal-core.js')),learning=await import(moduleURL('noyau-learning.js')),docs=await import(moduleURL('noyau-documents-core.js')),backup=await import(moduleURL('noyau-backup.js')),budget=await import(moduleURL('blob-context-budget.js'));
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.stack});process.exitCode=1;}}
const MODEL={id:'model',revision:'revision',modelBytes:1000000},JOB='noyauStandaloneJob-v1',CHAT='noyauStandaloneDialogue-v1',PERSONAL='assistantPersonal-v1';
const corrections=await import(moduleURL('aster-conversation-learning.js')),documentStore=await import(moduleURL('noyau-documents-store.js'));
const workCore=await import(moduleURL('aster-work-core.js'));
const workBudget=await import(moduleURL('aster-work-budget.js'));
const pipeline=await import(moduleURL('blob-response-pipeline.js'));
const fresh=()=>({dialogue:[],archive:[],personal:personal.personalState(null),learning:learning.learningState(null),revision:0,job:null});
const baseJob=()=>({id:'job1',homeProtocol:core.HOME_PROTOCOL,text:'Compare ces deux idées',mode:'deep',model:MODEL.id,modelRevision:MODEL.revision,context:{localOnly:true},elapsedMs:0,checkpoint:null});
function element(tag='div',all=[]){const e={tagName:tag.toUpperCase(),children:[],value:'',textContent:'',hidden:false,disabled:false,checked:false,attributes:{},className:'',append(...nodes){this.children.push(...nodes);},replaceChildren(...nodes){this.children=[];this.append(...nodes);},setAttribute(k,v){this.attributes[k]=v;},scrollIntoView(){},get lastElementChild(){return this.children.at(-1);}};all.push(e);return e;}
function uiHarness({db=new TestDB(),run=async(job,{saveCheckpoint,onContext})=>{await saveCheckpoint({answer:{plan:'Comparer les contraintes',final:'Une réponse locale simulée.'}});onContext({inputTokens:120,budget:736,droppedTurns:0,droppedEvidence:0,retainedSources:[]});return{answer:'Une réponse locale simulée.',review:{passed:true}};}}={}){
 const all=[],root=element('section',all),events={},statuses=[],drafts=[],timers=new Map();let accepted=0,calls=0,time=1000,timer=0;
 const c={...core,...store,...personal,...learning,...docs,...corrections,...documentStore,...workCore,...workBudget,Blob,URL,MODEL,console,structuredClone,crypto:webcrypto,Date,Number,String,Error,Promise,AbortController,
  window:{BlobLocalMemory:{setting:async(_,k)=>structuredClone(db.data.settings.get(k))}},document:{createElement:t=>element(t,all),createTextNode:t=>t,addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n],hidden:false},
  navigator:{storage:{estimate:async()=>({quota:1e9,usage:0})}},performance:{now:()=>time},setInterval:fn=>{timers.set(++timer,fn);return timer;},clearInterval:id=>timers.delete(id),
  runHomeDialogue:async(...a)=>{calls++;time+=350;return run(...a);},cacheReport:async()=>({complete:false}),storagePlan:()=>({availableBytes:null}),prepareModel:async()=>{throw Error('Unexpected download');}};
 vm.createContext(c);vm.runInContext(src('aster-conversation-ui.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function'),c);
 const ready=c.initConversationUI({db,root,execute:fn=>fn(),status:(...a)=>statuses.push(a),onAccepted:async()=>{accepted++;},onDraft:t=>drafts.push(t)});
 return{ready,db,all,root,c,statuses,drafts,get accepted(){return accepted;},get calls(){return calls;},button:s=>all.filter(x=>x.tagName==='BUTTON'&&x.textContent===s).at(-1),text:()=>all.flatMap(x=>[x.textContent,...x.children.filter(y=>typeof y==='string')]).filter(Boolean).join('\n')};
}
function runnerHarness({cached=true,failSave=false,wrongProtocol=false,hidden=false,hold=false,signal,toolRequest=null}={}){
 const workers=[],saved=[],events={},stages=[],contexts=[],partials=[];let released=0,locks=0;
 const c={...workCore,...workBudget,MODEL,MODEL_MODE:'compact',HOME_LIMITS:core.HOME_LIMITS,HOME_PROTOCOL:core.HOME_PROTOCOL,ENGINE_PROTOCOL:'engine',performance,AbortController,Error,Promise,structuredClone,crypto:webcrypto,setTimeout,clearTimeout,
  navigator:{locks:{request(){}}},document:{hidden,addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n]},addEventListener:(n,f)=>events[n]=f,removeEventListener:n=>delete events[n],cacheReport:async()=>({complete:cached}),reserveEngine:async()=>{locks++;return()=>released++;},workerModelOptions:()=>({type:'module'}),
  Worker:class{constructor(){this.sent=[];workers.push(this);}postMessage(m){this.sent.push(m);queueMicrotask(()=>{if(this.dead)return;const emit=data=>this.onmessage({data});if(m.type==='HELLO')emit({type:'HELLO_ACK',nonce:m.nonce,protocol:'engine',homeProtocol:wrongProtocol?'old':core.HOME_PROTOCOL,workProtocol:workBudget.WORK_PROTOCOL,model:MODEL.id,revision:MODEL.revision});if(m.type==='LOAD')emit({type:'READY',model:MODEL.id,revision:MODEL.revision,actual:{n_ctx:4096,n_batch:64,n_threads:1,sliceMs:25,pauseMs:50}});if(m.type==='CHAT'&&!hold){if(toolRequest){emit({type:'TOOL_REQUEST',id:1,jobId:m.jobId,...toolRequest});return;}emit({type:'TECHNICAL',event:'REQUEST_STARTED'});emit({type:'TECHNICAL',event:'FIRST_TOKEN'});emit({type:'PARTIAL',text:'Brouillon reçu'});emit({type:'TECHNICAL',event:'GENERATION_FINISHED',tokens:12});emit({type:'STAGE',label:'Plan en cours',phase:'GENERATE',tokens:3});emit({type:'CONTEXT',retainedSources:[]});emit({type:'CHECKPOINT',id:1,checkpoint:{answer:{plan:'P',final:'F'}}});}if(m.type==='TOOL_RESULT'&&m.ok)emit({type:'CHECKPOINT',id:1,checkpoint:{answer:{final:'F'}}});if(m.type==='CHECKPOINT_ACK'&&m.ok)emit({type:'ANSWER',answer:'F',review:{passed:true}});});}terminate(){this.dead=true;}}
 };
 vm.createContext(c);vm.runInContext(src('aster-conversation-runner.js').replace(/^import .*;\s*$/gm,'').replace('export async function','async function'),c);
 return{workers,saved,events,stages,contexts,partials,get released(){return released;},get locks(){return locks;},run:job=>c.runHomeDialogue(job,{signal,onTool:a=>workCore.executeLocalTool(a),saveCheckpoint:async x=>{if(failSave)throw Error('storage-failure');saved.push(x);},onProgress:x=>stages.push(x),onContext:x=>contexts.push(x),onPartial:x=>partials.push(x)})};
}


const evidence=await import(moduleURL('aster-work-evidence.js')),workPipeline=await import(moduleURL('aster-work-pipeline.js')),comparison=await import(moduleURL('aster-comparison-core.js')),grounding=await import(moduleURL('blob-grounding-core.js'));
const at=n=>new Date(n).toISOString();
await test('A113 : un dossier sélectionné ne détourne aucune phrase ordinaire',()=>{
 for(const text of ["Je m'appelle Fabien",'Mon objectif est de monter mon entreprise','Raconte-moi une histoire','Merci pour ton aide','Pose de terrasse','Je suis heureux de te parler'])assert.equal(core.homeRoute(text,{presentationActive:true}),'dialogue');
 assert.equal(core.homeRoute('Atelier Fabien',{presentationInput:true}),'presentation');
});
await test('A113 : prénom retenu retrouvé par reformulation et identité récente prioritaire',()=>{
 let p=personal.rememberPersonalNote(null,'Mon prénom est Fabien',10);assert.match(personal.relevantPersonalNotes(p,"Comment je m’appelle ?")[0].text,/Fabien/);
 p=personal.rememberPersonalNote(p,'Mon prénom est Paul',20);const selected=personal.relevantPersonalNotes(p,'Quel est mon prénom ?');assert.match(selected[0].text,/Paul/);assert(!selected.some(n=>n.text.includes('Fabien')));
});
await test('A113 : correction longue entière et question abrégée explicitement',()=>{
 let rows=[{role:'user',content:'Projet atelier '+ 'question '.repeat(100)},{role:'assistant',content:'Ancienne réponse'}];rows=corrections.correctedRows(rows,1,'Correction atelier '+ 'explication '.repeat(90));
 const found=corrections.correctionExamples(rows,'Projet atelier');assert.equal(found.length,1);assert(found[0].text.endsWith(rows[1].correction.text));assert.match(found[0].text,/Demande \(extrait\)/);
});
await test('A113 : 300 changements de note restent bornés sans perdre les notes actives',()=>{
 let p=personal.rememberPersonalNote(null,'Préférence 0',1);const old=structuredClone(p);
 p=personal.rememberPersonalNote(p,'Je préfère les réponses courtes',2);
 for(let i=0;i<300;i++)p=personal.replacePersonalNote(p,'Préférence '+i,'Préférence '+(i+1),10+i*2);
 assert.equal(p.forgotten.length,128);assert(p.forgottenBefore>0);assert.equal(p.notes.length,2);assert(p.notes.some(n=>n.text==='Préférence 300'));
 const merged=personal.mergePersonal(p,old);assert(!merged.notes.some(n=>n.text==='Préférence 0'));assert(merged.notes.some(n=>n.text==='Je préfère les réponses courtes'));
});
await test('A113 : oubli filtre les anciens messages et accepte une nouvelle déclaration datée',()=>{
 const s=fresh();s.personal=personal.rememberPersonalNote(null,'Mon prénom est Fabien',100);s.personal=personal.replacePersonalNote(s.personal,'Mon prénom est Fabien','',200);s.personal=personal.rememberPersonalNote(s.personal,'Mon prénom est Fabien',300);
 s.dialogue=[{role:'user',content:'Mon prénom est Fabien',savedAt:at(150)},{role:'assistant',content:'Bonjour Fabien',savedAt:at(150)},{role:'user',content:'Mon prénom est Fabien',savedAt:at(350)},{role:'assistant',content:'Ravi de discuter avec toi',savedAt:at(350)}];
 const context=core.dialogueContext(s,'Quel est mon prénom ?');assert.equal(context.history.length,2);assert.match(context.notes[0].text,/Fabien/);
 assert.equal(workCore.recalledExchanges(s.dialogue,'prénom',s.personal.forgotten,0).length,1);
 assert.equal(personal.forgottenExchange([{content:'ancien échange',at:10}],[],20),true);
});
await test('A113 : édition de mémoire invalide aussi les demandes archivées',()=>{
 const s=fresh();s.archive=[{...baseJob(),workControl:{...workBudget.initialWorkControl(),approvedTools:12},checkpoint:{answer:{draft:'ancien contexte'}},elapsedMs:42}];
 const patch=core.preferencePatch(s,personal.rememberPersonalNote(null,'Mon prénom est Fabien'));
 assert.equal(patch.archive[0].checkpoint,null);assert.equal(patch.archive[0].workControl.approvedTools,4);assert.equal(patch.archive[0].elapsedMs,42);
});
await test('A113 : 1 000 messages archivés puis reprise sans suppression ni croissance libre',async()=>{
 const db=new TestDB();db.data.settings.set(CHAT,Array.from({length:1000},(_,i)=>({role:i%2?'assistant':'user',content:'Message '+i})));let s=await store.readLocalState(db);assert.throws(()=>store.reserveDialogueAnswer(s.dialogue,'Suite'),/pleine/);
 s=await store.commitLocalState(db,s.revision,x=>store.archiveConversation(x,'history1'));assert.equal(s.dialogue.length,0);assert.equal(s.history[0].dialogue.length,1000);store.reserveDialogueAnswer(s.dialogue,'Suite');
 for(let i=2;i<=3;i++){s=await store.commitLocalState(db,s.revision,()=>({dialogue:[{role:'user',content:'Sujet '+i}]}));s=await store.commitLocalState(db,s.revision,x=>store.archiveConversation(x,'history'+i));}
 s=await store.commitLocalState(db,s.revision,()=>({dialogue:[{role:'user',content:'Sujet quatre'}]}));const before=structuredClone(db.data);await assert.rejects(()=>store.commitLocalState(db,s.revision,x=>store.archiveConversation(x,'history4')),/Trois/);assert.deepEqual(db.data,before);
});
await test('A113 : souvenir ancien reste retrouvable dans une conversation archivée',()=>{
 const s={...fresh(),history:[{id:'h',at:at(100),title:'Atelier',dialogue:[{role:'user',content:'Mon bateau se nomme Libellule.'},{role:'assistant',content:'Tu as appelé ton bateau Libellule.'}]}]};
 assert.match(core.dialogueContext(s,'Comment se nomme mon bateau ?').passages[0].text,/Libellule/);
});
await test('A113 : sauvegarde et restauration comprennent archives et mesure sans changer la conversation',async()=>{
 const db=new TestDB();let s=await store.readLocalState(db);s=await store.commitLocalState(db,s.revision,()=>({dialogue:[{role:'user',content:'Mémoire à conserver'}],comparison:comparison.newComparison('model','revision')}));s=await store.commitLocalState(db,s.revision,x=>store.archiveConversation(x,'h'));
 const payload=backup.serializeBackup(await backup.snapshot(db)),other=new TestDB();await backup.restoreBackup(other,payload);const restored=await store.readLocalState(other);assert.equal(restored.history[0].dialogue[0].content,'Mémoire à conserver');assert.equal(restored.comparison.results.length,0);assert(other.data.settings.has(backup.ROLLBACK_KEY));
});
await test('A113 : restauration de demande garde checkpoint, reçus et autorisation et échange le travail actif',()=>{
 const old={...baseJob(),id:'old',workControl:{...workBudget.initialWorkControl(),approvedTools:8},usage:{outputTokens:99,generations:3},elapsedMs:750,checkpoint:{answer:{local:{decisions:4,receipts:[],pending:null}}}};
 const s={...fresh(),job:{...baseJob(),id:'current'},archive:[old]};const patch=store.restoreArchivedJob(s,0,{protocol:core.HOME_PROTOCOL,model:MODEL.id,revision:MODEL.revision});assert.equal(patch.job.id,'old');assert.deepEqual(patch.job.checkpoint,old.checkpoint);assert.equal(patch.job.workControl.approvedTools,8);assert.equal(patch.archive[0].id,'current');assert.equal(patch.job.usage.outputTokens,99);
 assert.throws(()=>store.restoreArchivedJob(s,0,{protocol:core.HOME_PROTOCOL,model:'wrong',revision:MODEL.revision}),/incompatible/);
});
await test('A113 : bouton de sélection restaure le vrai travail sans lancer le modèle',async()=>{
 const db=new TestDB(),old={...baseJob(),id:'old',elapsedMs:230,checkpoint:{answer:{final:'Déjà conservé'}}};db.data.settings.set('noyauStandalonePendingArchive-v1',[old]);const h=uiHarness({db});await h.ready;await h.button('Sélectionner ce travail conservé').onclick();assert.equal(h.calls,0);assert.equal(db.data.settings.get(JOB).id,'old');assert.equal(db.data.settings.get(JOB).checkpoint.answer.final,'Déjà conservé');assert.equal(db.data.settings.get(JOB).elapsedMs,230);
});
await test('A113 : sélection refuse un document modifié et laisse le checkpoint intact',async()=>{
 const db=new TestDB(),old={...baseJob(),context:{toolScope:{documents:true,selectedId:'',documentSignature:'obsolete'}}};db.data.settings.set('noyauStandalonePendingArchive-v1',[old]);const h=uiHarness({db});await h.ready;await assert.rejects(()=>h.button('Sélectionner ce travail conservé').onclick(),/documents.*changé/);assert.equal(db.data.settings.has(JOB),false);assert.equal(db.data.settings.get('noyauStandalonePendingArchive-v1').length,1);
});
await test('A113 : archiver depuis l’interface garde les notes et le travail en pause',async()=>{
 const db=new TestDB();db.data.settings.set(CHAT,[{role:'user',content:'Avant'},{role:'assistant',content:'Réponse'}]);db.data.settings.set(JOB,baseJob());const h=uiHarness({db}),api=await h.ready;await h.button('Archiver cette conversation et continuer').onclick();assert.equal(db.data.settings.get(CHAT).length,0);assert.equal(db.data.settings.get(store.DIALOGUE_HISTORY_KEY)[0].dialogue.length,2);assert.equal(db.data.settings.get(JOB).id,'job1');assert.equal(h.calls,0);
});
await test('A113 : retrait d’une demande demande deux clics, sans purge automatique',async()=>{
 const db=new TestDB();db.data.settings.set('noyauStandalonePendingArchive-v1',[baseJob()]);const h=uiHarness({db});await h.ready;await h.button('Retirer cette demande').onclick();assert.equal(db.data.settings.get('noyauStandalonePendingArchive-v1').length,1);await h.button('Confirmer le retrait de cet appareil').onclick();assert.equal(db.data.settings.get('noyauStandalonePendingArchive-v1').length,0);
});
await test('A113 : sélection documents sans correspondance laisse une salutation au modèle',async()=>{
 let received;const h=uiHarness({run:async j=>{received=j;return{answer:'Bonjour !'};}}),api=await h.ready;h.all.filter(e=>e.tagName==='INPUT')[1].checked=true;await api.handle('Bonjour, comment vas-tu ?');assert.equal(h.calls,1);assert.equal(received.context.documentsNoMatch,true);assert.equal(h.db.data.settings.get(CHAT)[1].source,undefined);
});
await test('A113 : réserve couvre une réponse et un journal UTF-8 volumineux',()=>{
 const rows=Array.from({length:500},(_,i)=>({role:i%2?'assistant':'user',content:'x'.repeat(2900)}));store.reserveDialogueAnswer(rows,'Demande');const journal={receipts:Array.from({length:24},(_,i)=>({action:{tool:'read_document',id:'d',start:i},result:{status:'ok',evidence:[{source:'LOCAL_DOCUMENT',id:'d',title:'Source',text:'漢'.repeat(600)},{source:'LOCAL_DOCUMENT',id:'d2',title:'Source deux',text:'漢'.repeat(600)}]}}))};
 const record={role:'assistant',content:'漢'.repeat(12000),work:{localWork:journal,excerpts:journal.receipts.flatMap(r=>r.result.evidence).slice(0,6)}};assert(new TextEncoder().encode(JSON.stringify(record)).length>100000);store.ensureDialogueCapacity(rows,[{role:'user',content:'Demande'},record]);
 const near=Array.from({length:600},(_,i)=>({role:i%2?'assistant':'user',content:'x'.repeat(3100)}));assert.throws(()=>store.reserveDialogueAnswer(near,'Demande'),/réserve/);
});
await test('A113 : ancienne contrainte préservée après 24 résultats et doublons non comptés',()=>{
 const receipts=Array.from({length:24},(_,i)=>({result:{evidence:[{source:'LOCAL_DOCUMENT',id:'d'+i,title:'Document '+i,text:i?'Information complémentaire '+i:'Budget maximal obligatoire : 840 euros.'}]}}));
 const prior=receipts.flatMap(r=>r.result.evidence).slice(-6),current=workPipeline.workMessages(core.homeMessages('Quel plan pour ce projet ?'),{receipts})[0].evidence;
 assert(!prior.some(e=>e.id==='d0'));assert(current.some(e=>e.id==='d0'&&e.required));assert(current.length<=6);assert.equal(workBudget.workProgress({receipts:[receipts[0],receipts[0],receipts[0]]}).found,1);
 fs.writeFileSync(new URL('./a113-evidence-comparison.json',import.meta.url),JSON.stringify({scope:'Synthetic software fixtures, not LLM answer quality',receipts:24,selectedLimit:6,earlyConstraintIncluded:{A112:prior.some(e=>e.id==='d0'),A113:current.some(e=>e.id==='d0')},duplicateReceipts:3,distinctResults:1},null,2));
});
await test('A113 : recherches reformulées sans nouveauté s’arrêtent après trois outils',async()=>{
 const job={...baseJob(),workControl:workBudget.initialWorkControl()},work={};let decisions=0,tools=0;
 await workPipeline.gatherLocalEvidence(job,core.homeMessages(job.text),work,{generate:async()=>JSON.stringify({tool:'recall_conversation',query:'atelier '+(++decisions)}),tool:async()=>{tools++;return{status:'ok',evidence:[{source:'PAST_CONVERSATION',id:'same',title:'Même résultat',text:'Un seul passage retrouvé.'}]};}},async()=>true);
 assert.equal(tools,3);assert.match(work.local.stop,/sans résultat nouveau/);assert.equal(workBudget.workProgress(work.local).found,1);assert.equal(work.local.awaitingApproval,null);
});
await test('A113 : une réparation de JSON bornée puis un calcul valide',async()=>{
 const job={...baseJob(),workControl:workBudget.initialWorkControl()},work={};let n=0,tools=0;const answers=['Je vais calculer.','{"tool":"calculate","expression":"2+3"}','{"tool":"answer"}'];
 await workPipeline.gatherLocalEvidence(job,core.homeMessages(job.text),work,{generate:async()=>answers[n++],tool:async a=>{tools++;return workCore.executeLocalTool(a);}},async()=>true);assert.equal(tools,1);assert.equal(work.local.decisions,3);assert.equal(work.local.repairUsed,true);assert.equal(work.local.receipts[0].result.evidence[0].text,'2+3 = 5');
});
await test('A113 : deux décisions invalides arrêtent sans outil ni boucle',async()=>{
 const job={...baseJob(),workControl:workBudget.initialWorkControl()},work={};let n=0;await workPipeline.gatherLocalEvidence(job,core.homeMessages(job.text),work,{generate:async()=>{n++;return '{"tool":"execute_code","code":"bad"}';},tool:()=>{throw Error('Forbidden call');}},async()=>true);assert.equal(n,2);assert.equal(work.local.receipts.length,0);assert.match(work.local.stop,/non exploitable/);
});
await test('A113 : calcul vérifié accepté seulement avec son reçu exact, fausse publication refusée',async()=>{
 const receipt={result:await workCore.executeLocalTool({tool:'calculate',expression:'12+3'})};
 assert.throws(()=>grounding.guardExecutionClaims("J’ai vérifié le calcul : 12+3=15."),/UNPROVEN/);
 assert.equal(grounding.guardExecutionClaims("J’ai vérifié le calcul : 12+3=15.",{localOnly:true,localWork:{receipts:[receipt]}}),"J’ai vérifié le calcul : 12+3=15.");
 assert.throws(()=>grounding.guardExecutionClaims("J’ai vérifié le calcul : 12+3=16.",{localWork:{receipts:[receipt]}}),/UNPROVEN/);
 assert.throws(()=>grounding.guardExecutionClaims('Le site a été mis à jour et les fichiers sont publiés.',{localOnly:true}),/UNPROVEN/);
});
await test('A113 : comparaison alterne les modes et ne mélange pas les contextes',async()=>{
 let s=comparison.newComparison('model','revision'),order=[];
 for(let i=0;i<8;i++){const job=await comparison.comparisonJob(s,'j'+i);order.push(job.mode);const pair=s.results.find(x=>x.caseId===job.caseId);if(pair)assert.deepEqual(job.context,pair.context);s.results.push({caseId:job.caseId,mode:job.mode,answer:'Réponse',ms:1000,outputTokens:10,grade:null,context:job.context});}
 assert.deepEqual(order,['direct','deep','deep','direct','direct','deep','deep','direct']);assert.equal(comparison.nextComparison(s),null);assert.equal(comparison.comparisonSummary(s).pairs,4);
});
await test('A113 : comparaison garde les données initiales identiques et quatre outils maximum',async()=>{
 const s=comparison.newComparison('model','revision'),first=await comparison.comparisonJob(s,'direct');s.results.push({caseId:first.caseId,mode:'direct',answer:'Lina',ms:10,outputTokens:3});const second=await comparison.comparisonJob(s,'deep');assert.deepEqual(first.context,second.context);assert.equal(second.workControl.approvedTools,4);assert.equal(first.workControl,undefined);
});
await test('A113 : pas de gain de qualité annoncé sans notes humaines appariées',()=>{
 const s=comparison.newComparison('model','revision');s.results=[{caseId:'conversation',mode:'direct',answer:'Lina',ms:20,outputTokens:5,grade:2},{caseId:'conversation',mode:'deep',answer:'Lina',ms:60,outputTokens:20,grade:null}];assert.equal(comparison.comparisonSummary(s).gradeDelta,null);s.results[1].grade=4;assert.equal(comparison.comparisonSummary(s).gradeDelta,2);
 assert.throws(()=>comparison.comparisonState({...s,results:[...s.results,s.results[0]]}),/incompatible/);assert.throws(()=>comparison.comparisonState({...s,elapsedMs:-1}),/incompatible/);
});
function comparisonUIHarness({db=new TestDB(),run=null}={}){
 const all=[],els=new Map([...src('comparaison.html').matchAll(/<([\w-]+)[^>]*\bid="([^"]+)"/g)].map(m=>[m[2],element(m[1],all)]));let calls=0;
 const c={...comparison,...store,...core,...workCore,MODEL,Blob,URL,AbortController,structuredClone,crypto:webcrypto,performance,setTimeout,clearTimeout,document:{getElementById:id=>els.get(id),createElement:t=>element(t,all)},window:{BlobLocalMemory:{open:async()=>db}},runHomeDialogue:async(j,o)=>{calls++;return run?run(j,o):{answer:'Résultat simulé pour vérifier le parcours.',localWork:{receipts:[]},review:{passed:true}};}};
 vm.createContext(c);vm.runInContext(src('aster-comparison-ui.js').replace(/^import .*;\s*$/gm,'').replace('init().catch(e=>message(e.message));','globalThis.ready=init();'),c);
 return{db,c,ready:c.ready,get:id=>els.get(id),get calls(){return calls;}};
}
await test('A113 : comparaison UI ne démarre que sur clic, huit réponses bornées sans modifier les notes',async()=>{
 const db=new TestDB();db.data.settings.set(CHAT,[{role:'user',content:'Ma conversation privée'}]);db.data.settings.set(PERSONAL,personal.rememberPersonalNote(null,'Note privée'));const before=structuredClone(db.data.settings.get(PERSONAL));const h=comparisonUIHarness({db});await h.ready;assert.equal(h.calls,0);await h.get('comparisonStart').onclick();assert.equal(h.calls,8);assert.equal(db.data.settings.get(comparison.COMPARISON_KEY).status,'complete');assert.equal(db.data.settings.get(comparison.COMPARISON_KEY).results.length,8);assert.deepEqual(db.data.settings.get(PERSONAL),before);assert.equal(db.data.settings.get(CHAT)[0].content,'Ma conversation privée');
});
await test('A113 : comparaison interrompue reprend le checkpoint sans dupliquer une réponse',async()=>{
 let interrupted=false,seen=false;const db=new TestDB(),h=comparisonUIHarness({db,run:async(j,o)=>{if(!interrupted){interrupted=true;await o.saveCheckpoint({answer:{identity:'saved',draft:'brouillon'}});throw Error('Interruption simulée');}seen ||= j.checkpoint?.answer?.identity==='saved';return{answer:'Réponse',review:{passed:true}};}});await h.ready;await h.get('comparisonStart').onclick();assert.equal(db.data.settings.get(comparison.COMPARISON_KEY).results.length,0);assert.equal(db.data.settings.get(comparison.COMPARISON_KEY).status,'paused');await h.get('comparisonResume').onclick();assert(seen);assert.equal(db.data.settings.get(comparison.COMPARISON_KEY).results.length,8);
});
const report={release:'A113',scope:'Focused regression checks. Inference, DOM and browser services simulated; no real model quality measurement.',passed:tests.filter(t=>t.passed).length,failed:tests.filter(t=>!t.passed).length,tests};fs.writeFileSync(new URL('./a113-regressions.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:report.passed,failed:report.failed,failures:tests.filter(t=>!t.passed)},null,2));

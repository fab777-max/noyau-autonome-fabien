import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=new URL('../public/',import.meta.url),src=name=>fs.readFileSync(new URL(name,root),'utf8'),tests=[];
const revision=src('blob-sw.js').match(/const REVISION='([^']+)'/)[1],build=revision.split('-')[0];
async function test(name,fn){try{await fn();tests.push({name,passed:true});}catch(e){tests.push({name,passed:false,error:e.message});process.exitCode=1;}}
const flush=async()=>{for(let i=0;i<4;i++)await new Promise(setImmediate);};
async function offlineUI({supported=true,registrationFails=false,neverReady=false,standalone=false}={}){
 const ids=['offline','maintenance','refreshApp','retryOffline','homeMode'],elements=Object.fromEntries(ids.map(id=>[id,{textContent:'',disabled:false,hidden:['refreshApp','retryOffline'].includes(id)}])),handlers={},requests=[],timers=new Map();let nextTimer=0,registrations=0,failed=registrationFails;
 const worker={postMessage:m=>requests.push(m)},ready=neverReady?new Promise(()=>{}):Promise.resolve({active:worker});
 const sw={controller:neverReady?null:worker,ready,addEventListener:(name,fn)=>handlers[name]=fn,register:async()=>{registrations++;if(failed)throw Error('registration failed');return{active:neverReady?null:worker};}};
 const c={console,URL,WeakSet,Set,Error,Promise,navigator:{standalone,...(supported?{serviceWorker:sw}:{})},document:{getElementById:id=>elements[id]},location:{href:'https://test.local/',reload(){}},matchMedia:()=>({matches:standalone}),setTimeout:(fn,ms)=>{const id=++nextTimer;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id)};
 vm.createContext(c);vm.runInContext(src('noyau-local-offline.js'),c);await flush();
 return{elements,requests,timers,registrations:()=>registrations,setFailure:x=>failed=x,emit:p=>handlers.message?.({data:{revision,...p},source:worker}),click:()=>elements.retryOffline.onclick?.(),tick:async()=>{for(const[id,t]of [...timers]){timers.delete(id);t.fn();}await flush();}};
}
await test('une copie interrompue propose une reprise manuelle sans boucle automatique',async()=>{
 const h=await offlineUI();assert.equal(h.requests.length,1);h.emit({type:'SHELL_READY',ok:false});await flush();assert.equal(h.elements.retryOffline.hidden,false);assert.equal(h.requests.length,1);assert.equal(h.elements.retryOffline.disabled,false);await h.click();await flush();assert.equal(h.requests.length,2);assert.equal(h.elements.retryOffline.disabled,true);await h.click();assert.equal(h.requests.length,2);
});
await test('la progression des fichiers est visible sans déclarer le modèle prêt',async()=>{
 const h=await offlineUI();h.emit({type:'SHELL_PROGRESS',completed:4,total:50});assert.match(h.elements.offline.textContent,/4.*50/);assert.doesNotMatch(h.elements.offline.textContent,/modèle prêt/i);h.emit({type:'SHELL_READY',ok:true});assert.match(h.elements.offline.textContent,/enregistrée|prête/i);assert.equal(h.elements.retryOffline.hidden,true);assert.equal(h.timers.size,0);
});
await test('un échec d’enregistrement du service worker peut être repris explicitement',async()=>{
 const h=await offlineUI({registrationFails:true});assert.equal(h.elements.retryOffline.hidden,false);assert.equal(h.registrations(),1);h.setFailure(false);await h.click();await flush();assert.equal(h.registrations(),2);assert.equal(h.requests.length,1);
});
await test('une activation bloquée finit par afficher une action sans recommencer seule',async()=>{
 const h=await offlineUI({neverReady:true});await h.tick();assert.equal(h.elements.retryOffline.hidden,false);assert.equal(h.registrations(),1);assert.equal(h.requests.length,0);assert.match(h.elements.offline.textContent,/interrompue|non confirmée|trop longue/i);
});
await test('le mode icône est distingué de l’ouverture dans le navigateur',async()=>{
 const h=await offlineUI({standalone:true});assert.match(h.elements.homeMode.textContent,/icône/i);const b=await offlineUI();assert.match(b.elements.homeMode.textContent,/Safari|navigateur/i);
});
await test('un navigateur sans service worker ne propose pas une fausse installation',async()=>{
 const h=await offlineUI({supported:false});assert.match(h.elements.offline.textContent,/indisponible/i);assert.equal(h.requests.length,0);assert.equal(h.elements.retryOffline.hidden,true);
});
await test('une réponse d’une ancienne version ne valide pas l’interface courante',async()=>{
 const h=await offlineUI();h.emit({type:'SHELL_READY',ok:true,revision:'A80-local-only-1'});assert.doesNotMatch(h.elements.offline.textContent,/enregistrée|prête/i);
});
function shellHarness(){
 const maps=new Map(),requests=[],timers=new Map();let failPath=null,hangPath=null,n=0;
 const caches={open:async name=>{if(!maps.has(name))maps.set(name,new Map());const map=maps.get(name);return{match:async key=>map.get(key)?.clone(),put:async(key,r)=>map.set(key,r.clone())};}};
 const c={URL,Response,Error,AbortController,TransformStream,caches,setTimeout:(fn,ms)=>{const id=++n;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),self:{location:{origin:'https://test.local'},addEventListener(){}},fetch:async(url,opts)=>{
  const path=new URL(url,'https://test.local').pathname;requests.push(path);
  if(path===hangPath)return new Promise((_,reject)=>opts.signal.addEventListener('abort',()=>reject(Error('ABORTED')),{once:true}));
  if(path===failPath)return new Response('temporary',{status:503});
  const html=path==='/'||path==='/atelier.html';return new Response(html?build+'-LOCAL-ONLY':'asset',{headers:{'content-type':html?'text/html':'application/javascript'}});
 }};
 vm.createContext(c);vm.runInContext(src('blob-sw.js')+';globalThis.api={prepareShell,fetchShellAsset,CACHE,ASSETS};',c);
 return{api:c.api,maps,requests,timers,fail:path=>failPath=path,hang:path=>hangPath=path,fetch:fn=>c.fetch=fn};
}
await test('la copie partielle reprend seulement les fichiers absents et finit par confirmer le site',async()=>{
 const h=shellHarness(),first=h.api.ASSETS[0],failed=h.api.ASSETS[3],progress=[];h.fail(failed);await assert.rejects(()=>h.api.prepareShell('https://test.local/',p=>progress.push(p)),/SHELL_ASSET/);assert.equal(h.maps.get(h.api.CACHE).has('/'),false);assert.ok(h.maps.get(h.api.CACHE).has(first));const count=h.requests.filter(x=>x===first).length;h.fail(null);await h.api.prepareShell('https://test.local/',p=>progress.push(p));assert.equal(h.requests.filter(x=>x===first).length,count);assert.equal(progress.at(-1).completed,h.api.ASSETS.length);assert.equal(h.maps.get(h.api.CACHE).has('/'),true);assert.equal(h.timers.size,0);
});
await test('un transfert sans réponse est annulé avec un délai borné et ne recommence pas',async()=>{
 const h=shellHarness();h.hang('/');const attempt=h.api.prepareShell('https://test.local/');const rejected=assert.rejects(()=>attempt,/ABORTED/);await flush();assert.equal(h.requests.length,1);const timer=[...h.timers.values()][0];assert.equal(timer.ms,45000);timer.fn();await rejected;assert.equal(h.requests.length,1);assert.equal(h.maps.get(h.api.CACHE).has('/'),false);assert.equal(h.timers.size,0);
});
await test('les pages disposent des contrôles de reprise et d’identifiants uniques',()=>{
 for(const file of ['index.html','atelier.html']){const html=src(file),ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const id of ['offline','maintenance','retryOffline','refreshApp'])assert.ok(ids.includes(id),file+': '+id);}
});
await test('un fichier lent garde le transfert ouvert tant que des octets arrivent',async()=>{
 const h=shellHarness();let input,signal;const notices=[];
 h.fetch(async(_,opts)=>{signal=opts.signal;return new Response(new ReadableStream({start(c){input=c;signal.addEventListener('abort',()=>{try{c.error(Error('ABORTED'));}catch{}});}}));});
 const transfer=h.api.fetchShellAsset('/slow.js',r=>r.text(),bytes=>notices.push(bytes));await flush();const firstTimer=[...h.timers.keys()][0];input.enqueue(new TextEncoder().encode('début '));await flush();assert.equal(h.timers.has(firstTimer),false);assert.equal(signal.aborted,false);assert.ok(notices[0]>0);input.enqueue(new TextEncoder().encode('fin'));input.close();assert.equal(await transfer,'début fin');assert.equal(h.timers.size,0);
});
await test('une connexion coupée après les en-têtes annule aussi la lecture du corps',async()=>{
 const h=shellHarness();h.fetch(async(_,opts)=>new Response(new ReadableStream({start(c){opts.signal.addEventListener('abort',()=>c.error(Error('ABORTED')),{once:true});}})));
 const transfer=h.api.fetchShellAsset('/stalled.js',r=>r.text());const rejected=assert.rejects(()=>transfer,/ABORTED/);await flush();[...h.timers.values()][0].fn();await rejected;assert.equal(h.timers.size,0);
});
const report={release:build,scope:'UI hors ligne simulée ; aucun navigateur réel',passed:tests.filter(x=>x.passed).length,failed:tests.filter(x=>!x.passed).length,tests};fs.writeFileSync(new URL('./a96-offline.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));

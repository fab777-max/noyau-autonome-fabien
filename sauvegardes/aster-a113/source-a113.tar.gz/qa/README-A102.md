# A102 evidence

Run `node qa/test-a102-conversation.mjs` and `node qa/test-a102-shell.mjs` from the checkout. They write their own JSON reports, without rewriting older evidence. The 25 checks exercise the actual modules under simulated browser/Worker/storage APIs. They never load weights, use paid APIs or touch the phone's data.

`a102-structure.json` records HTML nesting/IDs/local assets and syntax checks for changed JS. Native build and deployment remain separate publication gates. Real Safari rendering, device storage behavior, LLM quality and long runs have not been validated here.

// Rerun only affected retained scenarios against the current modules; preserve past reports.
import fs from 'node:fs';
for(const [name,file] of [['documents','test-a99-documents.mjs'],['projects','test-a98-projects.mjs'],['recovery','test-a98-recovery.mjs']]){
 const url=new URL('./'+file,import.meta.url);
 let code=fs.readFileSync(url,'utf8').replaceAll('import.meta.url',JSON.stringify(url.href));
 code=code.replace("from './memory-double.mjs'","from "+JSON.stringify(new URL('./memory-double.mjs',import.meta.url).href));
 if(name!=='documents'){
  code=code.replace('const core=',"const documents=await import(moduleURL('noyau-documents-core.js')),research=await import(moduleURL('noyau-research-core.js'));\nconst core=");
  code=code.replace('const c={...core,...store,...learning,','const c={...core,...store,...learning,...documents,...research,');
  code=code.replace('const c={...project,','const c={...project,...documents,...research,');
 }
 if(name==='projects')code=code.replace('const report={release:',`await test('le formulaire de projet joint réellement la source et la transmet au lancement',async()=>{const h=await projectUI();h.input('projectGoal','Préparer la réponse client');h.input('projectSteps','Vérifier les faits');await h.click('projectCreate');const ref={documentId:'doc',title:'Brief',importedAt:'2026-10-15T00:00:00Z',start:0,end:18,startLine:1,endLine:1,text:'Délai à confirmer.'};assert.equal(await h.context.window.NoyauProjectWork.attachSource(ref),true);assert.equal(h.el('projectSource').hidden,false);assert.match(h.el('projectSourceText').textContent,/Délai à confirmer/);await h.click('projectRun');assert.equal(h.calls[0].source.text,ref.text);assert.ok(h.calls[0].input.includes(ref.text));assert.equal(await h.context.window.NoyauProjectWork.attachSource(ref),false);});\nconst report={release:`);
 code=code.replaceAll('error:e.stack','error:e.message').replaceAll('A99','A100').replaceAll('A98','A100');
 code=code.replaceAll('a99-'+name+'.json','a100-'+name+'-regressions.json').replaceAll('a98-'+name+'.json','a100-'+name+'-regressions.json');
 code=code.replace('console.log(JSON.stringify(report,null,2));',"console.log(JSON.stringify({suite:'"+name+"',passed:report.passed,failed:report.failed,failures:tests.filter(x=>!x.passed)},null,2));");
 await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
}

# A95 — final recovery and launch check

Date: 2026-10-15. Existing owner-only Site, same origin and model identities.

## Corrected defects

- An old workshop tab could overwrite a restored dossier when its revision matched the revision in the backup. Restoration now advances the revision above both the current and imported revisions in the same atomic transaction as the data replacement and rollback copy. Backups without workshop data receive an empty workshop with a new revision. An unsafe counter fails before any clear or write.
- Overlapping backup-file reads could select the wrong file or let an earlier read error discard the latest valid file. Only the most recent selection may update the candidate and preview.
- Restore now captures the confirmed candidate before waiting for the maintenance lock and disables the other recovery controls. Selecting the rollback copy cancels pending file reads. A completed restore stays locked until page reopening, preventing duplicate replacement of the rollback copy.

The A92/A93 backup formats remain accepted. A95 exports retain the A93 data schema. No database name, version, model manifest, weight-cache identifier or model-download behavior changed.

## Evidence

- `a95-memory.json`: 10 targeted recovery checks passed. Five failure scenarios were demonstrated against the previous implementation before correction.
- `a95-local-regression.json`: 59 existing checks passed, including interruption/resume, preserved model caches, no work at page opening, bounded retries and durable response recording.
- `a95-local-production.json`: 55 existing workshop/export/backup checks passed, including full restore, transaction rollback on simulated storage failure, resumable model download using tiny hashed fixtures, and real PNG/ZIP creation using native canvas.
- Authenticated remote `noyau_list_requests` succeeded after connecting the Site app: empty list, `automaticRuns: false`. This verifies the read connection for the current owner; no test request, claim or report was written to production.
- The Site remains owner-only. D1 tables `agent_tasks` and `agent_events` were observed. The queried recent error log contained only two missing favicon requests.

## Limits and first use

DOM and IndexedDB behavior in these checks are simulated. No physical iPhone Safari, real local-model inference or browser visual QA was performed in this run. The prior A94 API/MCP mutation tests were not rerun because the server and migrations are unchanged. The remote authenticated claim/report cycle is not yet verified.

On the iPhone: close old Noyau tabs, open the existing Site, check A95, export a full backup to Files, and run **TEST COURT : BONJOUR** with the installed model. Keep the page visible. Continue only after reviewing that response; the long exercise campaign is optional and does not train the model weights. The workshop can prepare the first photo pack without running the LLM.

Persistent browser storage is best effort. A separately saved backup is necessary to recover after browser-data deletion or device loss. Backups contain private data in clear text and must remain in the owner's storage.

Rollback uses the previous Site version, without deleting local memory, model caches or the server database.

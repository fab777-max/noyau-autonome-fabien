# A94 acceptance record

The delivered addition is a private request log and MCP access for an agent started in ChatGPT. It is not an embedded autonomous Codex process. Connecting the newly provisioned Site app is still required; no access token is shipped in source or browser code.

Checks completed:

- 25 checks: real SQLite migrations; identity isolation; origin and body limits; idempotency under concurrent and interrupted sends; one-agent claim; stale/cancelled receipt rejection; report evidence; prior report archive; manual owner acceptance and removal; MCP discovery and JSON-RPC tool cycle; safe text rendering and simulated phone-facing request flow.
- 59 existing Blob regression checks adapted to A94 paths and release markers.
- 55 workshop, export and backup checks; the former disconnected JSON task export check now verifies that the workshop links to the request log without transferring client data.
- Byte comparison with A93: 44 existing assets are identical, including model metadata, the WASM runtime, memory and backup modules. Six files change their release markers, navigation or obsolete task-export handler.
- Production framework build succeeds, including `/`, `/api/agent-tasks`, `/mcp`, static workshop assets and both schema-only migrations.

Limits: D1 is represented by a real SQLite adapter in tests. Browser DOM/event handling is simulated, canvas export checks use the native canvas library. No physical iPhone Safari, real model inference, visual browser session or authenticated remote MCP tool call has been tested. No client success, earnings or time savings have been inferred from these checks.

Manual first acceptance after installation: submit one non-sensitive request; copy its instruction into ChatGPT with the Site app connected; read, claim and report using the MCP tools; refresh the Site and verify that the report appears for the same account. A different account must not see that request. The owner can then validate the report. No repeat or polling automation is necessary.

For a deployment rollback, select the previous Site version. A93 does not read the new database, so schema additions remain harmless. Do not roll back by deleting the database or any local model/memory cache.

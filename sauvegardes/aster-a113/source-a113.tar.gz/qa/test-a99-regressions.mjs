// Reuse the retained A98 scenarios against current sources; keep their historical reports unchanged.
import fs from 'node:fs';
for(const name of ['projects','recovery']){
 const url=new URL('./test-a98-'+name+'.mjs',import.meta.url);
 let code=fs.readFileSync(url,'utf8').replaceAll('import.meta.url',JSON.stringify(url.href));
 code=code.replace('const core=','const documents=await import(moduleURL(\'noyau-documents-core.js\'));\nconst core=');
 code=code.replace('const c={...core,...store,...learning,','const c={...core,...store,...learning,...documents,');
 code=code.replace('const c={...project,','const c={...project,...documents,');
 if(name==='projects')code=code.replace('const report={release:',`await test('le formulaire de projet joint réellement la source et la transmet au lancement',async()=>{const h=await projectUI();h.input('projectGoal','Préparer la réponse client');h.input('projectSteps','Vérifier les faits');await h.click('projectCreate');const ref={documentId:'doc',title:'Brief',importedAt:'2026-10-15T00:00:00Z',start:0,end:18,startLine:1,endLine:1,text:'Délai à confirmer.'};assert.equal(await h.context.window.NoyauProjectWork.attachSource(ref),true);assert.equal(h.el('projectSource').hidden,false);assert.match(h.el('projectSourceText').textContent,/Délai à confirmer/);await h.click('projectRun');assert.equal(h.calls[0].source.text,ref.text);assert.ok(h.calls[0].input.includes(ref.text));assert.equal(await h.context.window.NoyauProjectWork.attachSource(ref),false);});\nconst report={release:`);
 code=code.replaceAll('error:e.stack','error:e.message');
 code=code.replaceAll("release:'A98'","release:'A99'").replaceAll('a98-'+name+'.json','a99-'+name+'-regressions.json');
 code=code.replace('console.log(JSON.stringify(report,null,2));',"console.log(JSON.stringify({suite:'"+name+"',passed:report.passed,failed:report.failed,failures:tests.filter(x=>!x.passed)},null,2));");
 await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
}

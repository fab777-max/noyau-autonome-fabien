# Aster A110 — conversation, corrections choisies et fichiers locaux

18 octobre 2026. Implémentation autorisée par Fabien pour tester son interface privée sur téléphone. Source ouverte : version Sites 24 / A109, commit b19c7ee83975452b23482b3fe2ae7e83c16ae0ed. Site conservé : appgprj_6ac867d9813081918708ab8424b79ca3. Le résultat natif de publication fait foi pour la mise en ligne.

## Ce qui change

- Le brouillon général utilise `noyau.home-draft.v1` dans le stockage existant. Une discussion ne crée plus un dossier photo et ne remplace plus le brouillon du projet. Le premier ancien brouillon est copié une fois sans effacement. Les projets se reprennent dans « Mes projets » ; un bouton revient à la discussion.
- Le moteur reçoit un prompt de conversation plus court. Le contexte privilégie la dernière paire question/réponse avant une source facultative volumineuse. Les demandes et les extraits obligatoires restent entiers : un dépassement devient une erreur visible, jamais une lecture documentaire inventée.
- Une réponse peut recevoir une correction du propriétaire, réutilisable au choix. L’original reste présent. Au maximum 32 corrections de 1 200 caractères sont rattachées à l’historique existant. Les corrections pertinentes peuvent guider le contexte ; les notes oubliées sont filtrées. Modifier ou retirer une correction invalide le point de reprise concerné.
- L’export de futurs exemples d’entraînement exige un consentement individuel distinct. Il déduplique les paires et annonce explicitement `weightsTrained:false`. Ce format de préparation n’est pas directement accepté par le pilote synthétique existant : nettoyage, séparation entraînement/évaluation et adaptateur de données restent nécessaires.
- « Fichier » permet d’ajouter un TXT ou MD à la collection locale existante. Une question longue fournit maintenant des mots-clés valides au moteur de recherche. Une relance courte peut reprendre le sujet précédent. La sélection d’un document et les extraits utilisés restent visibles. Un résumé limité à des extraits est présenté comme partiel.
- Le brouillon de réponse peut s’afficher pendant les jetons. Il disparaît sur interruption ; seule une réponse durablement enregistrée devient un message. Chargement, première sortie et génération sont mesurés depuis les événements du Worker, sans durée simulée dans l’application.
- A110 dispose d’une nouvelle copie hors ligne cohérente, incluant le module de corrections. Les caches des modèles et les clés de stockage existantes restent conservés.

## Limites conservées

Une inférence locale utilise le modèle déjà sélectionné : Qwen2.5 0,5B ou 1,5B quantifié. Le contexte reste à 1 024 jetons, la sortie à 256 jetons par étape, un Worker et dix minutes par lancement explicite. Une page masquée met en pause ; la reprise est manuelle. Le temps supplémentaire sert au plan, à la réponse et éventuellement à une correction de forme. Il n’ajoute ni paramètres ni vérification factuelle garantie. Les notes, méthodes et corrections sont du contexte, pas un changement de poids.

Les bornes connues restent : 1 000 messages / 2 Mio dans cette conversation, 32 notes, 32 corrections rattachées à cette même enveloppe, un brouillon de 1 800 caractères maximum, 12 documents / 144 000 caractères, jusqu’à 50 demandes interrompues. Aucun effacement automatique. Les anciens autres espaces de mémoire restent hors de cette garantie globale ; une sauvegarde complète reste bornée à 40 Mio.

Le moteur d’image connecté est toujours inactif : environnement Sites révision 0, aucune variable configurée à la lecture de cette session. Aucun secret, quota ou budget n’a été ajouté. Les retouches locales existantes restent disponibles. Aucun entraînement GPU, adaptateur de poids, fusion, téléchargement de modèle ni appel payant n’a été lancé. Aucun essai réel de qualité, batterie, température ou vitesse iPhone n’a été réalisé.

## Vérification

142 contrôles logiciels réussis : 39 conversation/corrections/documents/Worker, 64 conservation des parcours studio et rendus, 35 stockage partagé/restauration et 4 copie hors ligne. Commandes :

```
node qa/test-a110-conversation.mjs
node qa/test-a110-preserved-studio.mjs
node qa/test-a110-shared-store.mjs
node qa/test-a110-shell.mjs
```

Les gestionnaires et modules sont réels ; DOM, IndexedDB, cache, réseau et inférence sont simulés. Les PNG des contrôles studio sont rendus par Canvas natif Node. Le contrat `onNewToken(token, piece, currentText)` a été vérifié contre le runtime fourni et exercé avec un générateur de test. Cela ne prouve pas une amélioration mesurée de la qualité linguistique.

Pas de validation visuelle navigateur : control-browser indisponible dans l’environnement Sites géré. Aucun navigateur de remplacement n’a été lancé. La compilation de production et la synchronisation de source sont exécutées par le workflow de publication ; sa réussite est requise avant déploiement.

## Essai concret sur le téléphone

1. Ouvrir le même site, actualiser et vérifier A110 en bas de page. Si proposé, « Ouvrir la mise à jour ». Ne pas vider les données du site.
2. Envoyer « Bonjour Aster, je suis Fabien. Pose-moi une question pour faire connaissance. » Si le modèle manque, l’installer via le bouton explicite puis reprendre la demande conservée.
3. Envoyer « Retiens que je préfère des explications simples en français. », puis une question et une relance. Recharger et demander « Que sais-tu de moi ? ».
4. Sous une réponse, ajouter une correction précise ; poser ensuite une question proche. Ce comportement doit être évalué sur la réponse effective, pas sur un compteur d’apprentissage.
5. Ajouter un petit fichier TXT personnel et poser une question dont la réponse y figure. Vérifier les extraits et l’absence de faits ajoutés.
6. Demander une comparaison approfondie, observer la phase et le temps, mettre en pause puis reprendre. Une limite de contexte n’est pas un calcul qui doit tourner indéfiniment.

La prochaine décision dépend des résultats réels de ces essais. Ne pas augmenter automatiquement le contexte, installer un autre modèle ou activer un fournisseur payant sans données matérielles et configuration adaptées. Ce lot rend l’expérience de dialogue plus exploitable ; il ne termine pas les lots d’entraînement, moteur génératif connecté, réseau de calcul et marché multi-utilisateur du plan complet.

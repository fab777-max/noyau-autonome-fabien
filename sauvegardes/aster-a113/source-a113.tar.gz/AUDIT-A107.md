# A107 — images connectées et préparation d’un entraînement réel

17 octobre 2026. Base : A106 / version native 21, commit
`a73335857cfacbeea186dd13f4b04495f835e8c1`. Même site privé, même origine,
mêmes caches de poids. La publication est attestée par le résultat natif Sites.

## Livraison et limites d’activation

La conversation prépare « Crée une image de… », « Remplace le fond de la
photo… » et « Mes images ». Les retouches locales simples et les corrections
de champs gardent la priorité. La demande d’image est enregistrée dans le
projet avant tout envoi. L’état du serveur et les résultats apparaissent dans
la même conversation, sans nouvel onglet de navigation. Les résultats sont
téléchargeables individuellement en PNG ; les photos locales restent intactes.

Le serveur comporte un connecteur pour les endpoints officiels OpenAI Images
`generations` et `edits`, avec `gpt-image-2.5-sunburst`, une seule image,
1024 × 1024, qualité low, PNG. Il est **désactivé** au moment de cette livraison :
aucun secret d’inférence ni quota n’était configuré (environnement révision 0).
La génération et la qualité réelle n’ont donc pas été testées. L’interface
l’annonce et ne présente pas de bouton de lancement tant que l’accès manque.

Activation ultérieure : utiliser le parcours sécurisé OpenAI Developers prévu
par le guide Sites pour `OPENAI_API_KEY`, confirmer l’accès au modèle, définir
un plafond de dépenses chez le fournisseur et un nombre d’appels autorisé,
puis configurer `ASTER_IMAGE_ENABLED=true`, `ASTER_IMAGE_DAILY_CALLS` (1–10)
et `ASTER_IMAGE_TOTAL_CALLS` (1–100). Aucun secret dans le navigateur ou le dépôt.
Les quotas d’appels ne sont **pas** un plafond monétaire ; ils incluent les
essais refusés, incertains et supprimés. Jour compté en UTC. Ne pas activer ou
dépenser sur la seule base de ce fichier. L’accord antérieur sur le crédit
ChatGPT ne prouve pas un droit d’usage API pour ce site hébergé.

## Fiabilité et données

- Identité injectée par Sites, origine vérifiée pour les écritures, chaque
  lecture et suppression limitée au propriétaire. Aucune clé ni réponse
  d’erreur privée du fournisseur n’est renvoyée au navigateur. URL fournisseur
  fixe, aucun proxy arbitraire, pas de SDK qui réessaie en silence.
- Réservation D1 atomique : un seul travail actif, clé idempotente et empreinte
  exacte du brief/source. Un double clic ou la répétition de la même clé ne
  relance pas l’inférence. Maximum 20 travaux conservés. Les tombstones gardent
  le comptage des dépenses, même après suppression.
- Source JPEG/PNG au plus 3 Mio ; corps JSON borné réellement en streaming.
  La source n’est jamais enregistrée dans R2. Elle est transmise au fournisseur
  seulement après accord explicite pour cette demande. Ses propres règles de
  conservation s’appliquent ; aucune promesse de suppression chez lui.
- Réponse amont bornée à 12 Mio ; résultat PNG au plus 8 Mio, signature, structure
  et dimensions vérifiées. Ce contrôle ne juge pas la qualité visuelle et ne
  décode pas tous les pixels. Résultat privé R2 avec empreinte SHA-256, D1 puis
  relecture avant état prêt. Une erreur après commit ne détruit pas le fichier.
- Suppression en deux temps avec état récupérable `deleting`. Un fichier isolé
  après erreur reste privé, borné par les quotas, et supprimable avec son travail.
  Pas de purge automatique des sources ni de l’historique local.
- Appel fournisseur borné à 170 s ; réservation 180 s, attente navigateur 190 s.
  Un arrêt ou une réponse perdue peut avoir été facturé : état incertain et
  vérification par GET, jamais un nouvel appel automatique. **Ce n’est pas une
  file de calcul durable en arrière-plan**. Le maintien du travail après fermeture
  de Safari n’est pas garanti. Aucune vidéo longue n’est exécutée.
- Le brouillon et la clé de tentative font partie des sauvegardes de projet et
  des sauvegardes locales complètes. Les PNG serveur n’y sont pas inclus : ils
  se téléchargent séparément. Restaurer ne relance rien et invalide l’interface
  active. Une copie d’un brief non envoyé reçoit une nouvelle clé.

## Utiliser le temps et préparer les poids

Les estimations image apparaissent après trois réussites comparables du même
moteur et mode. Ce sont des intervalles de temps observés, pas un compte à
rebours garanti. Le mode étudiant estime les étapes restantes à partir de
mesures du même modèle/révision ; il distingue temps d’inférence, chargement,
corrections éventuelles et budget restant. Pas de calcul pour remplir une durée.

Depuis le bilan d’une séance notée, Fabien peut relire et cocher chaque corrigé
fictif à exporter. Aucune photo, demande client, note libre ou sortie brute du
modèle n’entre dans ce jeu. Le consentement est individuel. Les 24 exercices
de comparaison sont strictement réservés ; six autres cas sont réservés à la
validation. Les empreintes et identifiants préviennent les mélanges et doublons.
Les sélections temporaires ne sont pas un nouveau stockage de mémoire.

`training/pilot.py` valide réellement ces exports sans bibliothèque ML. Son
chemin `--train` prépare un pilote PEFT/LoRA textuel hors ligne, avec modèle
Safetensors local, GPU CUDA, budget 1–30 min et 1–100 étapes. Les poids de base
restent figés ; seules les matrices d’adaptation sont optimisées. Baseline,
candidat, perte de validation, changements des paramètres et régressions sont
mesurés. Aucun candidat n’est promu automatiquement. Voir `training/README.md`.

**Le chemin d’entraînement GPU n’a pas été exécuté.** Pas de PyTorch,
Transformers, PEFT ni accès GPU d’entraînement configurés dans cet environnement.
La révision du modèle doit encore être vérifiée contre ses fichiers ; les
versions des dépendances doivent être qualifiées. Les checkpoints n’incluent
pas encore une reprise exacte de l’optimiseur. Les quatre comparaisons
original/mémoire/entraîné/entraîné+mémoire, la fusion/quantification et le test
sur iPhone restent à faire. Un adaptateur textuel ne crée pas de capacité image.

## Vérifications

| Preuve | Résultat | Nature |
|---|---:|---|
| `qa/a107-images.json` | 24/24 | SQLite réel ; R2, réseau, fournisseur et DOM simulés |
| `qa/a107-studio.json` | 59/59 | Modules/gestionnaires réels, stockage et DOM simulés, PNG Node réels |
| `qa/a107-training.json` | 6/6 | Exports et validateur Python réels ; aucun entraînement |
| `qa/a107-shell.json` | 4/4 | Fichiers réels ; service worker/cache/réseau simulés |

93 contrôles logiciels passent. La compilation de production suit via le
workflow Sites. Pas de contrôle navigateur rendu (indisponible dans cet
environnement géré), d’iPhone physique, de température/batterie, d’image IA
réelle, de qualité du modèle ou de vente prouvée. Les suites historiques non
affectées n’ont pas été relancées.

Le produit vendable reste le pack de présentation accompagné déjà disponible,
tant qu’une image réelle n’a pas été validée et son coût mesuré. La totalité du
plan de 120 actions n’est pas réalisée ; `PLAN-A107-EXECUTION.md` fixe les suites.

## Références primaires examinées

- https://developers.openai.com/api/docs/guides/image-generation
- https://developers.openai.com/siwc/token-sharing-open-source
- https://huggingface.co/docs/peft/main/en/developer_guides/lora
- https://huggingface.co/docs/transformers/main/en/chat_templating
- https://arxiv.org/abs/2408.03314

Du temps supplémentaire peut améliorer la recherche de solution et la
vérification. Il ne garantit ni équivalence à un grand modèle, ni capacité
vidéo, ni réduction arbitraire de la mémoire minimale. Aucun calcul quantique
ni apprentissage automatique des poids depuis les visiteurs n’est implémenté.

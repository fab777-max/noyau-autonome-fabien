CREATE TABLE `image_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`client_key` text NOT NULL,
	`project_id` text NOT NULL,
	`prompt` text NOT NULL,
	`mode` text NOT NULL,
	`model` text NOT NULL,
	`fingerprint` text NOT NULL,
	`status` text NOT NULL,
	`created_at` integer NOT NULL,
	`deadline_at` integer NOT NULL,
	`elapsed_ms` integer,
	`result_key` text,
	`result_bytes` integer,
	`result_sha` text,
	`error_code` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `image_jobs_dedupe` ON `image_jobs` (`owner`,`client_key`);--> statement-breakpoint
CREATE INDEX `image_jobs_owner_time` ON `image_jobs` (`owner`,`created_at`);
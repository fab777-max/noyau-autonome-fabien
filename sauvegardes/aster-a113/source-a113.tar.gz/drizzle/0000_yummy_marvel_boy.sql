CREATE TABLE `agent_events` (
	`id` text PRIMARY KEY NOT NULL,
	`task_id` text NOT NULL,
	`owner` text NOT NULL,
	`from_status` text,
	`to_status` text NOT NULL,
	`revision` integer NOT NULL,
	`created_at` integer NOT NULL,
	`detail` text NOT NULL,
	FOREIGN KEY (`task_id`) REFERENCES `agent_tasks`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `agent_events_revision` ON `agent_events` (`task_id`,`revision`);--> statement-breakpoint
CREATE TABLE `agent_tasks` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`dedupe_key` text NOT NULL,
	`request` text NOT NULL,
	`diagnostic` text NOT NULL,
	`fingerprint` text NOT NULL,
	`status` text NOT NULL,
	`revision` integer NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`run_token` text,
	`lease_until` integer,
	`report` text,
	`last_event` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `agent_tasks_dedupe` ON `agent_tasks` (`owner`,`dedupe_key`);--> statement-breakpoint
CREATE INDEX `agent_tasks_owner_time` ON `agent_tasks` (`owner`,`created_at`,`id`);
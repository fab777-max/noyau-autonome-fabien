import { sqliteTable, text, integer, uniqueIndex, index } from "drizzle-orm/sqlite-core";
export const agentTasks = sqliteTable("agent_tasks", {
  id: text("id").primaryKey(), owner: text("owner").notNull(), dedupeKey: text("dedupe_key").notNull(),
  request: text("request").notNull(), diagnostic: text("diagnostic").notNull(), fingerprint: text("fingerprint").notNull(),
  status: text("status").notNull(), revision: integer("revision").notNull(),
  createdAt: integer("created_at").notNull(), updatedAt: integer("updated_at").notNull(),
  runToken: text("run_token"), leaseUntil: integer("lease_until"), report: text("report"),
  lastEvent: text("last_event").notNull(),
}, (t) => [uniqueIndex("agent_tasks_dedupe").on(t.owner, t.dedupeKey), index("agent_tasks_owner_time").on(t.owner, t.createdAt, t.id)]);
export const agentEvents = sqliteTable("agent_events", {
  id: text("id").primaryKey(), taskId: text("task_id").notNull().references(() => agentTasks.id),
  owner: text("owner").notNull(), fromStatus: text("from_status"), toStatus: text("to_status").notNull(),
  revision: integer("revision").notNull(), createdAt: integer("created_at").notNull(), detail: text("detail").notNull(),
  reportSnapshot: text("report_snapshot"),
}, (t) => [uniqueIndex("agent_events_revision").on(t.taskId, t.revision)]);

export const imageJobs = sqliteTable("image_jobs", {
  id: text("id").primaryKey(), owner: text("owner").notNull(), clientKey: text("client_key").notNull(),
  projectId: text("project_id").notNull(), prompt: text("prompt").notNull(), mode: text("mode").notNull(),
  model: text("model").notNull(), fingerprint: text("fingerprint").notNull(), status: text("status").notNull(),
  createdAt: integer("created_at").notNull(), deadlineAt: integer("deadline_at").notNull(), elapsedMs: integer("elapsed_ms"),
  resultKey: text("result_key"), resultBytes: integer("result_bytes"), resultSha: text("result_sha"), errorCode: text("error_code"),
}, (t) => [uniqueIndex("image_jobs_dedupe").on(t.owner, t.clientKey), index("image_jobs_owner_time").on(t.owner, t.createdAt)]);

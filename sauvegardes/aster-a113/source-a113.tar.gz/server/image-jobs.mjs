import {IMAGE_SETTINGS,imageEstimate,imageHash} from '../public/aster-image-core.js';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const INPUT_MAX=3*1024*1024,OUTPUT_MAX=8*1024*1024,DEADLINE=180000;
class ImageError extends Error{constructor(message,status=400){super(message);this.status=status;}}
const fail=(m,s)=>{throw new ImageError(m,s);};
const json=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'private, no-store','x-content-type-options':'nosniff','vary':'Cookie, Authorization'}});
export function imageConfig(env){
 const daily=Number(env.ASTER_IMAGE_DAILY_CALLS),total=Number(env.ASTER_IMAGE_TOTAL_CALLS);
 const ready=env.ASTER_IMAGE_ENABLED==='true'&&typeof env.OPENAI_API_KEY==='string'&&env.OPENAI_API_KEY.length>20&&Number.isInteger(daily)&&daily>=1&&daily<=10&&Number.isInteger(total)&&total>=1&&total<=100&&!!env.BUCKET&&!!env.DB;
 return {ready,provider:'OpenAI',...IMAGE_SETTINGS,dailyCalls:ready?daily:0,totalCalls:ready?total:0,reason:ready?'':'La création d’images attend un accès au moteur et un quota de dépenses configurés. Aucun calcul payant n’est activé.'};
}
async function readBytes(stream,max){
 const reader=stream?.getReader();if(!reader)fail('Contenu manquant.');let size=0,parts=[];
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>max)fail('Fichier ou réponse trop volumineux.',413);parts.push(value);}}catch(e){await reader.cancel().catch(()=>{});throw e;}
 const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return bytes;
}
function decode(base64,max){if(typeof base64!=='string'||base64.length>Math.ceil(max/3)*4||!base64.length||base64.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(base64))fail('Image encodée invalide.');let value;try{value=atob(base64);}catch{fail('Image illisible.');}if(value.length>max)fail('Image trop volumineuse.',413);return Uint8Array.from(value,c=>c.charCodeAt(0));}
function sourceImage(data){
 if(typeof data!=='string')fail('Ajoute une photo avant cette retouche.');
 const match=/^data:image\/(jpeg|png);base64,(.+)$/.exec(data);if(!match)fail('Photo JPEG ou PNG requise.');
 const bytes=decode(match[2],INPUT_MAX),png=bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71;
 if(match[1]==='png'?!png:!(bytes[0]===255&&bytes[1]===216&&bytes[2]===255))fail('Le contenu ne correspond pas au format de la photo.');
 return{bytes,type:'image/'+match[1],extension:match[1]};
}
function pngResult(bytes){
 if(bytes.length<33||![137,80,78,71,13,10,26,10].every((v,i)=>bytes[i]===v)||String.fromCharCode(...bytes.slice(12,16))!=='IHDR')fail('Le moteur n’a pas renvoyé un PNG valide.');
 const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);if(dv.getUint32(16)!==1024||dv.getUint32(20)!==1024)fail('Dimensions inattendues dans le résultat.');
 let offset=8,data=false,ended=false;
 while(offset+12<=bytes.length){const size=dv.getUint32(offset),kind=String.fromCharCode(...bytes.slice(offset+4,offset+8));if(size>OUTPUT_MAX||offset+12+size>bytes.length)fail('PNG tronqué.');if(kind==='IDAT'&&size)data=true;offset+=size+12;if(kind==='IEND'){if(size!==0||offset!==bytes.length)fail('Fin de PNG invalide.');ended=true;break;}}
 if(!data||!ended)fail('PNG incomplet.');
}
function view(row,now){if(!row)return null;return{id:row.id,key:row.client_key,projectId:row.project_id,prompt:row.prompt,mode:row.mode,model:row.model,status:row.status==='running'&&row.deadline_at<=now?'uncertain':row.status,created_at:row.created_at,elapsed_ms:row.elapsed_ms,resultBytes:row.result_bytes,error:row.error_code,sha256:row.result_sha,download:row.status==='ready'?'/api/image-jobs?id='+row.id+'&file=1&download=1':null};}
export function imageStore(env,owner,{now=()=>Date.now(),fetcher=fetch}={}){
 const db=env.DB;if(!db)fail('Stockage temporairement indisponible.',503);
 const sql=(q,...args)=>db.prepare(q).bind(...args),raw=id=>{if(!UUID.test(id||''))fail('Identifiant invalide.');return sql('SELECT * FROM image_jobs WHERE id=? AND owner=?',id,owner).first();};
 async function list(){const rows=(await sql("SELECT * FROM image_jobs WHERE owner=? AND status!='deleted' ORDER BY created_at DESC LIMIT 100",owner).all()).results;return{config:imageConfig(env),items:rows.map(r=>view(r,now())),estimates:{generate:imageEstimate(rows,'generate'),edit:imageEstimate(rows,'edit')}};}
 async function get(id){const r=await raw(id);if(!r||r.status==='deleted')fail('Image introuvable.',404);return view(r,now());}
 async function start(data){
  if(!data||!UUID.test(data.key||'')||typeof data.projectId!=='string'||!data.projectId||data.projectId.length>80||typeof data.prompt!=='string'||!data.prompt.trim()||data.prompt.length>1800||!['generate','edit'].includes(data.mode)||data.consent!==true)fail('Demande ou autorisation d’envoi invalide.');
  const source=data.mode==='edit'?sourceImage(data.image):null;if(data.mode==='generate'&&data.image!=null)fail('Aucune photo attendue pour une création.');
  const digest=source?await imageHash(source.bytes):null;
  const fingerprint=await imageHash(JSON.stringify({projectId:data.projectId,prompt:data.prompt.trim(),mode:data.mode,source:digest}));
  const existing=await sql('SELECT * FROM image_jobs WHERE owner=? AND client_key=?',owner,data.key).first();
  if(existing){if(existing.fingerprint!==fingerprint)fail('Cette tentative contient déjà une autre demande.',409);return view(existing,now());}
  const config=imageConfig(env);if(!config.ready)fail(config.reason,503);
  const id=crypto.randomUUID(),time=now(),day=Math.floor(time/86400000)*86400000;
  // A single conditional insert serializes quota reservation in D1. Deleted and
  // uncertain attempts still consume budget. No SDK retry and no automatic restart.
  const inserted=(await db.batch([sql(`INSERT INTO image_jobs (id,owner,client_key,project_id,prompt,mode,model,fingerprint,status,created_at,deadline_at)
   SELECT ?,?,?,?,?,?,?,?,'running',?,?
   WHERE NOT EXISTS (SELECT 1 FROM image_jobs WHERE owner=? AND status='running' AND deadline_at>?)
   AND (SELECT COUNT(*) FROM image_jobs WHERE owner=? AND created_at>=?)<?
   AND (SELECT COUNT(*) FROM image_jobs WHERE owner=?)<?
   AND (SELECT COUNT(*) FROM image_jobs WHERE owner=? AND status!='deleted')<20
   ON CONFLICT(owner,client_key) DO NOTHING`,id,owner,data.key,data.projectId,data.prompt.trim(),data.mode,config.model,fingerprint,time,time+DEADLINE,owner,time,owner,day,config.dailyCalls,owner,config.totalCalls,owner)]))[0];
  const row=await sql('SELECT * FROM image_jobs WHERE owner=? AND client_key=?',owner,data.key).first();
  if(!row)fail('Un travail est en cours ou le quota est atteint. Consulte les images conservées avant un nouvel essai.',429);
  if(row.fingerprint!==fingerprint)fail('Cette tentative contient déjà une autre demande.',409);
  if(inserted.meta.changes!==1)return view(row,now());
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),DEADLINE-10000);let resultKey=null;
  try{
   let body,headers={authorization:'Bearer '+env.OPENAI_API_KEY},path='generations';
   if(source){path='edits';body=new FormData();for(const [k,v]of Object.entries(IMAGE_SETTINGS))body.set(k,String(v));body.set('prompt',data.prompt.trim());body.append('image[]',new Blob([source.bytes],{type:source.type}),'source.'+source.extension);}
   else{headers['content-type']='application/json';body=JSON.stringify({...IMAGE_SETTINGS,prompt:data.prompt.trim()});}
   const response=await fetcher('https://api.openai.com/v1/images/'+path,{method:'POST',headers,body,signal:controller.signal,redirect:'error'});
   if(!response.ok){await response.body?.cancel();const certain=response.status>=400&&response.status<500&&response.status!==408;
    await db.batch([sql('UPDATE image_jobs SET status=?,error_code=?,elapsed_ms=? WHERE id=? AND owner=?',certain?'failed':'uncertain',certain?'PROVIDER_REFUSED':'OUTCOME_UNKNOWN',now()-time,id,owner)]);return get(id);}
   const payload=JSON.parse(new TextDecoder().decode(await readBytes(response.body,12*1024*1024)));
   if(payload.data?.length!==1)fail('Un seul résultat est attendu.');
   const bytes=decode(payload.data[0].b64_json,OUTPUT_MAX);pngResult(bytes);
   resultKey='images/'+id+'.png';const sha=await imageHash(bytes);
   await env.BUCKET.put(resultKey,bytes,{httpMetadata:{contentType:'image/png'},customMetadata:{sha256:sha}});
   const stored=await env.BUCKET.head(resultKey);if(!stored||stored.size!==bytes.length)throw Error('STORAGE_UNCONFIRMED');
   await db.batch([sql("UPDATE image_jobs SET status='ready',result_key=?,result_bytes=?,result_sha=?,elapsed_ms=? WHERE id=? AND owner=? AND status='running'",resultKey,bytes.length,sha,now()-time,id,owner)]);
   return get(id);
  }catch{
   // Once dispatched, an error may still have incurred provider cost. Never retry.
   // A D1 transport error can occur AFTER the result commit. Keep the private,
   // bounded object until explicit deletion; never destroy a possibly ready PNG.
   await db.batch([sql("UPDATE image_jobs SET status='uncertain',error_code='OUTCOME_UNKNOWN',elapsed_ms=? WHERE id=? AND owner=? AND status='running'",now()-time,id,owner)]);
   return get(id);
  }finally{clearTimeout(timer);}
 }
 async function file(id,download=false){const r=await raw(id);if(!r||r.status!=='ready'||!r.result_key)fail('Image indisponible.',404);const value=await env.BUCKET?.get(r.result_key);if(!value)fail('Fichier indisponible. Aucun nouveau calcul lancé.',404);return new Response(value.body,{headers:{'content-type':'image/png','content-length':String(value.size),'content-disposition':(download?'attachment':'inline')+'; filename="aster-'+id+'.png"','cache-control':'private, no-store','x-content-type-options':'nosniff','vary':'Cookie, Authorization'}});}
 async function remove(id){const r=await raw(id);if(!r)fail('Image introuvable.',404);if(r.status==='running'&&r.deadline_at>now())fail('Attends la fin du travail avant de le retirer.',409);
  // Hide the file first; keep an incomplete deletion visible/retryable after
  // reload. Neither deleting nor deleted records reset the call budget.
  await db.batch([sql("UPDATE image_jobs SET status='deleting',prompt='' WHERE id=? AND owner=?",id,owner)]);
  await env.BUCKET.delete(r.result_key||'images/'+id+'.png');
  await db.batch([sql("UPDATE image_jobs SET status='deleted',result_key=NULL,result_bytes=NULL,result_sha=NULL WHERE id=? AND owner=?",id,owner)]);return{removed:id};
 }
 return{list,get,start,file,remove};
}
export async function imageAPI(request,env,options){
 try{
  const owner=request.headers.get('oai-authenticated-user-id');if(!owner?.trim()||owner.length>256)fail('Connexion ChatGPT nécessaire.',401);
  const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)fail('Origine refusée.',403);
  if(!['GET','POST'].includes(request.method))fail('Méthode refusée.',405);
  // CSRF: writes require browser same-origin proof, not only a cookie.
  if(request.method==='POST'&&origin!==new URL(request.url).origin)fail('Origine de la demande requise.',403);
  const store=imageStore(env,owner,options),q=new URL(request.url).searchParams;
  if(request.method==='GET')return q.has('file')?await store.file(q.get('id'),q.has('download')):json(q.has('id')?await store.get(q.get('id')):await store.list());
  if(!request.headers.get('content-type')?.startsWith('application/json'))fail('JSON requis.',415);
  if(Number(request.headers.get('content-length'))>5*1024*1024)fail('Demande trop volumineuse.',413);
  let data;try{data=JSON.parse(new TextDecoder().decode(await readBytes(request.body,5*1024*1024)));}catch(e){if(e instanceof ImageError)throw e;fail('JSON illisible.');}
  if(data?.action==='start')return json(await store.start(data));
  if(data?.action==='delete')return json(await store.remove(data.id));
  fail('Action inconnue.');
 }catch(e){return json({error:e instanceof ImageError?e.message:'Enregistrement non confirmé. Actualise l’état ; ne relance pas le calcul.'},e instanceof ImageError?e.status:503);}
}

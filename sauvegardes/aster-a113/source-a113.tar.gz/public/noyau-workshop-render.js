// Native canvas compositions. No external assets, tracking or generative image model.
import {photoEdit,hasPhotoEdit} from '/aster-photo-core.js?v=A105';
export function loadImage(src) {
  return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(Error('Photo illisible. Choisis une image JPEG, PNG ou un format reconnu par Safari.'));image.src=src;});
}
export async function importPhoto(file,id) {
  if(!file || file.size>25*1024*1024 || !(/^image\//.test(file.type)||/\.(heic|heif|jpe?g|png|webp)$/i.test(file.name)))throw Error('Choisis une photo de moins de 25 Mio.');
  const url=URL.createObjectURL(file);
  try {
    const image=await loadImage(url);
    if(!image.naturalWidth||!image.naturalHeight||image.naturalWidth*image.naturalHeight>65000000)throw Error('Dimensions de photo non prises en charge.');
    const scale=Math.min(1,1600/Math.max(image.naturalWidth,image.naturalHeight)),canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const ctx=canvas.getContext('2d');if(!ctx)throw Error('Composition d’image indisponible.');
    ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    let data='';for(const quality of [.86,.72,.55]){data=canvas.toDataURL('image/jpeg',quality);if(data.length<=1000000)break;}
    if(data.length>1000000||!data.startsWith('data:image/jpeg;base64,'))throw Error('Photo encore trop lourde après réduction.');
    const result={id,name:file.name.slice(0,150),data,width:canvas.width,height:canvas.height};canvas.width=canvas.height=1;return result;
  } finally { URL.revokeObjectURL(url); }
}
export function wrapLines(ctx,text,width) {
  const lines=[];let line='';
  for(const word of String(text).split(/\s+/).filter(Boolean)){
    if(ctx.measureText(word).width>width){
      if(line){lines.push(line);line='';}
      let fragment='';for(const character of word){if(fragment&&ctx.measureText(fragment+character).width>width){lines.push(fragment);fragment='';}fragment+=character;}line=fragment;
    } else if(line&&ctx.measureText(line+' '+word).width>width){lines.push(line);line=word;}else line+=(line?' ':'')+word;
  }
  if(line)lines.push(line);return lines;
}
function fitText(ctx,text,x,y,width,{size,min=26,maxLines=3,color='#183c31',weight=600}={}) {
  let lines;
  for(;size>=min;size-=2){ctx.font=weight+' '+size+'px system-ui, -apple-system, sans-serif';lines=wrapLines(ctx,text,width);if(lines.length<=maxLines)break;}
  if(size<min)throw Error('Un texte ne tient pas dans le visuel. Raccourcis le titre ou le contact.');
  ctx.fillStyle=color;ctx.textBaseline='top';for(const line of lines){ctx.fillText(line,x,y);y+=size*1.23;}return y;
}
export async function poster(dossier,kind) {
  const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=kind==='story'?1920:1350;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Export image indisponible.');
  const f=dossier.facts,story=kind==='story',photoHeight=story?990:690;
  ctx.fillStyle='#f2f0e7';ctx.fillRect(0,0,1080,canvas.height);ctx.fillStyle='#204d3b';ctx.fillRect(0,0,1080,16);
  const businessBottom=fitText(ctx,f.business,60,story?74:32,960,{size:32,min:22,maxLines:2});
  const top=Math.max(story?160:72,businessBottom+20);
  const image=await photoCanvas(dossier.photos[0]),scale=Math.min(960/image.width,photoHeight/image.height),w=image.width*scale,h=image.height*scale;
  ctx.fillStyle='#dce5db';ctx.fillRect(60,top,960,photoHeight);ctx.drawImage(image,60+(960-w)/2,top+(photoHeight-h)/2,w,h);
  image.width=image.height=1;
  let y=top+photoHeight+38;
  y=fitText(ctx,f.title,60,y,960,{size:story?68:60,min:44,maxLines:3});
  y=fitText(ctx,[f.city,f.date].filter(Boolean).join(' · '),60,y+24,960,{size:30,min:24,maxLines:2,color:'#4d6659',weight:400});
  if(f.price)y=fitText(ctx,'Prix communiqué : '+f.price,60,y+24,960,{size:30,min:24,maxLines:2,weight:400});
  if(f.contact){if(y+45>canvas.height-150)throw Error('Titre trop long pour ce visuel : raccourcis-le pour conserver le contact.');fitText(ctx,f.contact,60,Math.max(y+30,canvas.height-(story?180:145)),960,{size:28,min:22,maxLines:3,weight:400});}
  if(y>canvas.height-75)throw Error('Contenu trop long pour le visuel.');
  return canvas;
}
export const canvasBlob=canvas=>new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('Fichier PNG non créé.')),'image/png'));

// Always render from the imported copy, never from a previously retouched JPEG.
// Only small settings are persisted. Pixel work yields regularly to the UI.
export async function photoCanvas(photo,{signal,yieldFrame=()=>new Promise(resolve=>setTimeout(resolve,0))}={}){
  const e=photoEdit(photo.edit),check=()=>signal?.throwIfAborted();check();
  const image=await loadImage(photo.data);check();
  const iw=image.naturalWidth,ih=image.naturalHeight;
  if(!iw||!ih||iw>1600||ih>1600)throw Error('Dimensions de la copie photo invalides.');
  const rotated=e.rotation===90||e.rotation===270,w=rotated?ih:iw,h=rotated?iw:ih,side=Math.min(w,h);
  const canvas=document.createElement('canvas');canvas.width=e.crop==='square'?side:w;canvas.height=e.crop==='square'?side:h;
  try{
    const ctx=canvas.getContext('2d');if(!ctx)throw Error('Retouche photo indisponible.');
    ctx.save();ctx.translate(canvas.width/2,canvas.height/2);ctx.rotate(e.rotation*Math.PI/180);ctx.drawImage(image,-iw/2,-ih/2);ctx.restore();
    if(e.brightness||e.contrast||e.monochrome){
      const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),p=pixels.data,factor=(100+e.contrast)/100,offset=e.brightness*2.55,chunk=canvas.width*4*32;
      for(let start=0;start<p.length;start+=chunk){
        check();const end=Math.min(p.length,start+chunk);
        for(let i=start;i<end;i+=4){
          if(e.monochrome){const l=.2126*p[i]+.7152*p[i+1]+.0722*p[i+2];p[i]=p[i+1]=p[i+2]=l;}
          for(let c=0;c<3;c++)p[i+c]=(p[i+c]-128)*factor+128+offset;
        }
        if(end<p.length)await yieldFrame();
      }
      check();ctx.putImageData(pixels,0,0);
    }
    check();return canvas;
  }catch(e){canvas.width=canvas.height=1;throw e;}
}
// Ephemeral export representation. Never save these generated image copies.
export async function photoDeliveryDossier(dossier){
  const d={...dossier,photos:[]};
  for(const p of dossier.photos){
    if(!hasPhotoEdit(p)){d.photos.push(p);continue;}
    const canvas=await photoCanvas(p);
    try{const next={...p,data:canvas.toDataURL('image/png'),width:canvas.width,height:canvas.height};delete next.edit;d.photos.push(next);}
    finally{canvas.width=canvas.height=1;}
  }
  return d;
}

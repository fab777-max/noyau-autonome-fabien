// FR/EN task routing and strict validation of optional LLM proposals.
export const TASKS={
 'event-clean':'Remove duplicate events / supprimer les doublons',
 'positive-clean':'Keep positive unique events / événements positifs uniques',
 'category-sum':'Sum amounts by category / total par catégorie',
 'category-count':'Count unique events by category / compter par catégorie',
 'category-priority':'Rank category totals / catégories prioritaires',
 'event-ranking':'Rank event priorities / classer les priorités',
 'high-value-ranking':'Rank large amounts / classer les montants élevés',
 'net-total':'Total after fees / total net après frais',
 'risk-rollup':'Adjust category totals for risk / synthèse du risque',
 'customer-join':'Match events and customers / rapprocher les clients',
 'region-total':'Regional totals after deduplication / totaux régionaux uniques',
 'recovery-priority':'Rank positive ready events / priorités positives',
 'joined-net':'Join customers and sum net amounts by region / total net régional',
 'joined-count':'Join customers and count by region / comptage régional',
 'joined-risk':'Join customers and sum adjusted risk by region / risque régional'
};
export function validateTaskProposal(value){
 if(!value||Object.getPrototypeOf(value)!==Object.prototype||Object.keys(value).some(k=>!['recipeId','reason','params','proofGranted'].includes(k))||!Object.hasOwn(TASKS,value.recipeId)||('proofGranted'in value&&value.proofGranted!==false))throw Error('ASSISTANT_TASK_INVALID');
 if(typeof value.reason!=='string'||value.reason.length>800)throw Error('ASSISTANT_REASON_INVALID');
 const params=value.params;
 if(params&&(Object.keys(params).some(k=>!['k','minAmount','riskLimit'].includes(k))||('k'in params&&(!Number.isInteger(params.k)||params.k<1||params.k>32))||('minAmount'in params&&(!Number.isFinite(params.minAmount)||Math.abs(params.minAmount)>1000))||('riskLimit'in params&&(!Number.isInteger(params.riskLimit)||params.riskLimit<0||params.riskLimit>100))))throw Error('ASSISTANT_PARAMS_INVALID');
 return {recipeId:value.recipeId,reason:value.reason,...(params?{params}:{}),proofGranted:false};
}
export function parseTaskProposal(text){
 if(typeof text!=='string'||text.length>8192)throw Error('ASSISTANT_OUTPUT_BOUNDS');
 const first=text.indexOf('{'),last=text.lastIndexOf('}');if(first<0||last<=first)throw Error('ASSISTANT_JSON_REQUIRED');const raw=JSON.parse(text.slice(first,last+1));if(Number.isInteger(raw.task)&&raw.task>=0&&raw.task<Object.keys(TASKS).length&&Object.keys(raw).every(k=>['task','reason','params'].includes(k))){raw.recipeId=Object.keys(TASKS)[raw.task];delete raw.task;}return validateTaskProposal(raw);
}
export function routeTask(text){
 if(typeof text!=='string'||!text.trim()||text.length>2000)throw Error('ASSISTANT_REQUEST_BOUNDS');
 const t=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();let id;
 const region=/region|regional|client|customer/.test(t),risk=/risqu|risk/.test(t),net=/net|frais|fees/.test(t),count=/compt|count|nombre/.test(t),join=/rapproch|joint|match|join|client|customer/.test(t);
 if(region&&risk)id='joined-risk';else if(region&&net)id='joined-net';else if(region&&count)id='joined-count';else if(/doublon|duplicate|dedup|en double|repeated events/.test(t))id=/positi/.test(t)?'positive-clean':'event-clean';
 else if(risk)id='risk-rollup';else if(net)id='net-total';else if(join)id='customer-join';else if(count)id='category-count';else if(/priorit/.test(t))id=/categor/.test(t)?'category-priority':'event-ranking';else if(/class|rank|top|largest|grand|eleve/.test(t))id='high-value-ranking';else if(/somme|sum|total|categor/.test(t))id='category-sum';
 if(!id)return null;
 return validateTaskProposal({recipeId:id,reason:TASKS[id]});
}
export function taskMessages(text){const choices=Object.entries(TASKS).map(([id,label],i)=>i+': '+label).join('\n');return [{role:'system',content:'Select exactly one task NUMBER from the list. Return ONLY JSON {"task":NUMBER,"reason":"short explanation"}. Respond in the user language. Never invent a task number.\n'+choices},{role:'user',content:'Remove duplicate events.'},{role:'assistant',content:'{"task":0,"reason":"Remove repeated events."}'},{role:'user',content:text}];}
export function compactMessages(text){
 if(typeof text!=='string'||!text.trim()||text.length>1000)throw Error('ASSISTANT_REQUEST_BOUNDS');
 const choices=Object.entries(TASKS).map(([id,label],i)=>String.fromCharCode(65+i)+': '+label.split(' / ')[0]).join('\n');
 return [{role:'system',content:'Classify the request. Reply with ONLY one letter A to O. No explanation.\n'+choices},
 {role:'user',content:'Supprime les événements en double.'},{role:'assistant',content:'A'},
 {role:'user',content:text}];
}
export function parseCompactProposal(text){
 if(typeof text!=='string'||text.length>100)throw Error('ASSISTANT_CHOICE_INVALID');
 const clean=text.trim().replace(/^["'`]|["'`.!]$/g,''),match=clean.match(/^[A-O]$/);
 const recipeId=match?Object.keys(TASKS)[match[0].charCodeAt(0)-65]:clean;
 if(!Object.hasOwn(TASKS,recipeId))throw Error('ASSISTANT_CHOICE_INVALID');
 return validateTaskProposal({recipeId,reason:TASKS[recipeId].split(' / ')[1]||TASKS[recipeId],proofGranted:false});
}

// One bounded production conversation. Supplied facts are preserved verbatim.
// This composer is deterministic; it is not a general agent or a vision model.
import {FIELDS, freshDossier, cleanFacts, composeCaptions, workshopState} from '/noyau-workshop-core.js?v=A105';
import {imageDraft} from '/aster-image-core.js?v=A107';

export const FIELD_NAMES = {business:'nom à afficher', title:'titre', details:'description', city:'ville', date:'date', contact:'contact', price:'prix'};
export const MAX_MESSAGES = 120;
const copy = value => structuredClone(value);
export const normal = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();

export function studioConversation(raw) {
  if (raw == null) return {schema:1, messages:[], draft:'', editing:null};
  if (raw.schema !== 1 || !Array.isArray(raw.messages) || raw.messages.length > MAX_MESSAGES ||
      typeof raw.draft !== 'string' || raw.draft.length > 1800 ||
      (raw.editing !== null && !Object.keys(FIELDS).concat('caption0','caption1','caption2').includes(raw.editing))) throw Error('Conversation de projet incompatible.');
  imageDraft(raw.imageRequest);
  for (const m of raw.messages) if (!m || !['user','assistant'].includes(m.role) || typeof m.text !== 'string' || m.text.length > 2000 || typeof m.at !== 'string' || !Number.isFinite(Date.parse(m.at))) throw Error('Message de projet incompatible.');
  return copy(raw);
}
export function studioDossier(raw) {
  const d = copy(raw);
  d.studio = studioConversation(d.studio);
  if(d.facts.business && d.facts.title && d.facts.details && (d.captions.length!==3 || d.captions.some(t=>!t.trim()))) {
    const templates=composeCaptions(d.facts);
    d.captions=templates.map((text,i)=>d.captions[i]?.trim()?d.captions[i]:text);
    d.factsConfirmed=false;d.validatedAt=null;
  }
  return d;
}
export function newStudioDossier(id, now) { return studioDossier(freshDossier(id, now)); }
export function nextStep(d) {
  if (d.studio?.editing) return d.studio.editing;
  if (!d.facts.details) return 'details';
  if (!d.facts.business) return 'business';
  if (!d.facts.title) return 'title';
  if (!d.photos.length) return 'photos';
  return 'review';
}
export function questionFor(d) {
  const key = nextStep(d);
  if (key.startsWith('caption')) return 'Écris le nouveau texte '+(Number(key.at(-1))+1)+'. Il remplacera uniquement celui-ci.';
  const questions = {
    details:'Raconte la réalisation que tu veux présenter. Tu peux dicter avec ton clavier et joindre tes photos.',
    business:'Quel nom ou quelle entreprise dois-je afficher sur la présentation ?',
    title:'Quel titre veux-tu afficher ? Par exemple : « Rénovation d’une terrasse ».',
    photos:'Ajoute au moins une photo avec le bouton Photos. Je pourrai ensuite préparer les aperçus.',
    review:'Ta présentation est prête à relire ci-dessous. Tu peux me demander « change le titre » ou corriger un texte, puis récupérer tes fichiers.',
    city:'Quelle ville dois-je afficher ? Écris « sans » pour la retirer.',
    date:'Quelle date ou période dois-je afficher ? Écris « sans » pour la retirer.',
    contact:'Quel contact souhaites-tu rendre visible ? Écris « sans » pour le retirer.',
    price:'Quel prix confirmé dois-je afficher ? Écris « sans » pour le retirer.'
  };
  return questions[key];
}
export function record(d, role, text, now = new Date().toISOString()) {
  if (d.studio.messages.length >= MAX_MESSAGES) throw Error('Cette conversation est complète. Sauvegarde ce projet et poursuis dans une nouvelle copie.');
  d.studio.messages.push({role,text,at:now}); d.updatedAt=now; return d;
}
export function invalidateApproval(d) {
  d.factsConfirmed=false; d.validatedAt=null;
  return d;
}
function setFact(d,key,value) {
  if (!Object.hasOwn(FIELDS,key)) throw Error('Champ inconnu.');
  const clean = !['business','title','details'].includes(key) && ['sans','aucun','aucune','retirer'].includes(normal(value)) ? '' : value.trim();
  if (['business','title','details'].includes(key) && !clean) throw Error('Cette information est nécessaire.');
  if (clean.length > FIELDS[key]) throw Error('Le '+FIELD_NAMES[key]+' peut contenir '+FIELDS[key]+' caractères. Raccourcis-le ; ton texte reste dans la zone de saisie.');
  d.facts=cleanFacts({...d.facts,[key]:clean});
  if (d.facts.business && d.facts.title && d.facts.details) {
    // A fact edit refreshes template captions; user-written captions must be kept for review.
    if (d.source === 'TEMPLATES' || !d.captions.length) d.captions=composeCaptions(d.facts);
  }
  invalidateApproval(d);
}
const aliases = {
  nom:'business', entreprise:'business', professionnel:'business', titre:'title',
  description:'details', realisation:'details', faits:'details', ville:'city',
  date:'date', periode:'date', contact:'contact', telephone:'contact', prix:'price'
};
export function editCommand(text) {
  const m = /^(?:change|changer|modifie|modifier|remplace|remplacer|ajoute|ajouter|corrige|corriger)\s+(?:(?:le|la|les|mon|ma|mes|un|une)\s+)?(nom|entreprise|professionnel|titre|description|realisation|faits|ville|date|periode|contact|telephone|prix|texte\s*[123])(?:\s*(?::|par|avec|en)\s*(.+))?\s*$/is.exec(normal(text));
  if (!m) return null;
  const key = m[1].startsWith('texte') ? 'caption'+(Number(m[1].match(/[123]/)[0])-1) : aliases[m[1]];
  // Do not use the normalized value: preserve accents, case and wording.
  const raw = /^(?:change|changer|modifie|modifier|remplace|remplacer|ajoute|ajouter|corrige|corriger)\s+(?:(?:le|la|les|mon|ma|mes|un|une)\s+)?\S+(?:\s*[123])?(?:\s*(?::|par|avec|en)\s*(.+))?\s*$/is.exec(text.trim());
  return {key,value:m[2] ? raw?.[1]?.trim() || null : null};
}
function setValue(d,key,value) {
  if (!key.startsWith('caption')) { setFact(d,key,value); return; }
  if (d.captions.length !== 3) throw Error('Complète d’abord les informations de la présentation.');
  if (!value.trim() || value.length > 1800) throw Error('Le texte doit contenir entre 1 et 1 800 caractères.');
  d.captions[Number(key.at(-1))]=value.trim(); d.source='OWNER_EDITED'; invalidateApproval(d);
}
export function submitMessage(raw,text,now = new Date().toISOString()) {
  const d=studioDossier(raw), value=text.trim();
  if (!value || value.length > 1800) throw Error('Écris une demande de 1 à 1 800 caractères.');
  if (d.studio.messages.length > MAX_MESSAGES-2) throw Error('Conversation pleine. Sauvegarde ce projet avant de continuer dans une copie.');
  const step=nextStep(d), command=!d.studio.editing && editCommand(value);
  let answer;
  if (!d.studio.editing && /^(?:bonjour|salut|coucou|bonsoir|hello|merci)[\s!.]*$/i.test(normal(value))) {
    answer='Bonjour ! '+questionFor(d);
  } else if (step==='details' && /^(?:cree|prepare|fais|je veux|je voudrais|peux.tu)(?:\s+moi)?\s+(?:un|une|ma|mon)\s+(?:pack|presentation|fiche|publication)(?:\s+(?:avec|a partir de)\s+mes photos)?[\s!.]*$/i.test(normal(value))) {
    answer='D’accord. Décris les faits de ta réalisation : ce qui a été fait et ce que tu veux montrer.';
  } else if (command) {
    if (command.value) { setValue(d,command.key,command.value); d.studio.editing=null; answer='Modification conservée. '+questionFor(d); }
    else { d.studio.editing=command.key; answer=questionFor(d); }
  } else if (d.studio.editing) {
    if (normal(value)==='annuler') { d.studio.editing=null; answer='Modification annulée. '+questionFor(d); }
    else { setValue(d,d.studio.editing,value); d.studio.editing=null; answer='Modification conservée. '+questionFor(d); }
  } else if (['details','business','title'].includes(step)) {
    // Explicit labelled lines allow a full brief in one message, without guessed entities.
    const lines=value.split('\n'), parsed={}, rest=[];
    for (const line of lines) { const pair=/^([^:]{1,20})\s*:\s*(.*)$/.exec(line); const key=pair && aliases[normal(pair[1])]; if (key) {if(Object.hasOwn(parsed,key))throw Error('Une information apparaît deux fois : '+FIELD_NAMES[key]+'. Garde une seule version.');parsed[key]=pair[2].trim();} else rest.push(line); }
    if (Object.keys(parsed).length) { for(const [key,v] of Object.entries(parsed))setFact(d,key,v); if(rest.join('\n').trim()){if(parsed.details)throw Error('Ajoute les lignes restantes à la description pour ne rien perdre.');setFact(d,'details',rest.join('\n'));} }
    else if (step==='details' && /(?:https?:\/\/|\b(?:code|javascript|python|internet|recherche|video|image generee|agent)\b)/.test(normal(value)) && /\b(?:cherche|recherche|programme|code|genere|cree|lance)\b/.test(normal(value))) {
      answer='Cet espace prépare une présentation avec tes photos et tes informations. Il ne lance pas de recherche web, de programme ou de vidéo. Pour commencer, raconte la réalisation à présenter.';
    } else setFact(d,step,value);
    answer ||= questionFor(d);
  } else {
    answer=step==='photos' ? questionFor(d) : 'Pour une correction, dis par exemple « change le titre », « ajoute le contact » ou « modifie le texte 1 ». Les versions actuelles sont affichées ci-dessous.';
  }
  record(d,'user',value,now); record(d,'assistant',answer,now); d.studio.draft='';
  return d;
}
export function beginEdit(raw,key) {
  const d=studioDossier(raw);
  if (!Object.keys(FIELDS).concat('caption0','caption1','caption2').includes(key)) throw Error('Modification inconnue.');
  d.studio.editing=key;
  return record(d,'assistant',questionFor(d));
}
export function addPhotos(raw,photos) {
  const d=studioDossier(raw); d.photos.push(...photos); d.rightsConfirmed=false; invalidateApproval(d);
  workshopState({schema:1,revision:0,dossiers:[d]});
  return record(d,'assistant',photos.length+' photo'+(photos.length>1?'s':'')+' ajoutée'+(photos.length>1?'s':'')+'. '+questionFor(d));
}
export function exportPrivateProject(raw) {
  const d=studioDossier(raw); workshopState({schema:1,revision:0,dossiers:[d]});
  return JSON.stringify({schema:'noyau-dossier-v1',dossier:d});
}
export function importPrivateProject(text,id,now=new Date().toISOString()) {
  if (new TextEncoder().encode(text).length > 8*1024*1024) throw Error('Projet supérieur à 8 Mio.');
  const data=JSON.parse(text);
  if (data.schema!=='noyau-dossier-v1') throw Error('Choisis une sauvegarde de projet Aster.');
  workshopState({schema:1,revision:0,dossiers:[data.dossier]});
  const d=studioDossier(data.dossier); d.id=id; d.updatedAt=now;
  // Keep attempted keys for recovery; a copied unsubmitted request needs a new
  // reservation and explicit consent. Never reuse another project's draft key.
  if(d.studio.imageRequest&&!d.studio.imageRequest.attempted){d.studio.imageRequest.projectId=id;d.studio.imageRequest.key=crypto.randomUUID();}
  for(const r of d.runs)if(r.status==='RUNNING'){r.status='INTERRUPTED';r.error='Import sans reprise de calcul.';}
  // Import does not transfer fresh consent to publish or approve generated text.
  d.factsConfirmed=false; d.rightsConfirmed=false; d.validatedAt=null;
  return d;
}

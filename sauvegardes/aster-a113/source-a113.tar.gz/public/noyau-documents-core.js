// Small, bounded lexical retrieval. Original text is never rewritten by a model.
export const DOCUMENTS_KEY='noyau.documents.v1',DOCUMENT_DRAFT_KEY='noyau.documents.draft.v1';
export const DOCUMENT_LIMITS=Object.freeze({count:12,characters:24000,total:144000,fileBytes:98304,excerpt:360,results:6});
const clone=x=>structuredClone(x),str=(s,n,empty=false)=>typeof s==='string'&&s.length<=n&&(empty||!!s.trim());
const plain=x=>x&&typeof x==='object'&&!Array.isArray(x);
const clean=s=>s.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n');
const binary=s=>/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(s);
const fail=()=>{throw Error('Documents incompatibles. Conserve une sauvegarde avant de continuer.');};
export function documentDraft(raw){
 if(raw==null)return {title:'',text:''};
 if(!plain(raw)||!str(raw.title,80,true)||!str(raw.text,DOCUMENT_LIMITS.characters,true))fail();
 return {title:raw.title,text:raw.text};
}
export function documentsState(raw){
 if(raw==null)return {schema:1,revision:0,documents:[]};
 if(!plain(raw)||raw.schema!==1||!Number.isSafeInteger(raw.revision)||raw.revision<0||!Array.isArray(raw.documents)||raw.documents.length>DOCUMENT_LIMITS.count)fail();
 const ids=new Set();let total=0;
 for(const d of raw.documents){
  if(!plain(d)||!str(d.id,100)||ids.has(d.id)||!str(d.title,80)||!str(d.text,DOCUMENT_LIMITS.characters)||binary(d.text)||clean(d.text)!==d.text||!str(d.importedAt,40)||!Number.isFinite(Date.parse(d.importedAt)))fail();
  ids.add(d.id);total+=d.text.length;
 }
 if(total>DOCUMENT_LIMITS.total)fail();
 return clone(raw);
}
export function addDocument(raw,{title,text},id,at=new Date().toISOString()){
 const state=documentsState(raw);title=title.trim();text=clean(text);
 if(!str(title,80)||!str(text,DOCUMENT_LIMITS.characters)||binary(text))throw Error('Ajoute un titre et du texte lisible (24 000 caractères maximum). Aucun fichier n’a été tronqué.');
 if(state.documents.some(d=>d.text===text))throw Error('Ce texte est déjà conservé. Aucun doublon ajouté.');
 if(state.documents.length>=DOCUMENT_LIMITS.count||state.documents.reduce((n,d)=>n+d.text.length,0)+text.length>DOCUMENT_LIMITS.total)throw Error('Limite atteinte : 12 documents ou 144 000 caractères au total. Aucun ancien document effacé.');
 state.documents.push({id,title,text,importedAt:at});return documentsState(state);
}
export function removeDocument(raw,id){const state=documentsState(raw);state.documents=state.documents.filter(d=>d.id!==id);return state;}
export async function readTextFile(file){
 if(!file||! /\.(txt|md)$/i.test(file.name)||file.size>DOCUMENT_LIMITS.fileBytes)throw Error('Choisis un fichier TXT ou MD UTF-8 de 96 Kio maximum. PDF et images ne sont pas lus ici.');
 let text;try{text=clean(new TextDecoder('utf-8',{fatal:true}).decode(await file.arrayBuffer()));}catch{throw Error('Le fichier n’est pas un texte UTF-8 lisible.');}
 if(!str(text,DOCUMENT_LIMITS.characters)||binary(text))throw Error('Texte vide, illisible ou supérieur à 24 000 caractères. Aucun contenu tronqué.');
 return {title:file.name.slice(0,80),text};
}
const stop=new Set('a au aux avec ce ces cet cette chez comment dans de des du elle en es est et eu eux fait faire il ils je la le les leur lui ma mais me mes moi mon ne nos notre nous on ou par pas pour pourquoi qu que quel quelle quelles quels qui sa sans se ses si son sont sur ta te tes toi ton tous tout toutes tu un une vos votre vous y'.split(' '));
export function searchTerms(text){return [...new Set((text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().match(/[\p{L}\p{N}]+/gu)||[]).filter(t=>t.length>1&&!stop.has(t)))];}
const lineAt=(text,offset)=>1+(text.slice(0,offset).match(/\n/g)||[]).length;
export function sourceExcerpt(d,start,end){
 if(!d||!Number.isInteger(start)||!Number.isInteger(end)||start<0||end<=start||end>d.text.length||end-start>DOCUMENT_LIMITS.excerpt)fail();
 return validateExcerpt({documentId:d.id,title:d.title,importedAt:d.importedAt,start,end,startLine:lineAt(d.text,start),endLine:lineAt(d.text,end-1),text:d.text.slice(start,end)});
}
export function validateExcerpt(x){
 if(!plain(x)||!str(x.documentId,100)||!str(x.title,80)||!str(x.importedAt,40)||!Number.isFinite(Date.parse(x.importedAt))||!str(x.text,DOCUMENT_LIMITS.excerpt)||!Number.isInteger(x.start)||!Number.isInteger(x.end)||x.start<0||x.end>x.start+DOCUMENT_LIMITS.excerpt||x.end-x.start!==x.text.length||!Number.isInteger(x.startLine)||!Number.isInteger(x.endLine)||x.startLine<1||x.endLine!==x.startLine+(x.text.match(/\n/g)||[]).length-(x.text.endsWith('\n')?1:0))fail();
 return clone(x);
}
export function excerptLabel(x){return x.title+' · lignes '+x.startLine+(x.endLine!==x.startLine?'–'+x.endLine:'');}
// Overlap preserves a short sentence crossing a window boundary; offsets refer to stored text.
function chunks(d){
 const out=[];let start=0;
 while(start<d.text.length){
  while(/\s/.test(d.text[start]||'')&&start<d.text.length)start++;
  if(start>=d.text.length)break;
  let end=Math.min(start+DOCUMENT_LIMITS.excerpt,d.text.length);
  if(end<d.text.length){const cut=d.text.slice(start,end).search(/\s+\S*$/);if(cut>DOCUMENT_LIMITS.excerpt/2)end=start+cut;}
  if(end<d.text.length&&/[\uD800-\uDBFF]/.test(d.text[end-1]))end--;
  while(end>start&&/\s/.test(d.text[end-1]))end--;
  if(end<=start)break;
  out.push(sourceExcerpt(d,start,end));if(end===d.text.length)break;
  let next=Math.max(start+1,end-70);while(next<end&&!/\s/.test(d.text[next-1]))next++;
  start=next;
 }
 return out;
}
export function searchDocuments(raw,query,documentId=''){
 const state=documentsState(raw);if(!str(query,200))return [];
 const terms=searchTerms(query).slice(0,20);if(!terms.length)return [];
 const rows=state.documents.filter(d=>!documentId||d.id===documentId).flatMap(chunks).map(excerpt=>({excerpt,terms:searchTerms(excerpt.text),titleTerms:searchTerms(excerpt.title)}));
 const frequencies=new Map(terms.map(t=>[t,rows.filter(r=>r.terms.includes(t)).length]));
 const average=rows.reduce((n,r)=>n+r.terms.length,0)/Math.max(1,rows.length);
 const ranked=rows.map(r=>{
  const matched=terms.filter(t=>r.terms.includes(t));let score=0;
  for(const t of matched){const idf=Math.log(1+(rows.length-frequencies.get(t)+0.5)/(frequencies.get(t)+0.5));score+=idf*2.2/(1+1.2*(0.25+0.75*r.terms.length/(average||1)));if(r.titleTerms.includes(t))score+=0.3;}
  return {...r.excerpt,score,matchedTerms:matched.length,queryTerms:terms.length};
 }).filter(r=>r.matchedTerms>0).sort((a,b)=>b.matchedTerms-a.matchedTerms||b.score-a.score||a.documentId.localeCompare(b.documentId)||a.start-b.start);
 const selected=[];
 for(const r of ranked){if(selected.some(p=>p.documentId===r.documentId&&Math.max(0,Math.min(p.end,r.end)-Math.max(p.start,r.start))>Math.min(p.text.length,r.text.length)/2))continue;selected.push(r);if(selected.length===DOCUMENT_LIMITS.results)break;}
 return selected;
}

import {DOCUMENTS_KEY,DOCUMENT_DRAFT_KEY,documentDraft,documentsState,addDocument,removeDocument,readTextFile,searchDocuments,sourceExcerpt,excerptLabel} from '/noyau-documents-core.js?v=A100';
import {commitDocuments} from '/noyau-documents-store.js?v=A100';
const $=id=>document.getElementById(id),memory=window.BlobLocalMemory,node=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
let db=null,state=documentsState(),busy=false,outsideBusy=false,loading=false,fileSelection=0,unsaved=false;
const notice=text=>{$('documentsState').textContent=text;};
const blocked=()=>busy||outsideBusy||loading||!db;
function controls(){for(const id of ['documentFile','documentTitle','documentText','documentSave','documentsQuery','documentsScope','documentsSearch','documentsRefresh'])$(id).disabled=blocked();for(const b of document.querySelectorAll('[data-document-action]'))b.disabled=blocked();}
document.addEventListener('noyau-workspace-state',e=>{outsideBusy=e.detail.busy===true;if(outsideBusy){fileSelection++;loading=false;}controls();});
function saveDraft(){const data=documentDraft({title:$('documentTitle').value,text:$('documentText').value}),text=JSON.stringify(data);localStorage.setItem(DOCUMENT_DRAFT_KEY,text);if(localStorage.getItem(DOCUMENT_DRAFT_KEY)!==text)throw Error('Brouillon non confirmé.');unsaved=false;}
for(const id of ['documentTitle','documentText'])$(id).addEventListener('input',()=>{unsaved=true;try{saveDraft();}catch{notice('Brouillon non sauvegardé. Copie ton texte avant de fermer cette page.');}});
window.addEventListener('beforeunload',e=>{if(unsaved){e.preventDefault();e.returnValue='';}});
const action=(label,fn)=>{const b=node('button',label);b.type='button';b.className='secondary';b.dataset.documentAction='';b.onclick=fn;return b;};
function render(){
 const previous=$('documentsScope').value,scope=$('documentsScope');scope.replaceChildren();const all=node('option','Tous mes documents');all.value='';scope.append(all);
 const list=$('documentsList');list.replaceChildren();
 for(const d of state.documents){
  const option=node('option',d.title);option.value=d.id;scope.append(option);
  const details=node('details');details.append(node('summary',d.title),node('p',d.text.length.toLocaleString('fr-FR')+' caractères · ajouté le '+new Date(d.importedAt).toLocaleString('fr-FR')),node('pre',d.text));
  details.append(action('Retirer ce document',async()=>{if(blocked())return;if(!confirm('Retirer « '+d.title+' » ? Les extraits déjà joints aux projets restent conservés. Garde une sauvegarde complète si tu veux conserver le document entier.'))return;await edit(raw=>removeDocument(raw,d.id));}));list.append(details);
 }
 if(state.documents.some(d=>d.id===previous))scope.value=previous;
 $('documentsCount').textContent=state.documents.length+'/12 documents · '+state.documents.reduce((n,d)=>n+d.text.length,0).toLocaleString('fr-FR')+'/144 000 caractères. Inclus dans la sauvegarde complète.';
 $('documentsManage').hidden=!state.documents.length;search();controls();
}
function search(){
 const results=$('documentsResults');results.replaceChildren();const query=$('documentsQuery').value.trim();if(!query)return;
 let rows;try{rows=searchDocuments(state,query,$('documentsScope').value);}catch(e){notice(e.message);return;}
 if(!rows.length){results.append(node('p','Aucun extrait contenant ces mots. Essaie des mots présents dans ton document ; aucune réponse n’a été inventée.'));return;}
 results.append(node('p',rows.length+' extrait(s) contenant tes mots. Vérifie le contexte du document avant de les utiliser.'));
 for(const r of rows){
  const box=node('article');box.className='document-result';box.append(node('strong',excerptLabel(r)),node('small',r.matchedTerms+'/'+r.queryTerms+' mots recherchés retrouvés · extrait du texte enregistré'),node('blockquote',r.text));
  box.append(action('Joindre au projet sélectionné',async()=>{
   if(blocked())return;
   try{const d=state.documents.find(d=>d.id===r.documentId),excerpt=sourceExcerpt(d,r.start,r.end);if(excerpt.text!==r.text)throw Error('Le document a changé. Relance la recherche.');
    if(!window.NoyauProjectWork?.attachSource)throw Error('Les projets ne sont pas encore disponibles.');
    const ok=await window.NoyauProjectWork.attachSource(excerpt);if(ok){$('projectPanel').open=true;notice('Extrait joint au projet. Aucun calcul lancé ; prépare l’étape quand tu es prêt.');}else notice('Extrait non joint. Consulte le message du projet.');
   }catch(e){notice(e.message);}
  }));results.append(box);
 }
 controls();
}
async function reload(){state=documentsState(await memory.setting(db,DOCUMENTS_KEY));render();}
async function edit(transform){
 if(blocked())return false;busy=true;controls();
 try{await window.NoyauLocalMaintenance.run(async()=>{state=await commitDocuments(db,state.revision,transform);});render();notice('Documents sauvegardés et relus.');return true;}
 catch(e){notice(e.message+' Le texte saisi reste disponible.');return false;}
 finally{busy=false;controls();}
}
$('documentsSearch').onclick=()=>{if(!blocked())search();};
$('documentsQuery').addEventListener('keydown',e=>{if(e.key==='Enter'&&!blocked()){e.preventDefault();search();}});
$('documentsScope').onchange=()=>{if(!blocked())search();};
$('documentsRefresh').onclick=async()=>{if(blocked())return;try{await reload();notice('Documents relus. Aucun calcul lancé.');}catch(e){notice(e.message);}};
$('documentSave').onclick=async()=>{
 if(blocked())return;const input={title:$('documentTitle').value,text:$('documentText').value};
 if(await edit(raw=>addDocument(raw,input,crypto.randomUUID()))){
  $('documentTitle').value='';$('documentText').value='';$('documentFile').value='';unsaved=false;
  try{saveDraft();}catch{notice('Document enregistré ; le brouillon précédent reste conservé.');}
  $('documentAdd').open=false;
 }
};
$('documentFile').onchange=async()=>{
 if(blocked())return;const file=$('documentFile').files?.[0];if(!file)return;
 if(($('documentTitle').value||$('documentText').value)&&!confirm('Remplacer le brouillon affiché par ce fichier ? Les documents enregistrés restent conservés.')){$('documentFile').value='';return;}
 const selection=++fileSelection;loading=true;controls();notice('Lecture du fichier sur cet appareil…');
 try{const draft=await readTextFile(file);if(selection!==fileSelection)return;$('documentTitle').value=draft.title;$('documentText').value=draft.text;unsaved=true;saveDraft();notice('Fichier lu intégralement. Vérifie le titre puis enregistre le document.');}
 catch(e){if(selection===fileSelection)notice(e.message);}
 finally{if(selection===fileSelection){loading=false;controls();}}
};
(async()=>{try{db=await memory.open();await reload();const draft=documentDraft(JSON.parse(localStorage.getItem(DOCUMENT_DRAFT_KEY)||'null'));$('documentTitle').value=draft.title;$('documentText').value=draft.text;$('documentAdd').open=!!draft.text;notice('Recherche locale, sans modèle ni envoi de document. Les extraits ne prouvent pas que leur contenu est vrai.');}catch(e){db=null;notice(e.message);}controls();})();

// Device-local adaptation, NOT weight training or an execution proof.
import {TASKS,routeTask,validateTaskProposal} from '/blob-assistant-core.js?v=A60';
export const ADAPTER_SCHEMA='noyau-intent-memory-v1';
const norm=text=>String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
const validHash=h=>typeof h==='string'&&/^[0-9a-f]{64}$/.test(h);
export function contextRecipes(rows){
 if(!Array.isArray(rows)||rows.length>64)return [];
 return rows.filter(r=>r&&Object.hasOwn(TASKS,r.id)&&validHash(r.sourceHash)).map(r=>({id:r.id,title:String(r.title||TASKS[r.id]).slice(0,96),sourceHash:r.sourceHash,verified:Number.isSafeInteger(r.verified)&&r.verified>0?Math.min(r.verified,100000):0,champion:r.champion===true}));
}
export function intentMemory(raw){
 if(!raw||raw.schema!==ADAPTER_SCHEMA||!Array.isArray(raw.entries)||raw.entries.length>32)return {schema:ADAPTER_SCHEMA,entries:[]};
 const entries=raw.entries.filter(e=>e&&typeof e.text==='string'&&e.text.length>0&&e.text.length<=500&&Object.hasOwn(TASKS,e.recipeId)&&validHash(e.sourceHash)&&e.proofGranted===false&&Number.isFinite(e.at)).map(e=>({text:e.text,recipeId:e.recipeId,sourceHash:e.sourceHash,at:e.at,proofGranted:false}));
 return {schema:ADAPTER_SCHEMA,entries};
}
export function rememberIntent(raw,text,recipe,at=Date.now()){
 const state=intentMemory(raw);
 if(typeof text!=='string'||!text.trim()||text.length>500||!recipe||!Object.hasOwn(TASKS,recipe.id)||!validHash(recipe.sourceHash)||!Number.isFinite(at))throw Error('INTENT_MEMORY_INVALID');
 const key=norm(text),entries=state.entries.filter(e=>norm(e.text)!==key);
 entries.push({text:text.trim(),recipeId:recipe.id,sourceHash:recipe.sourceHash,at,proofGranted:false});
 return {schema:ADAPTER_SCHEMA,entries:entries.slice(-32)};
}
export function adaptIntent(text,rows=[],memory=null){
 if(typeof text!=='string'||!text.trim()||text.length>1000)throw Error('ASSISTANT_REQUEST_BOUNDS');
 const recipes=contextRecipes(rows),entries=intentMemory(memory).entries,key=norm(text);
 const learned=entries.slice().reverse().find(e=>norm(e.text)===key&&recipes.some(r=>r.id===e.recipeId&&r.sourceHash===e.sourceHash));
 if(learned)return {proposal:validateTaskProposal({recipeId:learned.recipeId,reason:'Objectif que tu as confirmé sur cette version de recette.',proofGranted:false}),source:'LOCAL_MEMORY',choices:[learned.recipeId],recipes,examples:[]};
 let p=routeTask(text);const t=key;
 const relational=/client|customer|region|joint|join|rapproch|match/.test(t),net=/net|frais|fees|charges|commission/.test(t),risk=/risqu|risk|exposition/.test(t),count=/compt|count|nombre|how many/.test(t);
 let id=p?.recipeId;
 if(relational&&risk)id='joined-risk';else if(relational&&net)id='joined-net';else if(relational&&count)id='joined-count';
 else if(/doublon|duplicate|dedup|en double|repeated|repetition|repetes|une seule fois/.test(t))id=/positi/.test(t)?'positive-clean':'event-clean';
 else if(net)id='net-total';else if(count)id='category-count';else if(/region/.test(t))id='region-total';
 else if(/priorit/.test(t)&&/positi|ready|pret/.test(t))id='recovery-priority';
 if(id)p=validateTaskProposal({recipeId:id,reason:TASKS[id],proofGranted:false});
 const neighbours={'event-clean':['positive-clean','category-count','customer-join'],'positive-clean':['event-clean','recovery-priority','category-sum'],'category-sum':['category-count','category-priority','net-total'],'category-count':['category-sum','joined-count','event-clean'],'category-priority':['high-value-ranking','event-ranking','category-sum'],'event-ranking':['high-value-ranking','category-priority','recovery-priority'],'high-value-ranking':['event-ranking','category-priority','recovery-priority'],'net-total':['joined-net','category-sum','risk-rollup'],'risk-rollup':['joined-risk','category-sum','net-total'],'customer-join':['region-total','joined-net','joined-count'],'region-total':['joined-net','joined-count','customer-join'],'recovery-priority':['positive-clean','event-ranking','high-value-ranking'],'joined-net':['net-total','region-total','joined-risk'],'joined-count':['category-count','region-total','customer-join'],'joined-risk':['risk-rollup','joined-net','region-total']};
 const choices=p?[p.recipeId,...neighbours[p.recipeId]]:['event-clean','category-sum','customer-join','high-value-ranking'];
 const examples=entries.filter(e=>choices.includes(e.recipeId)&&recipes.some(r=>r.id===e.recipeId&&r.sourceHash===e.sourceHash)).slice(-2).map(e=>({text:e.text.slice(0,180),recipeId:e.recipeId}));
 return {proposal:p||null,source:p?'LOCAL_RULES':'MODEL_ONLY',choices,recipes:recipes.filter(r=>choices.includes(r.id)),examples};
}
export function integratedMessages(text,context={}){
 if(typeof text!=='string'||!text.trim()||text.length>1000)throw Error('ASSISTANT_REQUEST_BOUNDS');
 const choices=Array.isArray(context.choices)&&context.choices.length>=1&&context.choices.length<=4&&new Set(context.choices).size===context.choices.length&&context.choices.every(id=>Object.hasOwn(TASKS,id))?context.choices:Object.keys(TASKS).slice(0,4);
 const recipes=contextRecipes(context.recipes||[]);
 const list=choices.map((id,i)=>String.fromCharCode(65+i)+': '+TASKS[id].split(' / ')[0]+(recipes.some(r=>r.id===id&&r.champion)?' (saved plan, not a new proof)':'')).join('\n');
 const messages=[{role:'system',content:'Classify the request. Reply with ONLY one letter from the list. No explanation. A choice is not an execution or a proof.\n'+list}];
 // Tiny models need explicit output examples; these are labels, not fabricated runs.
 for(const id of choices.slice(0,2))messages.push({role:'user',content:TASKS[id].split(' / ')[0]+'.'},{role:'assistant',content:String.fromCharCode(65+choices.indexOf(id))});
 for(const example of (Array.isArray(context.examples)?context.examples:[]).slice(-2))if(example&&choices.includes(example.recipeId)&&typeof example.text==='string'&&example.text.length<=180)messages.push({role:'user',content:example.text},{role:'assistant',content:String.fromCharCode(65+choices.indexOf(example.recipeId))});
 messages.push({role:'user',content:text});return {messages,choices};
}
export function integratedProposal(text,choices){
 if(typeof text!=='string'||text.length>100||!Array.isArray(choices)||!choices.length||choices.length>4||choices.some(id=>!Object.hasOwn(TASKS,id)))throw Error('ASSISTANT_CHOICE_INVALID');
 const match=text.trim().match(/^["']?([A-D])["']?[.!]?$/),id=match&&choices[match[1].charCodeAt(0)-65];
 if(!id)throw Error('ASSISTANT_CHOICE_INVALID');
 return validateTaskProposal({recipeId:id,reason:TASKS[id].split(' / ')[1],proofGranted:false});
}

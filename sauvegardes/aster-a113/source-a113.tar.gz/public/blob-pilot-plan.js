// A73: executable, finite curriculum. Public synthetic fixtures, never private memories.
import {LOCAL_ACTIONS} from '/blob-local-actions.js?v=A72.2';
export const PILOT_RELEASE='A83-LOCAL-PROGRESSIVE';
// A new key prevents old A72 measurements from qualifying changed execution settings.
// Old keys and all personal stores remain untouched.
export const PILOT_KEY='assistantLocalPilot-A83';
// llama.cpp clamps its context batch to at least 64. Its native batch storage
// must be allocated with the same lower bound; values 4/8/16 abort on decode.
export const PROFILES=Object.freeze([Object.freeze({id:'safe-64',n_batch:64,sliceMs:25,pauseMs:50})]);
const tools=[...new Set(Object.values(LOCAL_ACTIONS))].join(', ');
const filler='Ce paragraphe décrit une pièce de démonstration, ses murs, ses fenêtres et ses meubles. '.repeat(8);
const originalProbes=[
 {id:'ready',phase:-1,text:'',expected:'ready',readyOnly:true},
 {id:'sum',phase:0,text:'Calcule 2 + 3. Réponds uniquement avec le chiffre du résultat.',expected:'5'},
 {id:'fact',phase:0,text:'Le ballon est bleu. Quelle est sa couleur ? Réponds uniquement par le mot de couleur.',expected:'bleu'},
 {id:'copy',phase:0,text:'Recopie uniquement le mot suivant, sans commentaire : lune',expected:'lune'},
 {id:'cycle',phase:0,text:'Le vélo est vert. Quelle est sa couleur ? Réponds uniquement par le mot de couleur.',expected:'vert',pipeline:true},
 {id:'note',phase:1,text:'Dans la note de démonstration, quel fruit préfère Camille ? Réponds uniquement par le nom du fruit.',expected:'pomme',context:{notes:[{text:'Note fictive de test : Camille préfère la pomme.'}]}},
 {id:'history',phase:1,text:'Quelle ville ai-je indiquée dans cet échange de démonstration ? Réponds uniquement avec le nom de la ville.',expected:'lyon',context:{history:[{role:'user',content:'Dans cet exemple fictif, je choisis Lyon.'},{role:'assistant',content:'Tu choisis Lyon dans cet exemple.'}]}},
 {id:'tool',phase:1,text:'Quel identifiant correspond à l’analyse des doublons ? Réponds uniquement par cet identifiant, sans exécuter l’action.',expected:'memory_audit',context:{passages:[{id:'a73-tools',source:'SYNTHETIC_TEST',title:'Actions réellement raccordées',text:'Identifiants disponibles : '+tools+'. MEMORY_AUDIT correspond à l’analyse des doublons en lecture seule. Aucune action ne doit être exécutée pendant cet exercice.'}]}},
 {id:'cycle-context',phase:2,text:'D’après le document de démonstration, quel est le numéro du casier ? Réponds uniquement par le nombre.',expected:'47',pipeline:true,minInputTokens:350,context:{passages:[
  {id:'a73-context-a',source:'SYNTHETIC_TEST',title:'Description A',text:filler},
  {id:'a73-context-b',source:'SYNTHETIC_TEST',title:'Casier',text:'Le numéro du casier est 47. '+filler},
  {id:'a73-context-c',source:'SYNTHETIC_TEST',title:'Description C',text:filler}
 ]}}
];
const copies=['lune','sel','lac'];
const nano=copies.map((word,i)=>({id:'nano-'+i,phase:0,text:word,expected:word,mechanical:true,minimal:true,maxTokens:1}));
const copy=copies.map((word,i)=>({id:i===0?'copy':'copy-'+i,phase:1,text:'Recopie : '+word,expected:word,minimal:true,maxTokens:8}));
const short=[['rouge bleu','rouge bleu'],['petit chat','petit chat'],['soleil lune','soleil lune']].map(([text,expected],i)=>({id:'short-'+i,phase:3,text:'Recopie seulement ces deux mots : '+text,expected,minimal:true,maxTokens:16}));
const heldout=[
 ['Écris seulement : ardoise','ardoise'],['Écris seulement : nuage','nuage'],['Écris seulement : olive','olive'],['Recopie : iris','iris'],['Recopie : sable','sable'],
 ['La fleur est jaune. Quelle couleur ? Un mot.','jaune'],['La feuille est brune. Quelle couleur ? Un mot.','brune'],['Le mur est blanc. Quelle couleur ? Un mot.','blanc'],
 ['Calcule 4 + 4. Un chiffre seulement.','8'],['Recopie ces deux mots : grand arbre','grand arbre']
].map(([text,expected],i)=>({id:'transfer-'+i,phase:7,text,expected,minimal:true,maxTokens:16,heldout:true}));
export const PROBES=Object.freeze([
 originalProbes.find(p=>p.id==='ready'),...nano,...copy,
 ...originalProbes.filter(p=>['sum','fact'].includes(p.id)).map(p=>({...p,phase:2,minimal:true,maxTokens:8})),
 {id:'fact-2',phase:2,text:'La tasse est rose. Quelle couleur ? Un mot.',expected:'rose',minimal:true,maxTokens:8},
 ...short,
 ...originalProbes.filter(p=>['note','history','tool'].includes(p.id)).map(p=>({...p,phase:4,maxTokens:32})),
 ...[originalProbes.find(p=>p.id==='cycle'),{id:'cycle-1',text:'Le tissu est beige. Quelle est sa couleur ? Réponds uniquement par le mot de couleur.',expected:'beige',pipeline:true},{id:'cycle-2',text:'Le cube est noir. Quelle est sa couleur ? Réponds uniquement par le mot de couleur.',expected:'noir',pipeline:true}].map(p=>({...p,phase:5,maxTokens:32})),
 {...originalProbes.find(p=>p.id==='cycle-context'),phase:6,maxTokens:32},...heldout
].map(Object.freeze));
export const PHASES=[-1,0,1,2,3,4,5,6,7];
export const PHASE_LABELS={'-1':'Chargement seul','0':'Un token','1':'Un mot','2':'Extraction courte','3':'Deux mots','4':'Mémoire et choix d’outil','5':'Sauvegarde et réutilisation','6':'Contexte étendu','7':'Transfert sur variantes'};
export function studyAssessment(state){
 const receipts=state.receipts||[],completed=receipts.filter(r=>['PASS','FAIL','INTERRUPTED'].includes(r.outcome));
 const technical=completed.filter(r=>r.outcome==='INTERRUPTED'||r.outcome==='FAIL'&&r.reason!=='PROBE_OUTPUT_REJECTED');
 const content=completed.filter(r=>!PROBES.find(p=>p.id===r.caseId)?.mechanical&&r.caseId!=='ready'&&(r.outcome==='PASS'||r.reason==='PROBE_OUTPUT_REJECTED'));
 const correct=content.filter(r=>r.outcome==='PASS').length,attempted=content.length;
 const transfer=content.filter(r=>PROBES.find(p=>p.id===r.caseId)?.heldout);
 const stages=PHASES.map(phase=>({phase,label:PHASE_LABELS[phase],passed:PROBES.filter(p=>p.phase===phase).every(p=>receipts.some(r=>r.caseId===p.id&&r.outcome==='PASS'))}));
 return {scope:'LOCAL_SYNTHETIC_ONLY',attempted,correct,accuracyPercent:attempted?Math.round(100*correct/attempted):null,technicalFailures:technical.length,stages,transfer:{attempted:transfer.length,correct:transfer.filter(r=>r.outcome==='PASS').length},engineReuses:completed.filter(r=>r.reusedEngine).length,checkpointReuses:completed.filter(r=>r.reusedFinal).length,activeWallMs:completed.reduce((n,r)=>n+(Number.isFinite(r.elapsedMs)?r.elapsedMs:0),0),usefulObservations:content.filter(r=>r.outcome==='PASS'&&r.reusedFinal&&r.cycleReadback).map(r=>({kind:'DURABLE_REPLAY_WITHOUT_GENERATION',caseId:r.caseId,at:r.at,novelty:'NOT_ESTABLISHED'})),outlook:technical.length?'DIAGNOSTIC_REQUIRED':attempted===0?'NOT_MEASURED':stages.every(s=>s.passed)?'BASIC_PATH_VALIDATED':'INCOMPLETE_OR_CONTENT_LIMIT',recordClaimed:false,innovationClaimed:false,weightsTrained:false};
}
export const PLAN_SIZE=PROBES.length;
export function loadOptions(id){const p=PROFILES.find(p=>p.id===id)||PROFILES[0];return {n_ctx:512,n_batch:p.n_batch,n_threads:1,flash_attn:false,cache_type_k:'f16',cache_type_v:'f16'};}
export function probePass(id,text){const p=PROBES.find(p=>p.id===id);return !!p&&typeof text==='string'&&(p.mechanical?text.length>0:text.trim().toLocaleLowerCase('fr').replace(/[.!?]+$/u,'').trim()===p.expected);}
export const signature=a=>a&&[a.n_ctx,a.n_batch,a.n_ubatch,a.n_threads,a.sliceMs,a.pauseMs].join('/');
export const actualOK=a=>!!a&&[512,1024].includes(a.n_ctx)&&a.n_threads===1&&Number.isInteger(a.n_batch)&&a.n_batch===64&&Number.isInteger(a.n_ubatch)&&a.n_ubatch>0&&a.n_ubatch<=a.n_batch&&PROFILES.some(p=>p.sliceMs===a.sliceMs&&p.pauseMs===a.pauseMs);
export const profileOK=(id,a)=>actualOK(a)&&a.n_ctx===512&&PROFILES.some(p=>p.id===id&&p.sliceMs===a.sliceMs&&p.pauseMs===a.pauseMs);
export const isCycle=id=>PROBES.some(p=>p.id===id&&p.pipeline===true);
export function runtimeReceipt(actual,stats){
 if(!actualOK(actual))return null;
 if(stats?.runtime==='READY_ONLY')return {runtime:'READY_ONLY',measured:false,sliceMs:actual.sliceMs,pauseMs:actual.pauseMs};
 if(!actual.sliceMs)return {measured:false,sliceMs:0,pauseMs:0};
 if(stats?.runtime!=='A72.3-COOPERATIVE-1'||!Number.isInteger(stats.batches)||stats.batches<1||stats.batches>100000||!Number.isInteger(stats.decodedTokens)||stats.decodedTokens<1||stats.decodedTokens>100000||!Number.isInteger(stats.pauses)||stats.pauses<0||stats.pauses>stats.batches||!Number.isFinite(stats.idleMs)||stats.idleMs<0||!Number.isFinite(stats.computeMs)||stats.computeMs<0)return null;
 return {runtime:'A72.3-COOPERATIVE-1',measured:true,sliceMs:actual.sliceMs,pauseMs:actual.pauseMs,batches:stats.batches,decodedTokens:stats.decodedTokens,pauses:stats.pauses,idleMs:stats.idleMs,computeMs:stats.computeMs};
}
export const copyActual=a=>({n_ctx:a.n_ctx,n_batch:a.n_batch,n_ubatch:a.n_ubatch,n_threads:a.n_threads,sliceMs:a.sliceMs,pauseMs:a.pauseMs});
export function nextTrial(state){
 // First certify a useful path on the minimal profile. No automatic escalation of pressure.
 const p=PROFILES[0],rs=state.receipts.filter(r=>r.profile===p.id);
 if(state.selected)return null;
 if(rs.some(r=>r.outcome==='INTERRUPTED'||r.outcome==='EQUIVALENT'||(r.outcome==='FAIL'&&r.reason!=='PROBE_OUTPUT_REJECTED')))return null;
 for(const phase of PHASES){
  const cases=PROBES.filter(c=>c.phase===phase);
  for(const c of cases)if(!rs.some(r=>r.caseId===c.id))return {profile:p.id,caseId:c.id};
  if(cases.some(c=>!rs.some(r=>r.caseId===c.id&&r.outcome==='PASS')))return null;
 }
 return null;
}
export function planProgress(state){const count=state.receipts.filter(r=>r.outcome==='PASS').length,trial=state.inflight||nextTrial(state),c=PROBES.find(p=>p.id===trial?.caseId);return {passed:count,max:PLAN_SIZE,phase:c?PHASE_LABELS[c.phase]:'Parcours arrêté ou terminé',trial};}
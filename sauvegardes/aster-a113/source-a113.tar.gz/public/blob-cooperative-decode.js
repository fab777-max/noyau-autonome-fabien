// Cooperative adapter for the vendored wllama b7179-4abef75 API only.
// Pauses do not free model weights or KV memory, nor certify Safari stability.
export const COOPERATIVE_RUNTIME='A72.3-COOPERATIVE-1';
export const SUPPORTED_LLAMA='b7179-4abef75';
const running=new WeakSet();
/** Preserve native decode batch boundaries and logits flags; only add idle time.
 * The caller keeps its existing single-engine lock and durable task checkpoints.
 * No prompts or token values enter the returned technical counters.
 */
export async function withCooperativeDecode(engine,run,{sliceMs=50,pauseMs=25,now=()=>performance.now(),sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms)),progress=()=>{}}={}){
 if(!engine||typeof run!=='function'||typeof engine.decode!=='function'||typeof engine.getCachedTokens!=='function'||engine.constructor.getLibllamaVersion?.()!==SUPPORTED_LLAMA)throw Error('COOPERATIVE_RUNTIME_UNSUPPORTED');
 if(!Number.isFinite(sliceMs)||sliceMs<1||sliceMs>1000||!Number.isFinite(pauseMs)||pauseMs<1||pauseMs>1000)throw Error('COOPERATIVE_BUDGET_INVALID');
 if(running.has(engine))throw Error('COOPERATIVE_ENGINE_BUSY');
 const info=engine.getLoadedContextInfo(),batch=info.n_batch;
 if(!Number.isInteger(batch)||batch<1||!Number.isInteger(info.n_ctx)||info.n_ctx<batch||engine.isEncoderDecoderArchitecture()||engine.useEmbeddings)throw Error('COOPERATIVE_PROFILE_UNSUPPORTED');
 const original=engine.decode,own=Object.getOwnPropertyDescriptor(engine,'decode');
 const stats={runtime:COOPERATIVE_RUNTIME,batches:0,decodedTokens:0,pauses:0,idleMs:0,computeMs:0};
 let workingMs=0;
 const notify=()=>{try{progress({...stats});}catch{ /* UI errors cannot invalidate completed computation. */ }};
 async function paced(tokens,options={}){
  if(tokens.length===0)return original.call(engine,tokens,options);
  // Preserve native all-or-nothing context-capacity preflight before any decode.
  if(tokens.length>batch){const cached=await engine.getCachedTokens();if(cached.length+tokens.length>info.n_ctx)return original.call(engine,tokens,options);}
  let result;
  for(let offset=0;offset<tokens.length;offset+=batch){
   const part=tokens.slice(offset,offset+batch),before=now();
   result=await original.call(engine,part,{...options,skipLogits:options.skipLogits||offset+batch<tokens.length});
   const work=Math.max(0,now()-before);workingMs+=work;stats.computeMs+=work;stats.batches++;stats.decodedTokens+=part.length;
   notify();
   if(workingMs>=sliceMs){const idleStart=now();await sleep(pauseMs);stats.idleMs+=Math.max(0,now()-idleStart);stats.pauses++;workingMs=0;}
  }
  return result;
 }
 running.add(engine);
 try{engine.decode=paced;const value=await run();return {value,stats:{...stats}};}
 finally{if(own)Object.defineProperty(engine,'decode',own);else delete engine.decode;running.delete(engine);}
}
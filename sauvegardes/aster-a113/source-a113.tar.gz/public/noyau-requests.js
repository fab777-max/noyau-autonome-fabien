const $=id=>document.getElementById(id),API='/api/agent-tasks',PENDING='noyau-request-pending-v1',DRAFT='noyau-request-draft-v1';
const labels={queued:'En attente',in_progress:'Pris en charge',needs_review:'À vérifier',blocked:'Bloqué',accepted:'Validé par moi',cancelled:'Annulé'};
let pending=null,sending=false,loading=false,cursor=null,items=new Map();
function node(tag,text,className){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;}
function message(id,text,error=false){$(id).textContent=text;$(id).classList.toggle('error',error);}
function date(value){return new Date(value).toLocaleString('fr-FR',{dateStyle:'medium',timeStyle:'short'});}
async function api(data=null,query=''){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{
    const response=await fetch(API+query,{method:data?'POST':'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:data?{'Content-Type':'application/json'}:{Accept:'application/json'},body:data?JSON.stringify(data):undefined,signal:controller.signal});
    if(!response.headers.get('content-type')?.includes('application/json'))throw Error('Connexion au site nécessaire. Rouvre cette page en ligne.');
    const value=await response.json();if(!response.ok)throw Error(value.error||'La réponse du serveur ne confirme pas l’opération.');return value;
  }catch(e){if(e.name==='AbortError'||e instanceof TypeError)throw Error('Connexion interrompue. Le résultat de l’envoi est inconnu ; vérifie avec le même bouton.');throw e;}finally{clearTimeout(timer);}
}
function syncPending(){
  $('requestText').readOnly=!!pending;$('includeDiagnostic').disabled=!!pending;
  $('sendRequest').textContent=pending?'Vérifier le même envoi':'Enregistrer ma demande';
  if(pending){$('requestText').value=pending.request;$('includeDiagnostic').checked=!!pending.diagnostic.capabilities;}
}
function handoff(task){
  const text=`Ouvre l’app Noyau de mon site ${location.origin}. Lis la demande ${task.id} avec noyau_get_request. Si elle est toujours en attente, prends-la en charge avec noyau_claim_request et réalise le travail demandé avec tes outils. Préserve mes modèles, ma mémoire et l’accès privé du site. Dépose ensuite un compte rendu avec noyau_report_request, les vérifications réellement faites et les limites. Si un outil manque, dis-le clairement. Ne lance aucune boucle automatique.\n\nDemande : ${task.request}`;
  $('handoffText').value=text;$('handoffPanel').hidden=false;$('handoffPanel').scrollIntoView({behavior:'smooth',block:'nearest'});message('copyStatus','La consigne est prête.');
}
async function copy(text){if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(text);return true;}catch{}}return false;}
$('copyHandoff').onclick=async()=>{if(await copy($('handoffText').value))message('copyStatus','Consigne copiée. Colle-la dans ChatGPT pour démarrer.');else{$('handoffText').focus();$('handoffText').select();message('copyStatus','Sélectionne le texte puis utilise Copier sur ton iPhone.');}};
function button(text,fn,style='secondary'){const b=node('button',text,style);b.type='button';b.onclick=fn;return b;}
function render(){
  const root=$('requestList');root.replaceChildren();
  for(const task of items.values()){
    const card=node('article',undefined,'request-card'),meta=node('div',undefined,'request-meta'),badge=node('span',labels[task.status]||task.status,'request-state');badge.dataset.state=task.status;
    meta.append(badge,node('span',date(task.created_at),'muted'));card.append(meta,node('h3',task.request),node('p','Référence : '+task.id+' · mise à jour '+date(task.updated_at),'muted'));
    if(task.stale)card.append(node('p','La prise en charge n’a pas reçu de compte rendu dans les 30 minutes. Vérifie d’abord la conversation avant de remettre cette demande en attente. Aucune relance automatique.','notice'));
    if(task.report){
      const details=node('details'),report=task.report;details.append(node('summary','Voir le compte rendu'),node('p',report.summary));
      if(report.kind==='analysis')details.append(node('p','Résultat d’analyse ; aucune modification de code attestée.','muted'));
      const checks=node('ul');for(const check of report.checks)checks.append(node('li',({passed:'Réussi',failed:'Échec',not_run:'Non effectué'}[check.outcome])+ ' — '+check.name+' : '+check.detail));details.append(checks);
      if(report.commit)details.append(node('pre','Commit déclaré : '+report.commit));
      details.append(node('p',report.published?'Publication déclarée par l’agent sur ce site.':'Aucune publication déclarée dans ce compte rendu.','muted'));
      if(report.limitations.length){details.append(node('strong','Limites signalées'));const limits=node('ul');for(const limitation of report.limitations)limits.append(node('li',limitation));details.append(limits);}
      card.append(details);
    }
    const actions=node('div',undefined,'request-actions');
    if(task.status==='queued')actions.append(button('Préparer la consigne ChatGPT',()=>handoff(task)));
    actions.append(button('Historique',async e=>{const b=e.currentTarget;b.disabled=true;try{const full=await api(null,'?id='+encodeURIComponent(task.id));const old=card.querySelector('.task-history');old?.remove();const history=node('ol',undefined,'task-history');for(const event of full.events){const entry=node('li',date(event.created_at)+' · '+event.detail);if(event.report){const detail=node('details');detail.append(node('summary','Compte rendu conservé'),node('p',event.report.summary));for(const check of event.report.checks)detail.append(node('p',check.name+' · '+check.outcome+' · '+check.detail,'muted'));if(event.report.commit)detail.append(node('pre','Commit : '+event.report.commit));for(const limitation of event.report.limitations)detail.append(node('p',limitation,'muted'));entry.append(detail);}history.append(entry);}card.append(history);}catch(error){message('listStatus',error.message,true);}finally{b.disabled=false;}}));
    if(task.status==='needs_review')actions.append(button('J’ai vérifié, valider',()=>mutate(task,'accept')));
    if(task.status==='blocked'||task.status==='needs_review'||task.stale)actions.append(button('Remettre en attente',()=>mutate(task,'requeue')));
    if(!['accepted','cancelled'].includes(task.status))actions.append(button('Annuler la demande',()=>mutate(task,'cancel'),'quiet'));
    else actions.append(button('Effacer cette demande',()=>mutate(task,'delete'),'quiet'));
    card.append(actions);root.append(card);
  }
  $('moreRequests').hidden=!cursor;
}
async function refresh(more=false){
  if(loading)return;loading=true;$('refreshRequests').disabled=true;$('moreRequests').disabled=true;
  message('listStatus','Lecture du carnet privé…');
  try{const value=await api(null,more&&cursor?'?cursor='+encodeURIComponent(cursor):'');if(!more)items.clear();for(const task of value.items)items.set(task.id,task);cursor=value.nextCursor;render();message('listStatus',items.size?items.size+' demande(s) affichée(s). Dernière lecture : '+date(Date.now())+'.':'Aucune demande enregistrée.');}
  catch(e){message('listStatus',e.message+' Les demandes déjà affichées peuvent être anciennes.',true);}finally{loading=false;$('refreshRequests').disabled=false;$('moreRequests').disabled=false;}
}
async function mutate(task,action){
  const prompts={cancel:'Annuler cette demande ? Si un agent travaille déjà, préviens-le aussi dans ChatGPT : ce bouton n’arrête pas son processus.',requeue:'Remettre cette demande en attente ? Cela ne redémarre pas l’agent.',accept:'As-tu vérifié le résultat et lu les limites indiquées ?',delete:'Effacer définitivement cette demande et son historique ?'};
  if(!confirm(prompts[action]))return;
  try{await api({action,id:task.id,revision:task.revision});await refresh();}catch(e){message('listStatus',e.message,true);}
}
$('requestText').addEventListener('input',()=>{try{localStorage.setItem(DRAFT,$('requestText').value);}catch{message('sendStatus','Le brouillon ne peut pas être conservé sur cet appareil.',true);}});
$('requestForm').addEventListener('submit',async event=>{
  event.preventDefault();if(sending)return;
  if(!pending){
    const request=$('requestText').value.trim();if(!request||request.length>2000){message('sendStatus','Décris la demande en 2 000 caractères maximum.',true);return;}
    const data={action:'create',key:crypto.randomUUID(),request,diagnostic:{build:'A98'}};
    if($('includeDiagnostic').checked)data.diagnostic.capabilities={online:navigator.onLine,webgpu:!!navigator.gpu,webcodecs:typeof VideoEncoder!=='undefined'};
    try{const saved=JSON.stringify(data);localStorage.setItem(PENDING,saved);if(localStorage.getItem(PENDING)!==saved)throw Error();pending=data;}catch{message('sendStatus','Stockage local indisponible. Envoi bloqué pour éviter un doublon après une coupure. Tu peux copier ta demande dans ChatGPT.',true);return;}
  }
  sending=true;syncPending();$('sendRequest').disabled=true;message('sendStatus','Vérification et enregistrement…');
  try{
    const task=await api(pending);if(!task?.id)throw Error('Réponse incomplète ; la demande n’est pas confirmée.');
    try{localStorage.removeItem(PENDING);localStorage.removeItem(DRAFT);}catch{}
    pending=null;syncPending();$('requestText').value='';message('sendStatus','Demande enregistrée. Prépare sa consigne ci-dessous pour la faire traiter dans ChatGPT.');await refresh();handoff(task);
  }catch(e){message('sendStatus',e.message+' Le prochain clic vérifiera le même envoi, sans créer de doublon.',true);}finally{sending=false;$('sendRequest').disabled=false;}
});
$('refreshRequests').onclick=()=>refresh();$('moreRequests').onclick=()=>refresh(true);
try{const raw=localStorage.getItem(PENDING);if(raw){const parsed=JSON.parse(raw);if(parsed.action==='create'&&typeof parsed.key==='string'&&typeof parsed.request==='string'&&parsed.diagnostic){pending=parsed;message('sendStatus','Un envoi précédent reste à confirmer. Vérifie-le avec le même bouton.');}else throw Error();}else $('requestText').value=localStorage.getItem(DRAFT)||'';}catch{message('sendStatus','Le brouillon local ne peut pas être lu. Aucune demande n’a été envoyée à l’ouverture.',true);}
syncPending();refresh();

// Owner-reviewed local experience. No model training, evaluation answers or network.
export const LEARNING_KEY='noyau.learned-lessons.v1';
const norm=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const words=s=>new Set(norm(s).split(/[^a-z0-9]+/).filter(w=>w.length>=3&&!['les','des','une','que','qui','pour','dans','avec','comment','peux','moi','est','sur','mon','mes','toi','faire'].includes(w)));
export function learningState(raw){
 if(raw==null)return {schema:1,lessons:[],contextUses:0};
 if(raw.schema!==1||!Array.isArray(raw.lessons)||raw.lessons.length>64||!Number.isSafeInteger(raw.contextUses)||raw.contextUses<0)throw Error('Mémoire de méthodes incompatible : exporte la sauvegarde.');
 const ids=new Set();for(const x of raw.lessons){if(!x||typeof x.id!=='string'||ids.has(x.id)||typeof x.question!=='string'||!x.question.trim()||x.question.length>1000||typeof x.answer!=='string'||!x.answer.trim()||x.answer.length>400||x.source!=='OWNER_VALIDATED')throw Error('Méthode conservée invalide.');ids.add(x.id);}
 return JSON.parse(JSON.stringify(raw));
}
export function retainLesson(raw,question,answer,id,at=Date.now()){
 const state=learningState(raw);question=question.trim();answer=answer.trim();
 if(!question||question.length>1000||!answer||answer.length>400)throw Error('Indique une situation et une méthode courte (400 caractères maximum).');
 const index=state.lessons.findIndex(x=>norm(x.question)===norm(question));
 if(index<0&&state.lessons.length>=64)throw Error('64 méthodes conservées. Exporte-les ou retire une méthode avant d’en ajouter.');
 const row={id:index<0?id:state.lessons[index].id,question,answer,source:'OWNER_VALIDATED',at};
 if(index<0)state.lessons.push(row);else state.lessons[index]=row;
 return learningState(state);
}
export function recallLessons(raw,question){
 const state=learningState(raw),q=words(question);if(!q.size)return [];
 // Keep every stored method and its provenance, but never waste the two context
 // slots on the same answer. This selection is read-only; no history is erased.
 const seen=new Set();
 return state.lessons.map(x=>({x,score:norm(x.question)===norm(question)?100:[...words(x.question)].filter(w=>q.has(w)).length})).filter(x=>x.score>=Math.min(2,q.size)).sort((a,b)=>b.score-a.score||(Number(b.x.at)||0)-(Number(a.x.at)||0)||a.x.id.localeCompare(b.x.id)).filter(({x})=>{const key=x.answer.normalize('NFC').replace(/\s+/g,' ').trim();if(seen.has(key))return false;seen.add(key);return true;}).slice(0,2).map(({x})=>({id:x.id,source:'OWNER_VALIDATED_MEMORY',title:'Méthode validée par Fabien',text:x.answer}));
}
export function recordContextUse(raw,ids){const state=learningState(raw);if(state.lessons.some(x=>ids.includes(x.id)))state.contextUses=Math.min(Number.MAX_SAFE_INTEGER,state.contextUses+1);return state;}

// A83: bounded technical evidence; never store prompts, answers or raw logs.
export const ENGINE_PROTOCOL='A83';
export const TRACE_KEY='noyau.llm.trace.A83';
const EVENTS=new Set(['ATTEMPT_STARTED','WORKER_CREATED','WORKER_ACK','LOAD_SENT','LOAD_RECEIVED','RUNTIME_IMPORT_STARTED','RUNTIME_IMPORTED','CACHE_OPEN','CACHE_READ','MODEL_READY','MODEL_REUSED','PROBE_STARTED','PROBE_SAVED','FIRST_TOKEN','REQUEST_STARTED','GENERATION_FINISHED','ANSWER_SAVED','DOWNLOAD_STARTED','FILES_READY','NATIVE_DIAGNOSTIC','FAILED','PAUSED','RELEASED']);
const CODES=new Set(['UNKNOWN','ALLOCATION_FAILURE','FORMAT_FAILURE','TENSOR_FAILURE','BACKEND_FAILURE','CACHE_FAILURE','ABORT_UNKNOWN','STORAGE_FAILURE','WORKER_FAILURE','DEADLINE_EXCEEDED']);
export function diagnosticCode(value){
 const s=typeof value==='string'?value.slice(0,1000):'';
 if(/alloc|out of memory|memory access out of bounds|cannot enlarge/i.test(s))return 'ALLOCATION_FAILURE';
 if(/gguf|invalid magic|unsupported.*format/i.test(s))return 'FORMAT_FAILURE';
 if(/tensor|dimension|shape mismatch/i.test(s))return 'TENSOR_FAILURE';
 if(/wasm|backend|compileerror|linkerror/i.test(s))return 'BACKEND_FAILURE';
 if(/MODEL_PART|MODEL_CACHE|MODEL_STREAM/i.test(s))return 'CACHE_FAILURE';
 if(/CHECKPOINT|STORAGE/i.test(s))return 'STORAGE_FAILURE';
 if(/abort/i.test(s))return 'ABORT_UNKNOWN';
 return 'UNKNOWN';
}
export function safeEvent(event,data={}){
 if(!EVENTS.has(event))return null;
 const out={event};
 for(const k of ['at','elapsedMs','cacheReadBytes','modelBytes','tokens','step','count'])if(Number.isFinite(data[k])&&data[k]>=0)out[k]=data[k];
 if(CODES.has(data.code))out.code=data.code;
 if(['PASS','FAIL','PAUSED','INTERRUPTED'].includes(data.outcome))out.outcome=data.outcome;
 return out;
}
export function readLlmTrace(store=globalThis.localStorage){
 try{const v=JSON.parse(store?.getItem(TRACE_KEY)||'null');if(v?.schema!=='noyau-llm-trace-A83')return null;
 return {schema:v.schema,protocol:ENGINE_PROTOCOL,events:(v.events||[]).slice(-64).map(e=>safeEvent(e.event,e)).filter(Boolean),personalTextIncluded:false,modelReadyObserved:(v.events||[]).some(e=>e.event==='MODEL_READY')};}catch{return null;}
}
export function createLlmTrace({store=globalThis.localStorage,now=()=>Date.now()}={}){
 const started=now();let events=[],lastWrite=0;
 const previous=readLlmTrace(store);if(previous?.events.length)try{store?.setItem(TRACE_KEY+'.history',JSON.stringify([...readLlmTraceHistory(store),previous].slice(-4)));}catch{}
 return {mark(event,data={}){const e=safeEvent(event,{...data,at:now(),elapsedMs:Math.max(0,now()-started)});if(!e)return;
 if(event==='CACHE_READ'&&events.at(-1)?.event==='CACHE_READ')events[events.length-1]=e;else events.push(e);
 events=events.slice(-64);
 if(event==='CACHE_READ'&&now()-lastWrite<1000)return;
 lastWrite=now();try{store?.setItem(TRACE_KEY,JSON.stringify({schema:'noyau-llm-trace-A83',protocol:ENGINE_PROTOCOL,events,personalTextIncluded:false}));}catch{}
 },snapshot(){return {schema:'noyau-llm-trace-A83',protocol:ENGINE_PROTOCOL,events:events.map(e=>({...e})),personalTextIncluded:false};}};
}
export function meteredModelStream(source,onProgress=()=>{}){
 if(!source||!Number.isFinite(source.size)||source.size<=0||typeof source.stream!=='function')throw Error('MODEL_STREAM_CONTRACT');
 return {size:source.size,stream(){const reader=source.stream().getReader();let total=0,closed=false;
 return new ReadableStream({async pull(controller){try{const part=await reader.read();if(closed)return;
 if(part.done){closed=true;reader.releaseLock();if(total!==source.size)throw Error('MODEL_STREAM_LENGTH');controller.close();return;}
 if(!(part.value instanceof Uint8Array))throw Error('MODEL_STREAM_CHUNK');
 total+=part.value.byteLength;if(total>source.size)throw Error('MODEL_STREAM_LENGTH');
 onProgress(total,source.size);controller.enqueue(part.value);
 }catch(error){if(!closed){closed=true;reader.cancel().catch(()=>{});}controller.error(error);}},async cancel(reason){closed=true;await reader.cancel(reason);}}
 ,{highWaterMark:0});}};
}

// Four preceding attempts, sanitized on read as well as write. No raw model logs.
export function readLlmTraceHistory(store=globalThis.localStorage){
 try{const rows=JSON.parse(store?.getItem(TRACE_KEY+'.history')||'[]');if(!Array.isArray(rows))return [];
 return rows.slice(-4).map(v=>readLlmTrace({getItem:()=>JSON.stringify(v)})).filter(Boolean);}catch{return [];}
}
export function traceLabel(trace){
 const events=trace?.events||[],last=events.filter(e=>!['RELEASED','NATIVE_DIAGNOSTIC'].includes(e.event)).at(-1);
 const labels={ATTEMPT_STARTED:'Essai démarré',WORKER_CREATED:'Moteur créé',WORKER_ACK:'Moteur connecté',LOAD_SENT:'Chargement demandé',LOAD_RECEIVED:'Chargement reçu',RUNTIME_IMPORT_STARTED:'Ouverture du moteur',RUNTIME_IMPORTED:'Moteur disponible',CACHE_OPEN:'Cache du modèle ouvert',CACHE_READ:'Lecture des poids dans cet appareil',MODEL_READY:'Modèle prêt',MODEL_REUSED:'Moteur déjà chargé réutilisé',PROBE_STARTED:'Exercice commencé',REQUEST_STARTED:'Requête envoyée au modèle',FIRST_TOKEN:'Premier token produit',GENERATION_FINISHED:'Génération terminée',ANSWER_SAVED:'Réponse sauvegardée et relue',PROBE_SAVED:'Exercice vérifié et sauvegardé',DOWNLOAD_STARTED:'Téléchargement réseau commencé',FILES_READY:'Fichiers locaux disponibles',PAUSED:'Essai mis en pause',FAILED:'Échec observé'};
 return last?'Dernier jalon enregistré : '+(labels[last.event]||'étape technique')+'.':'Aucun jalon du modèle enregistré sur cet appareil.';
}
/* A56 original Blob station artwork and camera. MIT StarNet MAP paths and
 * Generation II compositor are retained; no upstream artwork or runtime. */
(function(){
  'use strict';
  const X=12,Y=8,HULL=24,W=1700,H=1200,OX=720,OY=86;
  const rooms={
    hub:{name:'LE BLOB',short:'BLOB',color:'#80f0be',kind:'brain'},
    bridge:{name:'CERVEAU SERVEUR',short:'SERVEUR',color:'#73d9c8',kind:'server'},
    research:{name:'BIBLIOTHÈQUE',short:'EXERCICES',color:'#afbcf4',kind:'library'},
    comms:{name:'NOYAU PERSONNEL',short:'ASSISTANT',color:'#74d3dc',kind:'relay'},
    factory1:{name:'ATELIER DES PROGRAMMES',short:'PROGRAMMES',color:'#e6c582',kind:'program'},
    factory2:{name:'CALCUL LOCAL',short:'IPHONE',color:'#85d5f2',kind:'phone'},
    treasury:{name:'PLANS ET EFFICACITÉ',short:'PLANS UTILES',color:'#9ad1bc',kind:'efficiency'},
    warroom:{name:'PREUVES ET RÉPARATION',short:'VALIDATION',color:'#f2c47b',kind:'validation'},
    publishing:{name:'FICHIERS ET RÉSULTATS',short:'RÉSULTATS',color:'#c7dba0',kind:'files'},
    archives:{name:'MÉMOIRE ET HISTORIQUE',short:'MÉMOIRE',color:'#9bd8ae',kind:'memory'},
    quarters:{name:'SOCLE PROTÉGÉ',short:'RÉTENTION',color:'#a4bcc5',kind:'foundation'}
  };
  const canvas=document.getElementById('blobStationCanvas');if(!canvas)return;
  const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return;
  const cache=document.createElement('canvas');cache.width=W;cache.height=H;const b=cache.getContext('2d');
  const camera={scale:1,min:.1,max:2,panX:0,panY:0,width:0,height:0,dpr:1};
  const composer=WorldRenderer.create();const geo={TILE:MAP.TILE,W,H};const bake={baseCv:cache,W,H,lamps:[],wallFixtures:[]};
  let model={},selected=null,requestDraw=()=>{},onSelect=()=>{},error='',ready=false;
  const pointers=new Map();let gesture=null,labelHits=[];
  const iso=(x,y,z=0)=>({x:OX+(x-y)*X,y:OY+(x+y)*Y-z});
  const unproject=(x,y)=>{const u=(x-OX)/X,v=(y-OY)/Y;return {x:(u+v)/2,y:(v-u)/2}};
  const poly=(c,pts,fill,stroke)=>{c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=.8;c.stroke()}};
  const face=(c,x,y,w,h,z,fill,stroke)=>poly(c,[iso(x,y,z),iso(x+w,y,z),iso(x+w,y+h,z),iso(x,y+h,z)],fill,stroke);
  const line=(c,a,d,color,width=1)=>{c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(d.x,d.y);c.stroke()};
  function box(c,x,y,w,h,z,color='#324b4a',accent){
    const a=iso(x,y),d=iso(x+w,y),e=iso(x+w,y+h),f=iso(x,y+h),at=iso(x,y,z),dt=iso(x+w,y,z),et=iso(x+w,y+h,z),ft=iso(x,y+h,z);
    poly(c,[d,e,et,dt],'#132528','#425454');poly(c,[e,f,ft,et],'#1a3335','#52635e');poly(c,[at,dt,et,ft],color,'#65736b');
    if(accent){line(c,at,dt,accent,1.5);line(c,dt,et,accent,1)}
    for(let i=2;i<z-2;i+=5)line(c,{x:e.x-4,y:e.y-i},{x:f.x+4,y:f.y-i},'#2b4543',.6);
  }
  function halo(c,x,y,r,color){const g=c.createRadialGradient(x,y,1,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'transparent');c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2)}
  function ellipse(c,x,y,rx,ry,color,stroke){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=color;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke()}}
  function screen(c,x,y,w,h,color,z=24){
    box(c,x,y,w,h,z,'#304142',color);const p=iso(x+.2,y+.7,z+2),q=iso(x+w-.25,y+.7,z+2);
    const pts=[p,q,{x:q.x,y:q.y+13},{x:p.x,y:p.y+13}];poly(c,pts,'#09272c','#4f8585');
    for(let k=1;k<5;k++){const t=k/5;line(c,{x:p.x+3,y:p.y+3+k*1.7},{x:p.x+(q.x-p.x)*t,y:p.y+3+k*1.7+(q.y-p.y)*t},color,.8)}
    halo(c,(p.x+q.x)/2,(p.y+q.y)/2+4,20,color+'28');
  }
  function plant(c,x,y){const p=iso(x+.5,y+.5);box(c,x,y,1,1,5,'#554b32');for(let i=0;i<7;i++){const a=i*2.3;ellipse(c,p.x+Math.cos(a)*5,p.y-7+Math.sin(a)*4,4,3,i%2?'#77a978':'#487969')}}
  function capsuleRack(c,x,y,w,h,color){
    box(c,x,y,w,h,31,'#293e42',color);const p=iso(x+.2,y+h,27),q=iso(x+w-.2,y+h,27);
    for(let row=0;row<4;row++){line(c,{x:p.x,y:p.y+row*6},{x:q.x,y:q.y+row*6},'#687b73',1);for(let col=0;col<Math.max(2,w*2);col++){const t=(col+.3)/(w*2);c.fillStyle=(row+col)%3?color:'#365d5a';c.fillRect(p.x+(q.x-p.x)*t,p.y+(q.y-p.y)*t+row*6,3,3)}}
  }
  function build(){
    b.clearRect(0,0,W,H);
    // Fixed deck with original walkable geometry and original door lanes.
    for(let y=0;y<MAP.ROWS;y++)for(let x=0;x<MAP.COLS;x++){
      const z=MAP.zoneAt?MAP.zoneAt(x,y):MAP.zoneGrid[y*MAP.COLS+x];if(!z)continue;
      const id=typeof z==='string'?z:MAP.roomAt(x,y);if(!id)continue;
      face(b,x,y,1,1,0,((x*13+y*7)%6===0)?'#314446':'#233638','#3a4b49');
      const p=iso(x+.2,y+.2);b.fillStyle='#52605a';if((x+y)%5===0)b.fillRect(p.x,p.y,1,1);
    }
    // Raised ribs on each chamber's rear sides; front rails stay low for visibility.
    for(const id of MAP.ROOM_IDS){const r=MAP.zones[id],a=rooms[id].color;
      for(let x=r.x1;x<=r.x2;x+=2){box(b,x,r.y1,Math.min(2,r.x2+1-x),.45,HULL,'#344441',a);const p=iso(x+.45,r.y1,HULL-5);b.fillStyle='#e4b86b';b.fillRect(p.x,p.y,2,2)}
      for(let y=r.y1;y<=r.y2;y+=2)box(b,r.x1,y,.45,Math.min(2,r.y2+1-y),HULL,'#344441');
      for(let x=r.x1;x<=r.x2;x+=2)box(b,x,r.y2+.55,Math.min(2,r.x2+1-x),.45,5,'#293c3b');
      for(let y=r.y1;y<=r.y2;y+=2)box(b,r.x2+.55,y,.45,Math.min(2,r.y2+1-y),5,'#293c3b');
      const p=iso((r.x1+r.x2)/2,r.y1+1);halo(b,p.x,p.y-10,70,a+'16');
    }
    const drawables=[];
    for(const f of MAP.furniture){
      const id=MAP.roomAt(f.x,f.y),accent=rooms[id]?.color||'#8fbc9c',w=f.w||1,h=f.h||1;
      if(f.x>=33&&f.x<=40&&f.y>=24&&f.y<=31)continue; // reserve the existing hub for Blob organism
      drawables.push({y:iso(f.x+w,f.y+h).y,draw(c){
        if(f.t==='rug'){face(c,f.x,f.y,w,h,1,'#364239','#71816a');return}
        if(f.t==='plant'){plant(c,f.x,f.y);return}
        if(/chair|sofa|bed/.test(f.t)){box(c,f.x,f.y,w,h,7,'#49605a');return}
        if(/tank|core|lens|pillar/.test(f.t)){
          box(c,f.x,f.y,w,h,7,'#334b4a',accent);const p=iso(f.x+w/2,f.y+h/2,7);
          ellipse(c,p.x,p.y-14,Math.max(6,w*5),15,'#143e3b',accent);ellipse(c,p.x,p.y-17,Math.max(4,w*3),8,accent+'a0');return
        }
        if(/rack|shelf|cabinet|archive|library|vault/.test(f.t)){capsuleRack(c,f.x,f.y,w,h,accent);return}
        if(/belt|conveyor/.test(f.t)){box(c,f.x,f.y,w,h,5,'#35413b');for(let k=0;k<w;k+=.7)face(c,f.x+k,f.y+.2,.35,Math.max(.5,h-.4),6,'#b59e64');return}
        if(/screen|desk|console|monitor|wall|board|chart/.test(f.t)){screen(c,f.x,f.y,w,h,accent,/wall|board|screen/.test(f.t)?28:16);return}
        if(/table|bench|holo/.test(f.t)){box(c,f.x,f.y,w,h,11,'#405650',accent);face(c,f.x+.2,f.y+.2,w-.4,h-.4,12,'#20413c');return}
        box(c,f.x,f.y,w,h,10,'#3a4c46',accent);
      }});
    }
    composer.begin({geo,cache:bake,now:0,width:W,height:H,scale:1,panX:0,panY:0});composer.drawEntities(b,drawables);composer.finish();
    // A ring of equipment around the central organism, authored for the Blob.
    const center=iso(36.5,28);
    ellipse(b,center.x,center.y+3,73,36,'#071d20','#405958');
    ellipse(b,center.x,center.y,65,31,'#1f4241','#86be9e');
    ellipse(b,center.x,center.y,53,24,'#123c34','#447b60');
    for(let i=0;i<8;i++){const a=i*Math.PI/4;const x=center.x+67*Math.cos(a),y=center.y+32*Math.sin(a);b.fillStyle='#dda65d';b.fillRect(x-2,y-2,4,3)}
    ready=true;
  }
  function setView(scale,x,y){camera.scale=Math.max(camera.min,Math.min(camera.max,scale));camera.panX=x;camera.panY=y;requestDraw()}
  function reset(full=true){
    // Frame the occupied deck, not the large transparent baking canvas.
    const wide=false,usableH=Math.max(170,camera.height-48),usableW=camera.width-28,deckW=1136,deckH=800;
    camera.min=Math.min(usableW/deckW,usableH/deckH);camera.max=Math.max(1.7,camera.min*6);
    camera.scale=camera.min*(!full&&camera.width<600?1.3:1);camera.panX=(wide?usableW/2+10:camera.width/2)-812*camera.scale;camera.panY=24+usableH/2-600*camera.scale;requestDraw();
  }
  function resize(){const rect=canvas.getBoundingClientRect();camera.width=Math.max(1,rect.width);camera.height=Math.max(1,rect.height);camera.dpr=Math.min(1.5,window.devicePixelRatio||1);canvas.width=Math.round(camera.width*camera.dpr);canvas.height=Math.round(camera.height*camera.dpr);reset(false)}
  function focus(id){const r=MAP.zones[id];if(!r)return;const p=iso((r.x1+r.x2+1)/2,(r.y1+r.y2+1)/2,10),scale=Math.min(camera.max,Math.max(camera.min*2.2,.6));setView(scale,camera.width/2-p.x*scale,camera.height/2-p.y*scale)}
  function zoom(factor,x=camera.width/2,y=camera.height*.4){const old=camera.scale,scale=Math.max(camera.min,Math.min(camera.max,old*factor));setView(scale,x-(x-camera.panX)*scale/old,y-(y-camera.panY)*scale/old)}
  function pick(x,y){for(const hit of [...labelHits].reverse())if(x>=hit.x&&x<=hit.x+hit.w&&y>=hit.y&&y<=hit.y+hit.h)return hit.id;const t=unproject((x-camera.panX)/camera.scale,(y-camera.panY)/camera.scale);for(const id of ['hub',...MAP.ROOM_IDS]){const r=MAP.zones[id];if(t.x>=r.x1-.8&&t.x<=r.x2+1.8&&t.y>=r.y1-.8&&t.y<=r.y2+1.8)return id}return null}
  function drawBlob(c,now){
    const p=iso(36.5,28,24),nodes=model.brain?.programForge?.capabilityGraph?.nodes?.filter(n=>n.state==='PROMOTED')||[];
    const working=model.run?.status==='RUNNING'&&model.local?.workerActive===true&&!model.disconnected;
    const wave=working?Math.sin(now/480)*1.7:0;
    halo(c,p.x,p.y-10,99,'#4ae9ab40');ellipse(c,p.x,p.y+22,39,14,'#021d17');
    const g=c.createRadialGradient(p.x-12,p.y-18,1,p.x,p.y,44);g.addColorStop(0,'#dbffe0');g.addColorStop(.27,'#85ebbd');g.addColorStop(.65,'#32a583');g.addColorStop(1,'#0d564b');
    c.beginPath();for(let i=0;i<=48;i++){const a=i*Math.PI/24,r=31+5*Math.sin(a*3+.5)+3*Math.cos(a*5);const x=p.x+Math.cos(a)*r,y=p.y+Math.sin(a)*r*.8+wave;i?c.lineTo(x,y):c.moveTo(x,y)}c.closePath();c.fillStyle=g;c.fill();c.strokeStyle='#a6f7cd';c.lineWidth=1.8;c.stroke();
    for(let i=0;i<Math.min(12,nodes.length);i++){const a=i*Math.PI*2/Math.max(1,nodes.length)-Math.PI/2,q={x:p.x+Math.cos(a)*49,y:p.y+Math.sin(a)*31};line(c,p,q,'#90d9ab',1);ellipse(c,q.x,q.y,8,6,'#6edfab','#c6f8c7');ellipse(c,q.x-2,q.y-2,3,2,'#e0ffe3')}
    ellipse(c,p.x-11,p.y-12,10,4,'#e2ffdc80');
    // Glass chamber rim and original growing-root silhouette; visual decoration only.
    c.strokeStyle='#b6ecd951';c.lineWidth=1.2;c.beginPath();c.ellipse(p.x,p.y-2,58,47,0,Math.PI,2*Math.PI);c.stroke();
    for(let i=0;i<5;i++){const a=i*.55;line(c,{x:p.x-22+i*11,y:p.y+22},{x:p.x-40+i*20,y:p.y+37+Math.sin(a)*3},'#62b894',1.6)}
  }
  function statusLights(c){
    if(!model.ok)return;
    const good=model.mastery?.mastered||0,total=model.mastery?.total||0,r=MAP.zones.warroom;
    for(let i=0;i<total;i++){const p=iso(r.x1+2+(i%8)*1.3,r.y1+3+Math.floor(i/8)*2,8);ellipse(c,p.x,p.y,4,2.8,i<good?'#93e8b0':'#e7af62',i<good?'#315f46':'#825d37')}
    const q=iso(57,29,22);ellipse(c,q.x,q.y,8,11,model.local?.workerActive&&model.run?.status==='RUNNING'&&!model.disconnected?'#90d9ed':'#31545d','#73949b');
    const core=iso(37,7,18);ellipse(c,core.x,core.y,18,7,'#204c45','#77cba6');
    const retention=model.brain?.retention;const count=Math.min(10,retention?.levels?.length||0);for(let i=0;i<count;i++){const p=iso(29+i*1.5,49,8);ellipse(c,p.x,p.y,3,3,retention.levels[i].exactRate===1?'#8bdcc0':'#e4b465')}
    const mem=model.local?.memory;if(Number.isFinite(mem)){for(let i=0;i<Math.min(24,mem);i++){const p=iso(59+(i%6)*.7,40+Math.floor(i/6)*.5,14);c.fillStyle='#9ae6bc';c.fillRect(p.x,p.y,3,3)}}
  }
  function drawParcels(c,parcels,now){
    for(const p of parcels){
      const fade=Math.max(0,1-(now-p.start)/p.duration);c.save();c.globalAlpha=.1+fade*.3;c.strokeStyle=p.color;c.lineWidth=2.2;c.beginPath();p.path.forEach((tile,i)=>{const q=iso(tile.x+.5,tile.y+.5,3);i?c.lineTo(q.x,q.y):c.moveTo(q.x,q.y)});c.stroke();c.restore();
      for(const id of [p.from,p.to]){const r=MAP.zones[id];if(!r)continue;const q=iso((r.x1+r.x2)/2,(r.y1+r.y2)/2,5);halo(c,q.x,q.y,36,p.color+'35');}
      const t=Math.max(0,Math.min(1,(now-p.start)/p.duration)),v=t*(p.path.length-1),i=Math.min(p.path.length-2,Math.floor(v)),a=p.path[i],d=p.path[i+1];if(!a||!d)continue;const q=iso(a.x+(d.x-a.x)*(v-i)+.5,a.y+(d.y-a.y)*(v-i)+.5,7);
      halo(c,q.x,q.y,18,p.color+'35');box(c,a.x+(d.x-a.x)*(v-i)+.25,a.y+(d.y-a.y)*(v-i)+.25,.5,.5,5,p.color,p.color);
    }
  }
  function labels(c){
    labelHits=[];
    for(const id of ['hub',...MAP.ROOM_IDS]){const r=MAP.zones[id],p=iso((r.x1+r.x2+1)/2,(r.y1+r.y2+1)/2,id==='hub'?82:2),sy=camera.panY+p.y*camera.scale;let sx=camera.panX+p.x*camera.scale;
      const bottom=camera.width>=600&&camera.height<650&&sx<camera.width-334?camera.height-27:camera.height-20;
      if(sx<-50||sx>camera.width+50||sy<12||sy>bottom)continue;
      if(selected&&selected!==id&&camera.scale>camera.min*1.8)continue;
      const label=rooms[id].short;c.font='600 10px -apple-system, sans-serif';const w=c.measureText(label).width+16;
      sx=Math.max(w/2+9,Math.min(camera.width-w/2-9,sx));
      labelHits.push({id,x:sx-w/2-4,y:sy-12,w:w+8,h:27});
      c.fillStyle=selected===id?'#193c34ed':'#061a1be0';c.fillRect(sx-w/2,sy-8,w,19);c.strokeStyle=selected===id?rooms[id].color:'#36504e';c.lineWidth=1;c.strokeRect(sx-w/2+.5,sy-7.5,w-1,18);c.fillStyle=rooms[id].color;c.textAlign='center';c.fillText(label,sx,sy+5);
    }c.textAlign='left';
  }
  function draw(now=0,parcels=[]){
    if(!ready||error)return;const dpr=camera.dpr;c();
    function c(){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#061317';ctx.fillRect(0,0,camera.width,camera.height);
      const g=ctx.createRadialGradient(camera.width*.48,camera.height*.35,20,camera.width*.48,camera.height*.4,camera.height*.7);g.addColorStop(0,'#173237');g.addColorStop(.6,'#0c2028');g.addColorStop(1,'#040b13');ctx.fillStyle=g;ctx.fillRect(0,0,camera.width,camera.height);
      for(let i=0;i<125;i++){const x=(i*97.31)%camera.width,y=(i*61.37)%camera.height;ctx.fillStyle=i%5===0?'#748c873f':'#8bbabe22';ctx.fillRect(x,y,i%9===0?2:1,1)}
      ctx.setTransform(dpr*camera.scale,0,0,dpr*camera.scale,dpr*camera.panX,dpr*camera.panY);ctx.imageSmoothingEnabled=false;
      composer.begin({geo,cache:bake,now,width:camera.width,height:camera.height,scale:camera.scale,panX:camera.panX,panY:camera.panY,reducedMotion:window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches});composer.drawBase(ctx);
      if(selected){const r=MAP.zones[selected];face(ctx,r.x1,r.y1,r.x2-r.x1+1,r.y2-r.y1+1,1,'#77dcad12','#90e3bd')}
      composer.drawEntities(ctx,[{y:iso(36.5,28).y,draw:c=>drawBlob(c,now)},{y:9999,draw:c=>statusLights(c)},{y:10000,draw:c=>drawParcels(c,parcels,now)}]);composer.finish();
      ctx.setTransform(dpr,0,0,dpr,0,0);labels(ctx);
    }
  }
  function relative(e){const r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top}}
  canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture?.(e.pointerId);pointers.set(e.pointerId,relative(e));const ps=[...pointers.values()];if(ps.length===1)gesture={x:ps[0].x,y:ps[0].y,startX:ps[0].x,startY:ps[0].y,panX:camera.panX,panY:camera.panY,moved:false};else if(ps.length===2)gesture={pinch:true,distance:Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y),scale:camera.scale,center:{x:(ps[0].x+ps[1].x)/2,y:(ps[0].y+ps[1].y)/2},panX:camera.panX,panY:camera.panY,moved:true}});
  canvas.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId)||!gesture)return;pointers.set(e.pointerId,relative(e));const ps=[...pointers.values()];if(gesture.pinch&&ps.length===2){const dist=Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y),cx=(ps[0].x+ps[1].x)/2,cy=(ps[0].y+ps[1].y)/2,scale=Math.max(camera.min,Math.min(camera.max,gesture.scale*dist/Math.max(1,gesture.distance)));setView(scale,cx-(gesture.center.x-gesture.panX)*scale/gesture.scale,cy-(gesture.center.y-gesture.panY)*scale/gesture.scale)}else if(!gesture.pinch){const p=ps[0],dx=p.x-gesture.x,dy=p.y-gesture.y;gesture.moved=gesture.moved||Math.hypot(dx,dy)>7;setView(camera.scale,gesture.panX+dx,gesture.panY+dy)}});
  function release(e){if(!pointers.has(e.pointerId))return;const p=pointers.get(e.pointerId);if(gesture&&!gesture.moved&&!gesture.pinch){const id=pick(p.x,p.y);if(id)onSelect(id)}pointers.delete(e.pointerId);if(!pointers.size)gesture=null;else gesture={pinch:true,moved:true}}
  canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);gesture=null});
  canvas.addEventListener('wheel',e=>{e.preventDefault();const p=relative(e);zoom(e.deltaY<0?1.12:1/1.12,p.x,p.y)},{passive:false});
  window.addEventListener('resize',resize);
  window.BlobScene={rooms,iso,unproject,pick,focus,reset,zoom,resize,draw,update(m,id){model=m||{};selected=id||null;requestDraw()},init(select,redraw){onSelect=select;requestDraw=redraw;build();resize()},stats(){return {...composer.stats(),camera:{...camera},error,ready}}};
})();


import {RESEARCH_KEY,researchState} from '/noyau-research-core.js?v=A100';
export async function commitResearch(db,expectedRevision,transform){
 let next;
 await new Promise((resolve,reject)=>{
  const tx=db.transaction('settings','readwrite'),store=tx.objectStore('settings');
  tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error||Error('Enregistrement interrompu. Le dernier point confirmé reste conservé.'));
  store.get(RESEARCH_KEY).onsuccess=e=>{try{
   const current=researchState(e.target.result);if(current.revision!==expectedRevision)throw Error('Recherches modifiées dans un autre onglet ou restaurées. Actualise avant de reprendre.');
   next=researchState(transform(current));next.revision=current.revision+1;if(!Number.isSafeInteger(next.revision))throw Error('Compteur de recherche incompatible.');store.put(next,RESEARCH_KEY);
  }catch(error){tx.abort();reject(error);}};
 });
 const saved=await new Promise((resolve,reject)=>{const tx=db.transaction('settings','readonly');let value;tx.objectStore('settings').get(RESEARCH_KEY).onsuccess=e=>value=e.target.result;tx.oncomplete=()=>resolve(value);tx.onerror=tx.onabort=()=>reject(tx.error||Error('Relecture interrompue.'));});
 if(JSON.stringify(saved)!==JSON.stringify(next))throw Error('Enregistrement non confirmé. Actualise pour relire le dernier point avant de reprendre.');return next;
}

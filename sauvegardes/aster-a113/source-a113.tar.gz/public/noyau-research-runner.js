import {researchState,researchProgress,prepareNextQuestion,RESEARCH_LIMITS} from '/noyau-research-core.js?v=A100';
// The caller holds the shared maintenance lock. Only a user gesture starts this queue.
export async function runResearchQueue(initial,id,{save,signal,visible=()=>!document.hidden,onProgress=()=>{},yieldControl=()=>new Promise(resolve=>setTimeout(resolve,0)),now=()=>performance.now()}){
 let state=researchState(initial);const started=now();
 for(;;){
  const d=state.dossiers.find(x=>x.id===id);if(!d)throw Error('Dossier introuvable.');
  if(researchProgress(d).done===d.questions.length)return {state,status:'complete'};
  if(signal.aborted||!visible())return {state,status:'paused'};
  if(now()-started>=RESEARCH_LIMITS.sessionMs)return {state,status:'limited'};
  const next=prepareNextQuestion(state,id);
  if(signal.aborted||!visible())return {state,status:'paused'};
  state=await save(state.revision,()=>next);
  onProgress(state); // Never announce a completed question before storage readback.
  await yieldControl();
 }
}

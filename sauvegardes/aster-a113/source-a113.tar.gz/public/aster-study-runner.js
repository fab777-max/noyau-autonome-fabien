import {MODEL,MODEL_MODE,cacheReport} from '/blob-assistant-model.js?v=A83';
import {workerModelOptions} from '/blob-model-choice.js?v=A100';
import {reserveEngine} from '/blob-local-pilot.js?v=A91';
import {ENGINE_PROTOCOL} from '/blob-llm-evidence.js?v=A91';
import {STUDY_PROTOCOL,studyMessages} from '/aster-study-cases.js?v=A106';
import {STUDY_LIMITS,validateStudy,recoverStudy,nextStudyItem,studyPacket,beginStudyItem,finishStudyItem} from '/aster-study-core.js?v=A113';
export async function runStudy(initial,{save,onProgress=()=>{},signal}={}){
 let s=recoverStudy(initial);if(['review','graded'].includes(s.status))return s;
 if(s.status==='waiting')throw Error('Réponds à la question avant de reprendre.');
 if(s.model!==MODEL.id||s.modelRevision!==MODEL.revision)throw Error('Le modèle de cette séance a changé. Conserve le bilan puis termine cette séance.');
 if(s.starts>=STUDY_LIMITS.starts)throw Error('Six reprises utilisées. Termine ce bilan avant une autre séance.');
 let worker,release,waiting=null,storageFailed=false,started=false;
 const control=new AbortController(),abort=()=>control.abort(Error('Étude en pause. Reprise manuelle.')),hidden=()=>{if(document.hidden)abort();};
 signal?.addEventListener('abort',abort,{once:true});document.addEventListener('visibilitychange',hidden);globalThis.addEventListener?.('pagehide',abort);
 const start=performance.now(),base=s.activeMs,total=s.minutes*60000;
 const elapsed=()=>Math.min(total,base+Math.max(0,performance.now()-start)),remaining=()=>Math.max(0,total-elapsed());
 const check=()=>{if(document.hidden||signal?.aborted)abort();control.signal.throwIfAborted();if(remaining()<=0)throw Error('Budget de temps atteint. Bilan partiel conservé.');};
 const timer=setTimeout(()=>control.abort(Error('Budget de temps atteint. Bilan partiel conservé.')),Math.max(1,total-base));
 async function persist(){s.activeMs=elapsed();if(s.reservation)s.reservation.ms=Math.min(s.reservation.ms,total-s.activeMs);s.updatedAt=new Date().toISOString();s=validateStudy(s);try{await save(structuredClone(s));}catch(e){storageFailed=true;throw e;}}
 function call(message,expected,ms){
  check();if(waiting)throw Error('Un calcul est déjà en cours.');
  return new Promise((resolve,reject)=>{const stopped=()=>done(control.signal.reason||Error('Étude interrompue.')),timeout=setTimeout(()=>done(Error('Calcul trop long. Reprise manuelle ; aucun nouvel essai automatique.')),Math.max(1,Math.min(ms,remaining())));
   function done(err,value){if(waiting?.done!==done)return;clearTimeout(timeout);control.signal.removeEventListener('abort',stopped);waiting=null;err?reject(err):resolve(value);}
   waiting={done,expected,id:message.requestId};control.signal.addEventListener('abort',stopped,{once:true});try{worker.postMessage(message);}catch(e){done(e);}
  });
 }
 try{
  check();onProgress('Vérification du modèle installé…');if(!(await cacheReport()).complete)throw Error('Modèle absent ou incomplet. Aucun téléchargement lancé. Ouvre la mémoire et les réglages pour l’installer.');check();
  if(!globalThis.navigator?.locks?.request)throw Error('Verrou entre onglets indisponible. La séance n’a pas démarré.');
  release=await reserveEngine();if(!release)throw Error('Un autre travail utilise le modèle. Mets-le en pause avant l’étude.');check();
  if(!nextStudyItem(s)||remaining()<1000){s.status='review';s.reason='Travail disponible terminé ou budget épuisé.';await persist();return s;}
  s.starts++;s.status='running';s.reason='';s.reservation={kind:'load',ms:Math.min(remaining(),STUDY_LIMITS.loadMs+20000)};await persist();started=true;check();
  worker=new Worker('/blob-assistant-worker.js?v=A113&llm='+MODEL_MODE,workerModelOptions(MODEL_MODE));
  worker.onerror=worker.onmessageerror=()=>waiting?.done(Error('Moteur interrompu. Les résultats enregistrés sont conservés.'));
  worker.onmessage=({data:p})=>{if(!p||!waiting)return;if(p.type==='STAGE'){onProgress(String(p.label||'Étude').slice(0,160));return;}if(p.type==='ERROR'){waiting.done(Error(p.message==='DIALOGUE_CONTEXT_TOO_LONG'?'Exercice trop long pour ce modèle ; aucune donnée n’a été coupée.':String(p.message||'Erreur du modèle').slice(0,250)));return;}if(p.type!==waiting.expected||waiting.id&&waiting.id!==p.requestId)return;waiting.done(null,p);};
  const nonce=crypto.randomUUID(),hello=await call({type:'HELLO',nonce},'HELLO_ACK',20000);
  if(hello.nonce!==nonce||hello.protocol!==ENGINE_PROTOCOL||hello.studyProtocol!==STUDY_PROTOCOL||hello.model!==MODEL.id||hello.revision!==MODEL.revision)throw Error('Version du moteur incompatible. Ouvre la mise à jour.');
  onProgress('Chargement unique du modèle déjà conservé sur cet appareil…');
  const ready=await call({type:'LOAD',profile:'safe-64',projectWork:true,probe:true},'READY',STUDY_LIMITS.loadMs);
  if(ready.model!==MODEL.id||ready.revision!==MODEL.revision||ready.actual?.n_ctx!==1024||ready.actual?.n_batch!==64||ready.actual?.n_threads!==1||ready.actual?.sliceMs!==25||ready.actual?.pauseMs!==50)throw Error('Configuration du moteur non confirmée.');
  s.reservation=null;await persist();
  while(nextStudyItem(s)&&s.calls<24){
   check();const row=nextStudyItem(s),packet=studyPacket(s,row);studyMessages(packet);
   s.activeMs=elapsed();s=beginStudyItem(s,row.id,Math.min(STUDY_LIMITS.stepMs,remaining()));await persist();check();
   onProgress('Exercice '+(s.items.indexOf(s.items.find(r=>r.id===row.id))+1)+'/'+s.items.length+' · '+(packet.correction?'correction guidée':'nouvel essai')+'…');
   const result=await call({type:'STUDY_STEP',requestId:crypto.randomUUID(),packet},'STUDY_RESULT',STUDY_LIMITS.stepMs);
   check();s=finishStudyItem(s,result);await persist();onProgress('Résultat enregistré et vérifié.');
   if(s.status==='waiting')return s;
  }
  s.status='review';s.reason='Exercices disponibles terminés. Pas de calcul pour remplir le temps restant.';await persist();return s;
 }catch(e){
  if(started&&!storageFailed){for(const row of s.items)if(row.status==='running'){row.attempts.at(-1).status='interrupted';row.status=row.attempts.length<(row.phase==='study'?2:1)?'pending':'skipped';}s.reservation=null;s.status=remaining()<=0?'review':'paused';s.reason=String(e.message).slice(0,300);if(s.errors.length<12)s.errors.push({at:new Date().toISOString(),reason:s.reason});await persist();}
  throw e;
 }finally{clearTimeout(timer);worker?.terminate();release?.();signal?.removeEventListener('abort',abort);document.removeEventListener('visibilitychange',hidden);globalThis.removeEventListener?.('pagehide',abort);}
}

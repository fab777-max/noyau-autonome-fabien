import {imageIntent,imageDraft,imageHash} from '/aster-image-core.js?v=A107';
// Only an explicit confirmed start may send a photo or trigger paid inference.
export async function initImageUI({root,execute,status,getProject,saveDraft,getSource}){
 let data={config:{ready:false,reason:'Connexion au service d’images non vérifiée.'},items:[],estimates:{}},error='',working=false,invalid=false,showAll=false;
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 const draft=()=>imageDraft(getProject().studio.imageRequest);
 function button(label,fn){const b=el('button',label,'secondary');b.type='button';b.disabled=working||invalid;b.onclick=()=>execute(fn);return b;}
 async function api(payload=null,query=''){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),payload?.action==='start'?190000:15000);
  try{const r=await fetch('/api/image-jobs'+query,{method:payload?'POST':'GET',credentials:'same-origin',cache:'no-store',headers:payload?{'content-type':'application/json'}:undefined,body:payload?JSON.stringify(payload):undefined,signal:controller.signal});
   if(!r.headers.get('content-type')?.includes('application/json'))throw Error('Connexion au site requise. Aucun résultat confirmé.');
   const value=await r.json();if(!r.ok)throw Error(value.error||'Le service ne confirme pas la demande.');return value;
  }finally{clearTimeout(timer);}
 }
 async function refresh(){try{data=await api();error='';}catch(e){error=e.message;}render();}
 async function clear(){const d=draft();if(d?.attempted&&!confirm('Conserver le suivi serveur et fermer cette demande ? Un appel déjà lancé peut rester facturé. Aucun nouveau calcul ne sera lancé.'))return;await saveDraft(null);error='';render();}
 async function start(checkbox){
  const d=draft();if(!d||d.attempted||working||invalid)return;
  if(!checkbox.checked)throw Error('Confirme l’envoi de la demande au moteur d’image.');
  if(!data.config.ready)throw Error(data.config.reason);
  let source=null;
  if(d.mode==='edit'){source=await getSource(d.photoId);if(!source||await imageHash(source)!==d.sourceHash)throw Error('La photo a changé. Ferme cette demande puis prépare la retouche à nouveau.');}
  // Commit local attempt key BEFORE sending. Reload/restore only reads status.
  await saveDraft({...d,attempted:true});working=true;error='';render();
  try{const result=await api({action:'start',key:d.key,projectId:d.projectId,prompt:d.prompt,mode:d.mode,image:source,consent:true});data.items=[result,...data.items.filter(x=>x.key!==result.key)];status(result.status==='ready'?'Image reçue. Relis-la puis récupère le PNG.':'État du travail enregistré. Consulte le détail sous la conversation.');}
  catch(e){error=e.message+' Vérifie l’état pour retrouver un éventuel résultat. Aucune relance automatique.';}
  finally{working=false;render();}
 }
 function render(){
  root.replaceChildren();const d=draft(),items=data.items.filter(x=>showAll||x.projectId===getProject().id);root.hidden=!d&&!items.length&&!showAll;
  if(root.hidden)return;
  root.append(el('h2','Mes images'));
  if(invalid){root.append(el('p','La mémoire a été restaurée. Rouvre la page avant une nouvelle demande.','status error'));return;}
  if(error)root.append(el('p',error,'status error'));
  if(d){const card=el('article',null,'image-request');card.append(el('p',d.prompt));
   const match=data.items.find(x=>x.key===d.key),estimate=data.estimates[d.mode];
   if(!d.attempted){
    card.append(el('p',estimate?'Durée observée : '+estimate.lowSeconds+'–'+estimate.highSeconds+' s sur '+estimate.samples+' travaux comparables. Ce n’est pas une garantie.':'Durée encore inconnue : pas assez de mesures comparables.','helper'));
    if(!data.config.ready)card.append(el('p',data.config.reason,'status'));
    else{
     card.append(el('p','Une image PNG de 1 024 × 1 024 pixels. Un appel au moteur OpenAI ; quota configuré : '+data.config.dailyCalls+'/jour, '+data.config.totalCalls+' au total. La facturation API est distincte de ce site.','helper'));
     const label=el('label',null,'approval'),check=el('input');check.type='checkbox';label.append(check,el('span',d.mode==='edit'?'J’autorise l’envoi de cette photo et de ma demande à OpenAI pour cette retouche.':'J’autorise l’envoi de ma demande à OpenAI pour créer cette image.'));card.append(label);
     if(d.mode==='edit')card.append(el('p','La copie locale reste conservée. Le moteur peut modifier des détails : vérifie le résultat avant livraison.','helper'));
     const launch=button('Créer mon image',()=>start(check));launch.disabled=true;check.onchange=()=>{launch.disabled=!check.checked||working||invalid;};card.append(launch);
    }
   }else if(!match||match.status==='running')card.append(el('p',working?'Création en cours. Garde la page ouverte jusqu’à réception.':'Envoi enregistré localement. Vérifie son état avant toute nouvelle demande.','status'));
   card.append(button(d.attempted?'Fermer cette demande':'Annuler cette préparation',clear));root.append(card);
  }
  for(const job of items){const card=el('article',null,'image-job');card.append(el('p',job.prompt),el('small',new Date(job.created_at).toLocaleString('fr-FR')));
   const labels={ready:'Image reçue — à vérifier',running:'Création en cours',uncertain:'Résultat non confirmé. L’appel peut avoir été facturé. Aucun nouvel essai lancé.',failed:'Le moteur a refusé cette demande. Aucun nouvel essai lancé.',deleting:'Suppression interrompue. Reprends-la pour retirer le fichier.',deleted:'Résultat retiré.'};card.append(el('p',labels[job.status]||'État à vérifier','status'));
   if(job.status==='ready'){
    const img=el('img');img.alt='Image générée : '+job.prompt;img.src='/api/image-jobs?id='+job.id+'&file=1';img.loading='lazy';card.append(img);
    const a=el('a','Récupérer mon image · PNG','button');a.href=job.download;a.download='aster-'+job.id+'.png';card.append(a);
    card.append(el('p','Temps mesuré : '+Math.ceil(job.elapsed_ms/1000)+' s. Vérifie les objets, les textes et les détails importants.','helper'));
   }
   if(job.status!=='running')card.append(button('Supprimer ce résultat',async()=>{if(!confirm('Supprimer ce résultat du serveur ? Télécharge-le d’abord si tu veux le garder. La photo locale reste conservée.'))return;await api({action:'delete',id:job.id});await refresh();}));
   root.append(card);
  }
  root.append(button('Vérifier l’état',refresh));
  root.append(el('p','20 travaux conservés au maximum. Les images du moteur sont privées sur le serveur, jusqu’à suppression ; récupère les PNG pour les sauvegarder. Elles ne sont pas incluses dans la sauvegarde locale. Pas de vidéo ni d’entraînement automatique.','helper'));
 }
 async function handle(text,photoIndex=null){
  const intent=imageIntent(text);if(!intent)return false;if(invalid)throw Error('Rouvre la page après la restauration.');
  if(intent.kind==='list'){showAll=true;await refresh();root.scrollIntoView({block:'start'});return true;}
  const previous=draft();if(previous?.attempted){showAll=true;await refresh();throw Error('Une demande d’image est déjà suivie. Consulte son résultat puis ferme cette demande avant la suivante.');}
  const p=getProject();let photoId=null,sourceHash=null;
  if(intent.mode==='edit'){const index=intent.index??photoIndex??0,photo=p.photos[index];if(!photo)throw Error('Ajoute ou sélectionne d’abord la photo à transformer.');photoId=photo.id;sourceHash=await imageHash(await getSource(photoId));}
  await saveDraft({schema:1,key:crypto.randomUUID(),projectId:p.id,prompt:intent.prompt,mode:intent.mode,photoId,sourceHash,attempted:false});showAll=false;await refresh();render();root.scrollIntoView({block:'start'});return true;
 }
 await refresh();return{handle,render,pending:()=>working,invalidate:()=>{invalid=true;render();}};
}

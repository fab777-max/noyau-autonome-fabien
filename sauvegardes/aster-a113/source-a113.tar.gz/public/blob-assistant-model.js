import {MANIFEST as STANDARD_MANIFEST} from '/blob-model-manifest.js?v=A63';
import {COMPACT_MANIFEST} from '/blob-model-compact.js?v=A82';
import {modelChoice,MODEL_CHOICE_KEY} from '/blob-model-choice.js?v=A82';
let savedChoice;try{savedChoice=globalThis.localStorage?.getItem(MODEL_CHOICE_KEY);}catch{}
export const MODEL_MODE=modelChoice(globalThis.location?.href||'https://noyau.invalid',savedChoice,typeof window==='undefined'?globalThis.name:undefined);
const MANIFEST=MODEL_MODE==='compact'?COMPACT_MANIFEST:STANDARD_MANIFEST;
const STANDARD_MODEL={id:'Qwen/Qwen2.5-1.5B-Instruct-GGUF',revision:'91cad51170dc346986eccefdc2dd33a9da36ead9',dtype:'Q4_K_M',label:'Noyau Personnel · base Qwen2.5 1,5B',modelBytes:1117320736,sourceSha256:'6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e'};
export const MODEL=MODEL_MODE==='compact'?{id:COMPACT_MANIFEST.model,revision:COMPACT_MANIFEST.revision,dtype:'Q4_K_M',label:'Noyau Personnel · mode iPhone léger · Qwen2.5 0,5B',modelBytes:491400032,sourceSha256:'74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db'}:STANDARD_MODEL;
export const CACHE='noyau-models-v1';
export const FILES=Object.keys(MANIFEST.files);
export const modelURL=file=>'https://huggingface.co/'+MODEL.id+'/resolve/'+MODEL.revision+'/'+file;
const validEntry=(r,file)=>!!r&&r.headers.get('x-noyau-complete')==='sha256-v3'&&Number(r.headers.get('content-length'))===MANIFEST.files[file]?.bytes&&r.headers.get('x-noyau-sha256')===MANIFEST.files[file]?.sha256;
const partsMarker=file=>modelURL(file)+'?noyau-parts-ready=v1';
const partKey=(file,n)=>modelURL(file)+'?noyau-part='+n;
const partSize=(spec,n)=>Math.min(MANIFEST.chunkBytes,spec.bytes-n*MANIFEST.chunkBytes);
const validPart=(r,spec,n)=>!!r&&Number(r.headers.get('content-length'))===partSize(spec,n)&&r.headers.get('x-noyau-sha256')===spec.chunks[n];
export async function cacheReport(){
 const cache=await caches.open(CACHE),parts=await caches.open(PARTS),files=[];let partialBytes=0;
 for(const file of FILES){
  const spec=MANIFEST.files[file],response=await cache.match(modelURL(file));
  let cached=validEntry(response,file),storage=cached?'file':null,present=0;
  if(!cached){
   for(let n=0;n<spec.chunks.length;n++)if(validPart(await parts.match(partKey(file,n)),spec,n))present+=partSize(spec,n);
   const marker=await cache.match(partsMarker(file));
   cached=present===spec.bytes&&marker?.headers.get('x-noyau-sha256')===spec.sha256;
   if(cached)storage='segments';else partialBytes+=present;
  }
  files.push({file,cached,bytes:cached?spec.bytes:0,storage});
 }
 const complete=files.every(f=>f.cached);
 return {activated:complete&&await isActivated(),files,complete,cached:files.filter(f=>f.cached).length,bytes:files.reduce((n,f)=>n+f.bytes,0),partialBytes,totalBytes:FILES.reduce((n,f)=>n+MANIFEST.files[f].bytes,0)};
}
// wllama 2.3.7 consumes size + stream() in ProxyToWorker.fileWrite.
// One logical GGUF, NOT separate GGUF shards. Never assemble a full JS Blob.
export async function openModelStream(file=FILES[0]){
 const spec=MANIFEST.files[file];if(!spec)throw Error('MODEL_CACHE_MISSING');
 const cache=await caches.open(CACHE),full=await cache.match(modelURL(file));
 if(validEntry(full,file))return {size:spec.bytes,stream:()=>full.body};
 const marker=await cache.match(partsMarker(file));
 if(marker?.headers.get('x-noyau-sha256')!==spec.sha256)throw Error('MODEL_CACHE_MISSING');
 return {size:spec.bytes,stream(){let next=0,cancelled=false;return new ReadableStream({
  async pull(controller){try{
   if(next===spec.chunks.length){controller.close();return;}
   const n=next++,parts=await caches.open(PARTS),r=await parts.match(partKey(file,n));
   if(!r)throw Error('MODEL_PART_MISSING');
   const bytes=new Uint8Array(await r.arrayBuffer());
   // The immutable ready marker is written only after every segment passed SHA-256 during INSTALL.
   // During RUN, check segment identity/length but do not hash 1.1 GB again immediately before WASM allocation.
   if(bytes.byteLength!==partSize(spec,n)||r.headers.get('x-noyau-sha256')!==spec.chunks[n])throw Error('MODEL_PART_MISMATCH');
   if(!cancelled)controller.enqueue(bytes);
  }catch(e){if(!cancelled)controller.error(e);}},cancel(){cancelled=true;}
 },{highWaterMark:0});}};
}
// The inventory reads headers only: no full model buffer and no IndexedDB deletion.
const MODEL_CACHES=['noyau-models-v1','transformers-cache','noyau-download-parts-v1'];
const KNOWN_MODELS=new Set([MODEL.id,STANDARD_MODEL.id,COMPACT_MANIFEST.model,'onnx-community/Qwen2.5-1.5B-Instruct','onnx-community/SmolLM2-135M-Instruct-ONNX','onnx-community/Qwen3-0.6B-ONNX','onnx-community/Qwen2.5-0.5B-Instruct','onnx-community/Qwen3.5-0.8B-ONNX-OPT']);
export async function modelInventory(){
 const active=await cacheReport(),activated=await isActivated(),names=await caches.keys(),entries=[];
 for(const name of names.filter(n=>MODEL_CACHES.includes(n))){
  const cache=await caches.open(name);
  for(const req of await cache.keys()){
   const url=new URL(req.url),m=url.pathname.match(/^\/(.+?)\/resolve\/([^/]+)\/(.+)$/);
   if(url.origin!=='https://huggingface.co'||!m||!KNOWN_MODELS.has(m[1])||(m[3]==='_noyau-activation'||url.searchParams.has('noyau-parts-ready')))continue;
   const response=await cache.match(req),bytes=Number(response?.headers.get('content-length'))||0;
   const current=m[1]===MODEL.id&&m[2]===MODEL.revision&&FILES.includes(m[3])&&!url.search;
   const runtime=m[1]===MODEL.id&&m[2]==='main'&&m[3]==='config.json';
   const currentPart=name===PARTS&&m[1]===MODEL.id&&m[2]===MODEL.revision&&FILES.includes(m[3])&&url.searchParams.has('noyau-part');
   const kind=currentPart?'segments':current?(name===CACHE?'active':'duplicate'):runtime?'runtime':'obsolete';
   entries.push({cache:name,url:req.url,model:m[1],revision:m[2],file:m[3],bytes,kind,removable:active.complete&&activated&&![STANDARD_MODEL.id,COMPACT_MANIFEST.model].includes(m[1])&&['duplicate','obsolete'].includes(kind)});
  }
 }
 const estimate=await globalThis.navigator?.storage?.estimate?.().catch(()=>null);
 return {active,entries,siteBytes:estimate?.usage??null,reclaimableBytes:entries.filter(e=>e.removable).reduce((n,e)=>n+e.bytes,0),protectedStorage:['strategies','proofs','conversations','notes']};
}
export async function pruneLegacyModelCache(){
 const report=await modelInventory();let removed=0,bytes=0;
 if(!report.active.complete)return {removed,bytes};
 for(const entry of report.entries.filter(e=>e.removable)){
  const cache=await caches.open(entry.cache),r=await cache.match(entry.url);
  if(!r||Number(r.headers.get('content-length'))!==entry.bytes)continue;
  if(!(await cacheReport()).complete)break;
  if(await cache.delete(entry.url)){removed++;bytes+=entry.bytes;}
 }
 return {removed,bytes};
}

const PARTS='noyau-download-parts-v1';
const hex=bytes=>[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
const digest=async bytes=>hex(await crypto.subtle.digest('SHA-256',bytes));
const activationURL=()=>modelURL('_noyau-activation');
async function isActivated(){const c=await caches.open(CACHE);return !!await c.match(activationURL());}
export async function activateModel(){if(!(await cacheReport()).complete)return;const c=await caches.open(CACHE);await c.put(activationURL(),new Response('local-response-completed'));}
export function storagePlan(report,estimate){
 const missing=Math.max(0,report.totalBytes-report.bytes-report.partialBytes),reserve=missing?32*1024*1024+2*MANIFEST.chunkBytes:0;
 const available=Number.isFinite(estimate?.quota)&&Number.isFinite(estimate?.usage)?Math.max(0,estimate.quota-estimate.usage):null;
 return {missingBytes:missing,requiredBytes:missing+reserve,availableBytes:available,enough:available===null?null:available>=missing+reserve};
}
export async function prepareModel(onProgress=()=>{},signal,options={}){
 const work=async()=>{
 const cache=await caches.open(CACHE),parts=await caches.open(PARTS);let fetched=0,networkBytes=0,requests=0;
 const initial=await cacheReport();
 const estimate=await globalThis.navigator?.storage?.estimate?.().catch(()=>null),space=storagePlan(initial,estimate);
 onProgress({phase:'STORAGE',...space,networkBytes,requests});
 if(space.enough===false&&space.missingBytes>0)throw Error('MODEL_STORAGE_REQUIRED_'+Math.ceil(space.requiredBytes/1000000));
 for(const [index,file] of FILES.entries()){
  signal?.throwIfAborted();const url=modelURL(file),spec=MANIFEST.files[file],old=await cache.match(url);
  if(validEntry(old,file)){onProgress({file,index:index+1,count:FILES.length,loaded:spec.bytes,total:spec.bytes,cached:true,done:true,networkBytes,requests});continue;}
  let usedNetwork=false,loaded=0,transferKind='range',transferReceived=0;
  const key=n=>url+'?noyau-part='+n;
  const sizeOf=n=>Math.min(MANIFEST.chunkBytes,spec.bytes-n*MANIFEST.chunkBytes),verified=new Set();
  const progress=(phase,extra={})=>onProgress({phase,file,index:index+1,count:FILES.length,loaded,total:spec.bytes,verifiedBytes:loaded,transferKind,transferReceived,networkBytes,requests,...extra});
  const savePart=async(n,bytes)=>{
   signal?.throwIfAborted();
   if(bytes.byteLength!==sizeOf(n)||await digest(bytes)!==spec.chunks[n])throw Error('MODEL_SHA256_MISMATCH');
   signal?.throwIfAborted();
   await parts.put(key(n),new Response(bytes,{headers:{'content-length':String(bytes.byteLength),'x-noyau-sha256':spec.chunks[n]}}));
   verified.add(n);loaded+=bytes.byteLength;progress('VERIFY');
  };
  // Verify every saved segment before network I/O. A full HTTP 200 response can
  // then skip saved bytes without overwriting them or buffering the whole model.
  for(let n=0;n<spec.chunks.length;n++){
   signal?.throwIfAborted();progress('VERIFY');const part=await parts.match(key(n));
   if(part){
    const bytes=await part.arrayBuffer();
    if(bytes.byteLength===sizeOf(n)&&await digest(bytes)===spec.chunks[n]){verified.add(n);loaded+=bytes.byteLength;}
    else await parts.delete(key(n));
   }
  }
  const receive=async(response,first,last,full)=>{
   if(!response.body)throw Error('MODEL_DOWNLOAD_INCOMPLETE');
   const reader=response.body.getReader(),expected=full?spec.bytes:sizeOf(first);
   const abort=()=>{reader.cancel(signal.reason).catch(()=>{});};
   let received=0,n=first,offset=0,buffer=null,lastProgress=0;
   transferKind=full?'full':'range';transferReceived=0;progress('PREPARE');
   signal?.addEventListener('abort',abort,{once:true});
   try{
    const length=response.headers.get('content-length');
    if(length!==null&&Number(length)!==expected)throw Error('MODEL_DOWNLOAD_BOUNDS');
    while(true){
     signal?.throwIfAborted();const p=await reader.read();signal?.throwIfAborted();if(p.done)break;
     received+=p.value.byteLength;networkBytes+=p.value.byteLength;if(received>expected)throw Error('MODEL_DOWNLOAD_BOUNDS');
     for(let cursor=0;cursor<p.value.byteLength;){
      const size=sizeOf(n),take=Math.min(size-offset,p.value.byteLength-cursor);
      if(!verified.has(n)){if(!buffer)buffer=new Uint8Array(size);buffer.set(p.value.subarray(cursor,cursor+take),offset);}
      offset+=take;cursor+=take;transferReceived+=take;
      if(offset===size){if(buffer)await savePart(n,buffer);n++;offset=0;buffer=null;}
      if(performance.now()-lastProgress>500){lastProgress=performance.now();progress('PREPARE',{loaded:loaded+(buffer?offset:0)});}
      signal?.throwIfAborted();
     }
    }
    if(received!==expected||n!==last+1||offset!==0)throw Error('MODEL_DOWNLOAD_INCOMPLETE');
   }catch(error){await reader.cancel(error).catch(()=>{});throw error;}
   finally{signal?.removeEventListener('abort',abort);reader.releaseLock();}
  };
  for(let n=0;n<spec.chunks.length;n++){
   signal?.throwIfAborted();if(verified.has(n))continue;
   const begin=n*MANIFEST.chunkBytes,end=begin+sizeOf(n)-1;
   usedNetwork=true;requests++;const r=await fetch(url,{signal,cache:'no-store',credentials:'omit',headers:spec.chunks.length>1?{Range:'bytes='+begin+'-'+end}:{}});
   if(r.status===200){
    if(loaded>0&&options.allowFullRestart!==true){await r.body?.cancel().catch(()=>{});progress('RESUME_BLOCKED');throw Error('MODEL_RESUME_UNSUPPORTED');}
    await receive(r,0,spec.chunks.length-1,true);break;
   }
   const range=r.headers.get('content-range');
   if(r.status!==206||range&&range!=='bytes '+begin+'-'+end+'/'+spec.bytes){
    await r.body?.cancel().catch(()=>{});throw Error(r.status!==206?'MODEL_RANGE_HTTP_'+r.status:'MODEL_RANGE_MISMATCH');
   }
   await receive(r,n,n,false);
  }
  signal?.throwIfAborted();if(verified.size!==spec.chunks.length)throw Error('MODEL_PART_MISSING');
  progress('SAVE');
  // Atomic small marker after every segment was hashed; keep the segments as
  // the only model representation. A crash before this write loses no bytes.
  await cache.put(partsMarker(file),new Response('verified-segments-v1',{headers:{'x-noyau-sha256':spec.sha256}}));
  if(usedNetwork)fetched++;onProgress({file,index:index+1,count:FILES.length,loaded,total:spec.bytes,cached:false,done:true,networkBytes,requests});
 }
 return {...await cacheReport(),fetched,networkBytes,requests};
 };
 return globalThis.navigator?.locks?.request?globalThis.navigator.locks.request('noyau-model-chunks-v3',work):work();
}


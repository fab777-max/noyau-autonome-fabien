// A72.1: a small allowlist of executable local actions. No generated code or URLs.
export const LOCAL_ACTIONS=Object.freeze({
 'optimise le modele local':'PILOT_START',
 'optimise le llm local':'PILOT_START',
 "lance l'optimisation locale":'PILOT_START',
 "arrete l'optimisation locale":'PILOT_STOP',
 "bilan de l'optimisation locale":'PILOT_REPORT',
 'retablis le reglage initial':'PILOT_RESET',
 'analyse les doublons':'MEMORY_AUDIT',
 'analyse les doublons de memoire':'MEMORY_AUDIT'
});
export function localAction(text){
 if(typeof text!=='string'||text.length>180)return null;
 const key=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’]/g,"'").replace(/[.!]+$/g,'').trim().replace(/\s+/g,' ');
 return Object.hasOwn(LOCAL_ACTIONS,key)?LOCAL_ACTIONS[key]:null;
}
export function pilotReport(p){
 const receipts=p?.receipts||[],count=outcome=>receipts.filter(r=>r.outcome===outcome).length;
 return 'Optimisation locale : '+count('PASS')+' contrôles réussis, '+count('FAIL')+' contrôles échoués, '+count('INTERRUPTED')+' interruptions de cause inconnue, '+count('EQUIVALENT')+' réglages équivalents. '+(p?.manualOriginal?'Réglage initial choisi. ':p?.selected?'Profil retenu : '+p.selected+'. ':'Aucun profil validé. ')+(p?.enabled?'Essais autorisés, en attente ou en cours. ':'Essais en pause ou terminés. ')+'Les contrôles du catalogue ne certifient ni la qualité générale ni une absence de plantage. Aucun poids du modèle modifié.';
}
// An exact repetition is only a candidate for review, never permission to delete.
// Scan in small batches and keep only counts in the report, not personal contents.
export async function auditRepetitions(personal,documents,{yieldWork=()=>new Promise(resolve=>setTimeout(resolve,0)),canContinue=()=>true}={}){
 const report={schema:'local-repetition-audit-v1',scope:'ACTIVE_LOCAL_DIALOGUE_NOTES_DOCUMENTS',readOnly:true,deleted:0,complete:true,at:Date.now(),notes:{scanned:0,repetitions:0},documents:{scanned:0,repetitions:0},messages:{scanned:0,repetitions:0},totalScanned:0};
 async function scan(rows,key,field){
  const seen=new Set();
  for(const row of rows||[]){
   if(report.totalScanned>=20000||!canContinue()){report.complete=false;return false;}
   const value=key(row);if(typeof value!=='string'||!value.length)continue;
   report[field].scanned++;report.totalScanned++;
   if(seen.has(value))report[field].repetitions++;else seen.add(value);
   if(report.totalScanned%64===0)await yieldWork();
  }return true;
 }
 if(!await scan(personal?.notes,n=>n?.text,'notes'))return report;
 if(!await scan(documents,d=>d?.text,'documents'))return report;
 // Repeated messages are compared only within the same thread and role/source.
 for(const thread of personal?.threads||[]){if(!await scan(thread.messages,m=>typeof m?.content==='string'?JSON.stringify([m.role,m.source||'',m.content]):null,'messages'))break;}
 return report;
}
export function repetitionReport(r){return (r.complete?'Analyse terminée':'Analyse partielle')+' : '+r.notes.repetitions+' répétitions exactes parmi '+r.notes.scanned+' notes, '+r.documents.repetitions+' parmi '+r.documents.scanned+' documents et '+r.messages.repetitions+' parmi '+r.messages.scanned+' messages. Aucun contenu supprimé. Un message répété peut être légitime. Ce bilan ne mesure pas la mémoire vive du LLM et ne couvre pas les archives serveur.';}
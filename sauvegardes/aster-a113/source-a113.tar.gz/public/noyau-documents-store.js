import {DOCUMENTS_KEY,documentsState} from '/noyau-documents-core.js?v=A100';
export async function commitDocuments(db,expected,transform){
 let next;
 await new Promise((resolve,reject)=>{
  const tx=db.transaction('settings','readwrite'),store=tx.objectStore('settings');
  tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error||Error('Enregistrement interrompu ; documents précédents conservés.'));
  store.get(DOCUMENTS_KEY).onsuccess=e=>{try{
   const current=documentsState(e.target.result);if(current.revision!==expected)throw Error('Documents modifiés dans un autre onglet ou restaurés. Actualise avant de continuer.');
   next=documentsState(transform(current));next.revision=current.revision+1;if(!Number.isSafeInteger(next.revision))throw Error('Compteur de documents invalide.');store.put(next,DOCUMENTS_KEY);
  }catch(error){tx.abort();reject(error);}};
 });
 const actual=await new Promise((resolve,reject)=>{const tx=db.transaction('settings','readonly');let value;tx.objectStore('settings').get(DOCUMENTS_KEY).onsuccess=e=>value=e.target.result;tx.oncomplete=()=>resolve(value);tx.onerror=tx.onabort=()=>reject(tx.error||Error('Relecture interrompue.'));});
 if(JSON.stringify(actual)!==JSON.stringify(next))throw Error('Enregistrement non confirmé. Relis les documents avant de continuer.');
 return next;
}

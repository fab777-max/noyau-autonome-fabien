// A bounded queue of literal document searches. No inference, execution or network.
import {documentsState,searchDocuments,searchTerms,sourceExcerpt,validateExcerpt,excerptLabel} from '/noyau-documents-core.js?v=A100';
export const RESEARCH_KEY='noyau.research.v1',RESEARCH_DRAFT_KEY='noyau.research.drafts.v1';
export const RESEARCH_LIMITS=Object.freeze({dossiers:6,questions:12,question:200,excerpts:3,sessionMs:30000});
const copy=x=>structuredClone(x),plain=x=>x&&typeof x==='object'&&!Array.isArray(x);
const str=(x,n,empty=false)=>typeof x==='string'&&x.length<=n&&(empty||!!x.trim());
const date=x=>str(x,40)&&Number.isFinite(Date.parse(x));
const fail=()=>{throw Error('Dossier de recherche incompatible. Conserve une sauvegarde avant de continuer.');};
const verdicts=['useful','unclear','irrelevant'];
export function researchDrafts(raw){
 if(raw==null)return {schema:1,creation:{title:'',questions:''},reviews:{}};
 if(!plain(raw)||raw.schema!==1||!plain(raw.creation)||!str(raw.creation.title,120,true)||!str(raw.creation.questions,2412,true)||!plain(raw.reviews)||Object.keys(raw.reviews).length>72)fail();
 for(const [id,r] of Object.entries(raw.reviews))if(!str(id,201)||!plain(r)||!['',...verdicts].includes(r.verdict)||!str(r.note,600,true)||!str(r.baseAt,40,true))fail();
 return copy(raw);
}
export function researchState(raw){
 if(raw==null)return {schema:1,revision:0,dossiers:[]};
 if(!plain(raw)||raw.schema!==1||!Number.isSafeInteger(raw.revision)||raw.revision<0||!Array.isArray(raw.dossiers)||raw.dossiers.length>RESEARCH_LIMITS.dossiers)fail();
 const ids=new Set();
 for(const d of raw.dossiers){
  if(!plain(d)||!str(d.id,100)||ids.has(d.id)||!str(d.title,120)||!date(d.createdAt)||!date(d.updatedAt)||!Array.isArray(d.questions)||!d.questions.length||d.questions.length>12)fail();ids.add(d.id);
  const corpus=documentsState(d.corpus);if(!corpus.documents.length)fail();
  const questions=new Set();let pending=false;
  for(const q of d.questions){
   if(!plain(q)||!str(q.id,100)||questions.has(q.id)||!str(q.text,200)||!searchTerms(q.text).length||!['pending','done'].includes(q.status)||!Array.isArray(q.excerpts)||q.excerpts.length>3)fail();questions.add(q.id);
   if(q.status==='pending'){pending=true;if(q.excerpts.length||q.searchedAt!=null||q.review!=null)fail();}
   else if(pending||!date(q.searchedAt))fail();
   const refs=new Set();
   for(const ref of q.excerpts){
    validateExcerpt(ref);const doc=corpus.documents.find(x=>x.id===ref.documentId);if(!doc)fail();
    const expected=sourceExcerpt(doc,ref.start,ref.end),key=ref.documentId+':'+ref.start+':'+ref.end;
    if(refs.has(key)||Object.keys(expected).some(k=>expected[k]!==ref[k]))fail();refs.add(key);
   }
   if(q.review!=null&&(!plain(q.review)||!verdicts.includes(q.review.verdict)||!str(q.review.note,600,true)||!date(q.review.at)))fail();
  }
 }
 return copy(raw);
}
export function researchProgress(d){return {done:d.questions.filter(q=>q.status==='done').length,total:d.questions.length,reviewed:d.questions.filter(q=>q.review).length,withoutMatches:d.questions.filter(q=>q.status==='done'&&!q.excerpts.length).length};}
export function addResearch(raw,input,corpus,id,at=new Date().toISOString()){
 const state=researchState(raw),docs=documentsState(corpus),title=input.title.trim(),lines=input.questions.split('\n').map(x=>x.trim()).filter(Boolean);
 if(!str(title,120)||!lines.length||lines.length>12||lines.some(q=>!str(q,200)||!searchTerms(q).length))throw Error('Indique un titre et 1 à 12 questions ou groupes de mots, une ligne chacun (200 caractères maximum).');
 if(new Set(lines.map(x=>x.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase())).size!==lines.length)throw Error('Une question est répétée. Retire le doublon avant de continuer.');
 if(!docs.documents.length)throw Error('Enregistre au moins un document ou des notes avant de préparer ce dossier.');
 if(state.dossiers.length>=6)throw Error('Six dossiers conservés. Exporte ceux à garder puis retire-en un explicitement ; rien n’a été effacé.');
 if(state.dossiers.some(d=>d.title===title&&JSON.stringify(d.questions.map(q=>q.text))===JSON.stringify(lines)&&JSON.stringify(d.corpus.documents)===JSON.stringify(docs.documents)))throw Error('Ce dossier existe déjà avec les mêmes documents. Sélectionne-le pour le reprendre ou le relire.');
 state.dossiers.push({id,title,createdAt:at,updatedAt:at,corpus:docs,questions:lines.map((text,i)=>({id:id+'-'+i,text,status:'pending',excerpts:[]}))});return researchState(state);
}
export function prepareNextQuestion(raw,id,at=new Date().toISOString()){
 const state=researchState(raw),d=state.dossiers.find(x=>x.id===id);if(!d)throw Error('Dossier introuvable. Actualise la liste.');
 const q=d.questions.find(x=>x.status==='pending');if(!q)return state;
 q.excerpts=searchDocuments(d.corpus,q.text).slice(0,RESEARCH_LIMITS.excerpts).map(r=>sourceExcerpt(d.corpus.documents.find(x=>x.id===r.documentId),r.start,r.end));
 q.status='done';q.searchedAt=at;d.updatedAt=at;return researchState(state);
}
export function reviewResearch(raw,id,questionId,{verdict,note},at=new Date().toISOString()){
 const state=researchState(raw),d=state.dossiers.find(x=>x.id===id),q=d?.questions.find(x=>x.id===questionId);
 if(!q||q.status!=='done'||!verdicts.includes(verdict)||!str(note,600,true))throw Error('Choisis ton avis après lecture des extraits. Note : 600 caractères maximum.');
 q.review={verdict,note:note.trim(),at};d.updatedAt=at;return researchState(state);
}
export function removeResearch(raw,id){const state=researchState(raw);state.dossiers=state.dossiers.filter(d=>d.id!==id);return state;}
const labels={useful:'Extraits jugés utiles par toi',unclear:'À approfondir selon toi',irrelevant:'Extraits jugés hors sujet par toi'};
export function researchReport(d){
 researchState({schema:1,revision:0,dossiers:[d]});const p=researchProgress(d),out=['ASTER — DOSSIER DE RECHERCHE',d.title,'Créé : '+d.createdAt,'Dernière modification : '+d.updatedAt,p.done+'/'+p.total+' recherches préparées ; '+p.reviewed+' relues.',p.done===p.total?'Toutes les recherches prévues ont été traitées.':'DOSSIER INCOMPLET : des recherches restent en attente.','',
 'Portée : recherche de mots dans une copie des documents enregistrés. Aucun Internet ni LLM utilisé. Les extraits sont des correspondances textuelles, pas des réponses établies. L’absence de correspondance ne prouve pas l’absence d’information. Les avis et notes sont ceux du propriétaire.','',
 'DOCUMENTS UTILISÉS (copie figée à la création)'];
 for(const doc of d.corpus.documents)out.push(doc.title+' | '+doc.id+' | ajouté le '+doc.importedAt);
 for(const [i,q] of d.questions.entries()){
  out.push('','QUESTION '+(i+1)+' — '+q.text,q.status==='pending'?'En attente.':q.excerpts.length?'Passages à vérifier dans leur contexte.':'Aucun passage retrouvé avec ces mots. Essayer des synonymes ou une autre source.');
  for(const [j,e] of q.excerpts.entries())out.push('[Q'+(i+1)+'-S'+(j+1)+'] '+excerptLabel(e),'Document : '+e.documentId+' | caractères '+e.start+' à '+e.end+' (fin exclue)',e.text,'');
  out.push(q.review?labels[q.review.verdict]+' — '+q.review.at:'Avis humain : pas encore enregistré.');if(q.review?.note)out.push('Note du propriétaire : '+q.review.note);
 }
 out.push('','Les documents complets et les points de reprise sont inclus dans la sauvegarde complète du site. Ce fichier texte est un compte rendu, pas une sauvegarde à restaurer.');return out.join('\n');
}
export function researchHandoff(d){
 researchState({schema:1,revision:0,dossiers:[d]});const p=researchProgress(d),questions=[...d.questions].sort((a,b)=>Number(a.review?.verdict==='useful')-Number(b.review?.verdict==='useful')).slice(0,6);
 return 'Approfondis cette recherche et fournis des sources vérifiables : '+d.title+'\nDossier local : '+d.id+'\n'+p.done+'/'+p.total+' recherches locales préparées, '+p.reviewed+' relues.\nQuestions prioritaires (extrait du dossier, '+questions.length+'/'+p.total+') :\n'+questions.map((q,i)=>(i+1)+'. '+q.text).join('\n')+'\nCe résumé est partiel. Aucun document ni extrait local n’est joint à cette demande. Demande le compte rendu exporté si nécessaire. Ne présente pas les correspondances locales comme des faits vérifiés. Distingue les sources et tes propositions.';
}

// Mechanical format checks only. Passing these checks never certifies factual truth.
const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const counts={un:1,une:1,deux:2,trois:3,quatre:4,cinq:5,six:6,sept:7,huit:8,neuf:9,dix:10,one:1,two:2,three:3};
const amount=s=>counts[s]||Number(s);
const number='(?:[1-9]\\d{0,2}|une?|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|one|two|three)';
export function answerConstraints(question){
 const q=norm(question),out={};
 const sentences=q.match(new RegExp('\\b(?:en|exactement|en exactement|reponds avec|ecris|write|in)\\s+('+number+')(?:\\s+seules?)?\\s+(?:phrases?|sentences?)\\b'));
 const sentenceMax=q.match(new RegExp('\\b(?:maximum|max|au plus|pas plus de)\\s+('+number+')\\s+phrases?\\b|\\b('+number+')\\s+phrases?\\s+(?:maximum|max|au plus)\\b'));
 if(sentenceMax){out.sentences=amount(sentenceMax[1]||sentenceMax[2]);out.sentenceMode='max';}
 else if(sentences){out.sentences=amount(sentences[1]);out.sentenceMode='exact';}
 else if(/\bone sentence\b/.test(q)){out.sentences=1;out.sentenceMode='exact';}
 const cap=q.match(new RegExp('\\b(?:maximum|max|au plus|pas plus de)\\s+('+number+')\\s+mots\\b|\\b('+number+')\\s+mots\\s+(?:maximum|max|au plus)\\b'));
 if(cap)out.maxWords=amount(cap[1]||cap[2]);
 return out;
}
export function sentenceCount(answer){
 const text=String(answer).trim().replace(/\b(?:M|Mme|Mlle|Dr|Pr)\./g,x=>x.replace('.','∯')).replace(/(\d)\.(?=\d)/g,'$1∯').replace(/https?:\/\/[^\s]+/g,x=>x.replace(/\.(?=\S)/g,'∯'));
 return text?text.split(/[.!?]+(?:[»”"'])*(?:\s+|$)|\n+/u).filter(x=>x.trim()).length:0;
}
export function reviewAnswer(question,answer){
 const constraints=answerConstraints(question),issues=[],checks=[],observed={sentences:sentenceCount(answer),words:String(answer).trim().split(/\s+/u).filter(Boolean).length};
 if(constraints.sentences){
  const kind=constraints.sentenceMode==='max'?'MAX_SENTENCES':constraints.sentences===1?'ONE_SENTENCE':'SENTENCE_COUNT';checks.push(kind);
  if(!observed.sentences||(constraints.sentenceMode==='max'?observed.sentences>constraints.sentences:observed.sentences!==constraints.sentences))issues.push(kind);
 }
 if(constraints.maxWords){checks.push('MAX_WORDS');if(observed.words>constraints.maxWords)issues.push('MAX_WORDS');}
 return {checks,issues,passed:issues.length===0,checked:checks.length>0,status:checks.length?(issues.length?'FAIL':'PASS'):'NOT_CHECKED',constraints,observed,scope:'FORMAT_ONLY_NOT_FACTUAL_TRUTH'};
}
export function reviewInstruction(review){
 const c=review.constraints||{},sentences=review.issues.some(x=>['ONE_SENTENCE','SENTENCE_COUNT','MAX_SENTENCES'].includes(x)),words=review.issues.includes('MAX_WORDS');
 return 'Corrige la réponse précédente pour la demande initiale. '+(sentences?'Écris '+(c.sentenceMode==='max'?'au maximum ':'exactement ')+(c.sentences||1)+' phrase(s), sans introduction supplémentaire. ':'')+(words?'Écris au maximum '+c.maxWords+' mots. ':'')+(review.issues.includes('DIALOGUE_OUTPUT_ECHO')?'Réponds à la question sans la recopier. ':'')+(review.issues.includes('DIALOGUE_OUTPUT_REPETITIVE')?'Supprime les répétitions. ':'')+(review.issues.includes('DIALOGUE_OUTPUT_IDENTITY')?'Tu es Aster, un assistant local utilisant Qwen. Ne prétends pas être ChatGPT ou Claude, ni être créé par Anthropic ou OpenAI. Réponds sans te présenter. ':'')+(review.issues.includes('DIALOGUE_UNPROVEN_ACTION')?'Présente seulement une explication ou une proposition, sans prétendre avoir exécuté une action. ':'')+'Conserve les noms, dates et faits disponibles. Donne seulement la réponse corrigée.';
}

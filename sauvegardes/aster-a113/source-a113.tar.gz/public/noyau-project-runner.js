import {MODEL,MODEL_MODE} from '/blob-assistant-model.js?v=A83';
import {workerModelURL,workerModelOptions} from '/blob-model-choice.js?v=A100';
import {ENGINE_PROTOCOL} from '/blob-llm-evidence.js?v=A91';
import {PROJECT_PROTOCOL,PROJECT_LIMITS} from '/noyau-project-core.js?v=A100';
// Caller holds the exclusive engine lock and has durably saved this attempt.
export async function runProjectStep(attempt,{signal,onProgress=()=>{},onCheckpoint,onResult}){
 if(document.hidden||signal.aborted)throw Error('Travail mis en pause.');
 let worker,timer,total,queue=Promise.resolve(),finished=false,ready=false,ack=false,firstToken=false,seen=new Set(),memoryIds=new Set(attempt.memoryIds);
 const nonce=crypto.randomUUID();
 try{
  worker=new Worker(workerModelURL(MODEL_MODE),workerModelOptions(MODEL_MODE));
  return await new Promise((resolve,reject)=>{
   const finish=(error,value)=>{if(finished)return;finished=true;clearTimeout(timer);clearTimeout(total);signal.removeEventListener('abort',abort);worker.terminate();error?reject(error):resolve(value);};
   const abort=()=>finish(Error('Travail mis en pause. Les points enregistrés restent disponibles.'));
   const deadline=(ms,label)=>{clearTimeout(timer);timer=setTimeout(()=>finish(Error(label)),ms);};
   signal.addEventListener('abort',abort,{once:true});
   total=setTimeout(()=>finish(Error('Limite de 10 minutes atteinte. Reprise manuelle depuis le dernier point.')),PROJECT_LIMITS.sessionMs);
   worker.onerror=worker.onmessageerror=()=>finish(Error('Moteur interrompu. Aucun redémarrage automatique.'));
   worker.onmessage=({data:p})=>{queue=queue.then(async()=>{
    if(finished||signal.aborted)return;
    if(p.type==='HELLO_ACK'){
     if(ack||p.nonce!==nonce)return;
     if(p.protocol!==ENGINE_PROTOCOL||p.projectProtocol!==PROJECT_PROTOCOL||p.model!==MODEL.id||p.revision!==MODEL.revision)throw Error('Version du moteur incompatible. Ouvre la mise à jour du site.');
     ack=true;onProgress('Lecture des poids déjà présents. Aucun téléchargement de modèle.');deadline(480000,'Chargement trop long. Étape conservée.');worker.postMessage({type:'LOAD',profile:'safe-64',projectWork:true});
    }else if(p.type==='READY'){
     if(!ack||ready||p.model!==MODEL.id||p.revision!==MODEL.revision||p.actual?.n_ctx!==1024||p.actual?.n_threads!==1||p.actual?.n_batch!==64)throw Error('Configuration du moteur non confirmée.');
     ready=true;deadline(PROJECT_LIMITS.generationMs,'Calcul trop long. Reprends cette étape ou utilise le relais à l’agent.');worker.postMessage({type:'PROJECT_STEP',attempt});
    }else if(p.type==='STAGE')onProgress(String(p.label||'Préparation de l’étape').slice(0,200));
    else if(p.type==='TECHNICAL'&&p.event==='FIRST_TOKEN')firstToken=true;
    else if(p.type==='CONTEXT'){
     for(const x of p.retainedSources||[])if(x.source==='OWNER_VALIDATED_MEMORY'&&attempt.passages.some(v=>v.id===x.id))memoryIds.add(x.id);
    }else if(p.type==='CHECKPOINT'){
     if(!ready||!Number.isSafeInteger(p.id)||!p.checkpoint||JSON.stringify(p.checkpoint).length>64000)throw Error('Point de reprise invalide.');
     if(!seen.has(p.id)){await onCheckpoint(p.checkpoint,[...memoryIds]);seen.add(p.id);}
     if(finished||signal.aborted)return;
     deadline(PROJECT_LIMITS.generationMs,'Calcul trop long. Dernier point de reprise conservé.');worker.postMessage({type:'CHECKPOINT_ACK',id:p.id,ok:true,checkpoint:p.checkpoint});
    }else if(p.type==='PROJECT_RESULT'){
     if(!ready||!seen.size||typeof p.answer!=='string'||!p.answer.trim()||p.answer.length>1800||(!firstToken&&!p.reusedFinal))throw Error('Réponse non confirmée par le moteur.');
     const result={output:p.answer,memoryIds:[...memoryIds],reusedFinal:p.reusedFinal===true};
     await onResult(result);if(!finished&&!signal.aborted)finish(null,result);
    }else if(p.type==='ERROR')throw Error(p.message==='DIALOGUE_CONTEXT_TOO_LONG'?'Contexte trop long pour le moteur local. Utilise un résumé plus court ou le relais à l’agent.':p.message==='DIALOGUE_OUTPUT_REJECTED'?'La réponse n’a pas passé les contrôles de forme ou de cohérence. Reprise manuelle ou relais à l’agent.':String(p.message||'Calcul interrompu').slice(0,200));
   }).catch(error=>finish(error));};
   deadline(20000,'Moteur sans réponse.');worker.postMessage({type:'HELLO',nonce});
  });
 }finally{finished=true;clearTimeout(timer);clearTimeout(total);worker?.terminate();await queue;}
}

import {MODEL,cacheReport} from '/blob-assistant-model.js?v=A83';
import {PROJECT_KEY,PROJECT_DRAFT_KEY,projectDrafts,projectState,addProject,nextStep,beginStep,updateAttempt,reviewStep,adjustProject,removeCompletedProject,setProjectSource,projectHandoff} from '/noyau-project-core.js?v=A100';
import {excerptLabel} from '/noyau-documents-core.js?v=A100';
import {commitProject} from '/noyau-project-store.js?v=A100';
import {runProjectStep} from '/noyau-project-runner.js?v=A100';
import {LEARNING_KEY,learningState,recallLessons} from '/noyau-learning.js?v=A91';
const $=id=>document.getElementById(id),memory=window.BlobLocalMemory;
let state=projectState(),selected=null,db=null,busy=false,outsideBusy=false,controller=null,dirty=false;
const node=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
const message=text=>{$('projectState').textContent=text;};
const chosen=()=>state.projects.find(p=>p.id===selected);
const readDrafts=()=>projectDrafts(JSON.parse(localStorage.getItem(PROJECT_DRAFT_KEY)||'null'));
function saveDrafts(data){const text=JSON.stringify(projectDrafts(data));localStorage.setItem(PROJECT_DRAFT_KEY,text);if(localStorage.getItem(PROJECT_DRAFT_KEY)!==text)throw Error('Brouillon non confirmé.');}
function clearReviewDraft(id){try{const data=readDrafts();delete data.reviews[id];saveDrafts(data);}catch{message('Étape enregistrée ; ancien brouillon non effacé.');}}
function controls(){for(const id of ['projectCreate','projectSelect','projectGoal','projectContext','projectSteps','projectRun','projectRefresh','projectReviewText','projectCarry','projectConfirm','projectApprove','projectFeedback','projectReject','projectLesson','projectHandoff','projectContextEdit','projectCarryEdit','projectSaveContext','projectRemove','projectSourceRemove'])$(id).disabled=busy||outsideBusy||!db;$('projectPause').hidden=!controller;}
document.addEventListener('noyau-workspace-state',e=>{outsideBusy=e.detail.busy===true;controls();});
function render(){
 const select=$('projectSelect');select.replaceChildren();for(const p of state.projects){const option=node('option',p.goal.slice(0,75));option.value=p.id;select.append(option);}if(!chosen())selected=state.projects.at(-1)?.id||null;select.value=selected||'';
 const p=chosen();$('projectWork').hidden=!p;$('projectListLabel').hidden=!state.projects.length;
 if(!p){controls();return;}
 $('projectTitle').textContent=p.goal;
 const list=$('projectStepsList');list.replaceChildren();
 for(const s of p.steps){const li=node('li'),labels={pending:'À préparer',running:'Point de reprise conservé',review:'À vérifier',approved:'Validée par toi'};li.append(node('strong',s.instruction),node('p',labels[s.status]));
  if(s.status==='approved')li.append(node('p',s.approvedText));
  if(s.attempts.length){const details=node('details');details.append(node('summary',s.attempts.length+' essai(s) conservé(s)'));for(const a of s.attempts){const text=[new Date(a.at).toLocaleString('fr-FR'),a.model,a.status,a.reason,a.output].filter(Boolean).join('\n');details.append(node('p',text));if(a.source)details.append(node('p','Extrait transmis à cet essai : '+excerptLabel(a.source)+'\n'+a.source.text));}li.append(details);}list.append(li);
 }
 const step=nextStep(p),a=step?.attempts.at(-1);$('projectRun').hidden=!step||step.status==='review';$('projectRun').textContent=step?.status==='running'?'Reprendre cette étape':'Préparer l’étape suivante';
 $('projectSource').hidden=!p.source;$('projectSourceText').textContent=p.source?excerptLabel(p.source)+'\n'+p.source.text:'';$('projectSourceRemove').hidden=!step||step.status==='review';
 $('projectRemove').hidden=!!step;
 let adjustment;try{adjustment=readDrafts().adjustments[p.id];}catch{}
 if(adjustment?.baseContext!==p.context||adjustment?.baseCarry!==p.carry)adjustment=null;
 $('projectAdjust').hidden=!step||step.status==='review';$('projectContextEdit').value=adjustment?.context??p.context;$('projectCarryEdit').value=adjustment?.carry??p.carry;
 let draft;try{draft=readDrafts().reviews[p.id];}catch{}
 if(draft?.attemptId!==a?.id)draft=null;
 $('projectReview').hidden=step?.status!=='review';$('projectReviewText').value=draft?.text??(step?.status==='review'?a.output:'');$('projectCarry').value=draft?.carry??p.carry;$('projectConfirm').checked=false;$('projectLesson').value=draft?.lesson||'';$('projectFeedback').value=draft?.feedback??step?.feedback??'';dirty=false;
 const approved=p.steps.filter(s=>s.status==='approved').length,corrected=p.steps.filter(s=>s.status==='approved'&&s.attempts.at(-1)?.corrected).length;
 $('projectProgress').textContent=approved+'/'+p.steps.length+' étapes validées · '+corrected+' réponse(s) corrigée(s) par toi. '+(step?'Les suivantes attendent ta validation.':'Projet terminé ; aucune répétition automatique.');controls();
}
async function reload(){state=projectState(await memory.setting(db,PROJECT_KEY));render();}
async function edit(transform,options){
 if(busy||outsideBusy||!db)return;busy=true;controls();
 try{await window.NoyauLocalMaintenance.run(async()=>{state=await commitProject(db,state.revision,transform,options);});render();message('Projet sauvegardé et relu.');return true;}
 catch(e){message(e.message+' Tes champs restent affichés ; copie-les avant d’actualiser si nécessaire.');}
 finally{busy=false;controls();}
}
const pause=()=>controller?.abort();
window.NoyauProjectWork={active:()=>!!controller,stop:pause,prepare:text=>{
 if(busy||outsideBusy||!db)throw Error('Le projet n’est pas disponible pendant une autre opération.');
 $('projectNew').open=true;
 if(typeof text!=='string'||text.length>400)throw Error('Ton objectif dépasse 400 caractères. La demande entière reste dans la conversation ; écris ici un objectif plus court.');
 const data=readDrafts();
 if(Object.values(data.creation).some(value=>value.trim())&&data.creation.goal!==text)throw Error('Un projet en préparation est déjà présent. Son brouillon reste intact ; ta nouvelle demande est conservée dans la conversation.');
 data.creation.goal=text;
 if(!data.creation.steps.trim())data.creation.steps='Clarifier le résultat attendu et les informations manquantes.\nPréparer un premier brouillon à partir des faits disponibles.\nRelire le brouillon et lister les corrections ou incertitudes.';
 saveDrafts(data);$('projectGoal').value=data.creation.goal;$('projectContext').value=data.creation.context;$('projectSteps').value=data.creation.steps;
 message('Objectif repris. Relis les trois étapes proposées ou adapte-les, puis enregistre le projet. Aucun calcul lancé.');$('projectGoal').focus();
},attachSource:async source=>{
 if(busy||outsideBusy||!db)return false;
 const p=chosen();if(!p){message('Crée ou sélectionne un projet avant de joindre un extrait.');$('projectPanel').open=true;return false;}
 if(p.source&&!confirm('Remplacer l’extrait joint à « '+p.goal+' » ? Les extraits des anciens essais restent conservés.'))return false;
 const result=await edit(raw=>setProjectSource(raw,p.id,source));if(result)message('Extrait joint et sauvegardé. Il sera transmis lors du prochain lancement manuel.');return !!result;
}};
$('projectSourceRemove').onclick=async()=>{if(chosen())await edit(raw=>setProjectSource(raw,selected,null));};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});window.addEventListener('pagehide',pause);
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
for(const id of ['projectGoal','projectContext','projectSteps','projectReviewText','projectCarry','projectFeedback','projectLesson','projectContextEdit','projectCarryEdit'])$(id).addEventListener('input',()=>{
 dirty=true;try{const data=readDrafts();if(['projectGoal','projectContext','projectSteps'].includes(id))data.creation={goal:$('projectGoal').value,context:$('projectContext').value,steps:$('projectSteps').value};
 else if(['projectContextEdit','projectCarryEdit'].includes(id)){const p=chosen();if(p)data.adjustments[p.id]={context:$('projectContextEdit').value,carry:$('projectCarryEdit').value,baseContext:p.context,baseCarry:p.carry};}
 else{const a=chosen()&&nextStep(chosen())?.attempts.at(-1);if(a)data.reviews[selected]={attemptId:a.id,text:$('projectReviewText').value,carry:$('projectCarry').value,feedback:$('projectFeedback').value,lesson:$('projectLesson').value};}
 saveDrafts(data);
 }catch{message('Brouillon non sauvegardé : copie le texte avant de quitter cette page.');}
});
$('projectPause').onclick=pause;
$('projectCreate').onclick=async()=>{
 if(busy)return;const id=crypto.randomUUID(),input={goal:$('projectGoal').value,context:$('projectContext').value,steps:$('projectSteps').value};
 await edit(raw=>addProject(raw,input,id));
 if(state.projects.some(p=>p.id===id)){selected=id;try{const data=readDrafts();data.creation={goal:'',context:'',steps:''};saveDrafts(data);}catch{}$('projectGoal').value='';$('projectContext').value='';$('projectSteps').value='';$('projectNew').open=false;render();message('Projet enregistré. Lance la première étape quand tu es prêt.');}
};
$('projectSelect').onchange=()=>{if(busy)return;if(dirty&&!confirm('Changer de projet ? Les champs non enregistrés seront remplacés.')){$('projectSelect').value=selected;return;}selected=$('projectSelect').value;render();};
$('projectRefresh').onclick=async()=>{if(busy||!db)return;if(dirty&&!confirm('Actualiser ? Les champs non enregistrés seront remplacés.'))return;try{await reload();message('Projets relus. Aucun calcul lancé.');}catch(e){message(e.message);}};
$('projectRun').onclick=async()=>{
 if(busy||!db||document.hidden)return;
 if(!navigator.locks?.request){message('Le verrou entre onglets est indisponible. Le travail par étapes est bloqué pour éviter deux calculs concurrents.');return;}
 busy=true;controller=new AbortController();const signal=controller.signal,id=selected;let attemptId=null;controls();
 try{await window.NoyauLocalMaintenance.run(async()=>{
  try{
   if(!(await cacheReport()).complete)throw Error('Installe le modèle depuis Discuter. Aucun téléchargement n’a été lancé ici.');signal.throwIfAborted();
   const p=chosen(),s=p&&nextStep(p);if(!s)throw Error('Ce projet est terminé.');
   const learned=learningState(await memory.setting(db,LEARNING_KEY));
   state=await commitProject(db,state.revision,raw=>beginStep(raw,id,{model:MODEL.id,revision:MODEL.revision,attemptId:crypto.randomUUID(),passages:recallLessons(learned,p.goal+' '+s.instruction)}),{signal});
   const attempt=nextStep(chosen()).attempts.at(-1);attemptId=attempt.id;signal.throwIfAborted();render();controls();
   await runProjectStep(attempt,{signal,onProgress:message,
    onCheckpoint:async(checkpoint,memoryIds)=>{state=await commitProject(db,state.revision,raw=>updateAttempt(raw,id,attemptId,{checkpoint,memoryIds}),{signal});},
    onResult:async result=>{state=await commitProject(db,state.revision,raw=>updateAttempt(raw,id,attemptId,{...result,status:'review'}),{signal,usedIds:result.memoryIds});}
   });message('Proposition sauvegardée. Relis-la et valide-la avant de poursuivre.');
  }catch(e){
   const a=chosen()&&nextStep(chosen())?.attempts.at(-1);
   if(attemptId&&a?.id===attemptId&&a.status==='running'){
    try{state=await commitProject(db,state.revision,raw=>updateAttempt(raw,id,attemptId,{status:'paused',reason:String(e.message||e).slice(0,300)}));}
    catch{throw Error('Arrêt du calcul. Le dernier point enregistré reste conservé ; actualise pour confirmer l’état du projet.');}
   }
   throw e;
  }
 });}catch(e){message(signal.aborted?'Étape en pause. Dernier point enregistré conservé. Reprise par le bouton, écran visible.':e.message);}
 finally{controller=null;busy=false;render();controls();document.dispatchEvent(new CustomEvent('noyau-learning-changed'));}
};
$('projectApprove').onclick=async()=>{
 const p=chosen(),s=p&&nextStep(p);if(!s)return;
 const review={approved:true,text:$('projectReviewText').value,carry:$('projectCarry').value,confirmed:$('projectConfirm').checked};
 const answer=$('projectLesson').value.trim(),lesson=answer?{question:p.goal+' — '+s.instruction,answer,id:crypto.randomUUID()}:null;
 if(await edit(raw=>reviewStep(raw,selected,review),{lesson})){clearReviewDraft(selected);render();}document.dispatchEvent(new CustomEvent('noyau-learning-changed'));
};
$('projectReject').onclick=async()=>{const review={approved:false,feedback:$('projectFeedback').value};if(await edit(raw=>reviewStep(raw,selected,review))){clearReviewDraft(selected);render();}};
$('projectSaveContext').onclick=async()=>{const context=$('projectContextEdit').value,carry=$('projectCarryEdit').value;if(await edit(raw=>adjustProject(raw,selected,context,carry))){try{const data=readDrafts();delete data.adjustments[selected];saveDrafts(data);}catch{}render();}};
$('projectRemove').onclick=async()=>{if(busy||!chosen()||nextStep(chosen()))return;if(!confirm('Conserve d’abord une sauvegarde complète dans Fichiers. Effacer ce projet terminé et ses essais de cet appareil ? Les méthodes validées restent conservées.'))return;const id=selected;if(await edit(raw=>removeCompletedProject(raw,id))){try{const data=readDrafts();delete data.reviews[id];delete data.adjustments[id];saveDrafts(data);}catch{}render();}};
$('projectHandoff').onclick=()=>{
 const p=chosen();if(!p||busy)return;
 try{const text=projectHandoff(p),key='noyau-request-draft-v1',old=localStorage.getItem(key);if(old&&old!==text&&!confirm('Remplacer le brouillon non envoyé dans Avec l’agent ?'))return;localStorage.setItem(key,text);if(localStorage.getItem(key)!==text)throw Error();location.assign('/demandes.html');}
 catch{message('Le brouillon n’a pas pu être conservé. Sauvegarde ton travail avant le relais à l’agent.');}
};
(async()=>{try{db=await memory.open();await reload();const draft=readDrafts().creation;$('projectGoal').value=draft.goal;$('projectContext').value=draft.context;$('projectSteps').value=draft.steps;$('projectNew').open=!state.projects.length||!!draft.goal;$('projectPanel').open=!!state.projects.length;message(state.projects.length?'Projets retrouvés. Reprise uniquement sur demande.':'Enregistre un objectif et des étapes courtes pour commencer.');}catch(e){db=null;message(e.message);}controls();})();

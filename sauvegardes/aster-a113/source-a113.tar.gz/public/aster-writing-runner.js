import {MODEL,MODEL_MODE,cacheReport} from '/blob-assistant-model.js?v=A83';
import {workerModelOptions} from '/blob-model-choice.js?v=A100';
import {reserveEngine} from '/blob-local-pilot.js?v=A91';
import {ENGINE_PROTOCOL} from '/blob-llm-evidence.js?v=A91';
import {WRITING_PROTOCOL,WRITING_STEPS,WRITING_LIMITS,validateWriting,startWriting,beginWritingStep,writingPrompt,finishWritingStep,interruptWriting} from '/aster-writing-core.js?v=A106';

// One resident worker, three bounded requests, a durable commit between requests.
// No downloader, network inference, retry loop, background work or learned claims.
export async function runLocalWriting(initial,{save,onProgress=()=>{},signal}={}){
  let run=structuredClone(initial);validateWriting(run.writing);
  if(run.writing.steps.every(s=>s.status==='done'))return run;
  if(run.writing.model!==MODEL.id||run.writing.revision!==MODEL.revision)throw Error('Le modèle de cette rédaction a changé. Résultats antérieurs conservés.');
  const controller=new AbortController(),abort=()=>controller.abort(Error('Rédaction en pause. Résultats enregistrés conservés.'));
  const hidden=()=>{if(document.hidden)abort();};
  signal?.addEventListener('abort',abort,{once:true});document.addEventListener('visibilitychange',hidden);globalThis.addEventListener?.('pagehide',abort);
  const check=()=>{if(signal?.aborted||document.hidden)abort();controller.signal.throwIfAborted();};
  const budget=setTimeout(()=>controller.abort(Error('Limite de dix minutes atteinte. Reprise manuelle des étapes restantes.')),WRITING_LIMITS.sessionMs);
  let worker,release,started=false,waiting=null,storageFailed=false;
  const persist=async value=>{try{await save(structuredClone(value));}catch(e){storageFailed=true;throw e;}};
  function call(message,expected,ms){
    check();if(waiting)throw Error('Un calcul est déjà en cours.');
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>done(Error('Temps de calcul dépassé. Aucun nouvel essai automatique.')),ms);
      const stopped=()=>done(controller.signal.reason||Error('Rédaction interrompue.'));
      function done(error,value){if(waiting?.done!==done)return;clearTimeout(timer);controller.signal.removeEventListener('abort',stopped);waiting=null;error?reject(error):resolve(value);}
      waiting={expected,requestId:message.requestId,done};controller.signal.addEventListener('abort',stopped,{once:true});
      try{worker.postMessage(message);}catch(e){done(e);}
    });
  }
  try{
    check();onProgress('Vérification du modèle déjà installé…');
    if(!(await cacheReport()).complete)throw Error('Modèle absent ou incomplet. Installe-le une fois depuis « Mémoire et réglages avancés ». Aucun téléchargement n’a été lancé.');
    check();
    if(!globalThis.navigator?.locks?.request)throw Error('Le navigateur ne permet pas de réserver le modèle entre onglets. Les textes existants restent utilisables.');
    release=await reserveEngine();if(!release)throw Error('Un autre onglet utilise le modèle. Mets-le en pause puis reprends ici.');check();
    // Validate every full prompt before loading weights. Nothing is silently cut.
    for(let i=0;i<3;i++)if(run.writing.steps[i].status!=='done')writingPrompt(run.writing,i);
    run=startWriting(run);await persist(run);started=true;check();
    worker=new Worker('/blob-assistant-worker.js?v=A113&llm='+MODEL_MODE,workerModelOptions(MODEL_MODE));
    worker.onerror=worker.onmessageerror=()=>waiting?.done(Error('Moteur interrompu. Les étapes enregistrées sont conservées.'));
    worker.onmessage=({data:p})=>{
      if(!p||!waiting)return;
      if(p.type==='STAGE'){onProgress(String(p.label||'Calcul local').slice(0,160));return;}
      if(p.type==='ERROR'){waiting.done(Error(p.message==='DIALOGUE_CONTEXT_TOO_LONG'?'Les faits complets ne tiennent pas dans le contexte du modèle. Raccourcis-les ; aucune information n’a été coupée.':String(p.message||'Calcul interrompu').slice(0,250)));return;}
      if(p.type!==waiting.expected||waiting.requestId&&p.requestId!==waiting.requestId)return;
      waiting.done(null,p);
    };
    const nonce=crypto.randomUUID();
    const hello=await call({type:'HELLO',nonce},'HELLO_ACK',20000);
    if(hello.nonce!==nonce||hello.protocol!==ENGINE_PROTOCOL||hello.writingProtocol!==WRITING_PROTOCOL||hello.model!==MODEL.id||hello.revision!==MODEL.revision)throw Error('Version du moteur incompatible. Ouvre la mise à jour du site.');
    onProgress('Chargement unique des poids depuis cet appareil…');
    const ready=await call({type:'LOAD',profile:'safe-64',projectWork:true},'READY',480000);
    if(ready.model!==MODEL.id||ready.revision!==MODEL.revision||ready.actual?.n_ctx!==1024||ready.actual?.n_batch!==64||ready.actual?.n_threads!==1||ready.actual?.sliceMs!==25||ready.actual?.pauseMs!==50)throw Error('Configuration du modèle non confirmée.');
    for(let i=0;i<3;i++){
      if(run.writing.steps[i].status==='done')continue;
      check();run=beginWritingStep(run,i);await persist(run);check();
      const step=WRITING_STEPS[i];onProgress((i+1)+'/3 · '+step.label+' en cours…');
      const result=await call({type:'STUDIO_COMPOSE',requestId:crypto.randomUUID(),prompt:writingPrompt(run.writing,i),stepId:step.id},'STUDIO_COMPOSED',WRITING_LIMITS.stepMs);
      check();run=finishWritingStep(run,i,{text:result.answer,outputTokens:result.outputTokens,wallMs:result.elapsedMs});
      await persist(run);onProgress((i+1)+'/3 · '+step.label+' enregistrée.');
    }
    return run;
  }catch(e){
    if(started&&!storageFailed){run=interruptWriting(run,e.message);try{await persist(run);}catch{throw Error('Enregistrement non confirmé. Dernier point enregistré conservé ; récupère le projet avant de recharger.');}}
    throw e;
  }finally{
    clearTimeout(budget);worker?.terminate();release?.();signal?.removeEventListener('abort',abort);document.removeEventListener('visibilitychange',hidden);globalThis.removeEventListener?.('pagehide',abort);
  }
}

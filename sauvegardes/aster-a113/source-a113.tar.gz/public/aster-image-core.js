// Intent routing and timing only: this module never draws or claims an AI result.
export const IMAGE_MODEL='gpt-image-2.5-sunburst';
export const IMAGE_SETTINGS=Object.freeze({model:IMAGE_MODEL,size:'1024x1024',quality:'low',output_format:'png',n:1});
const normal=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
export function imageIntent(text){
 const t=normal(text).replace(/^(?:peux[- ]tu|tu peux|je veux|je voudrais)\s+(?:me\s+)?/,'');
 if(/^(?:mes images|reprends? (?:mes|les) images|voir mes images)[.!\s]*$/.test(t))return{kind:'list'};
 if(/^(?:cree|creer|genere|generer|dessine|dessiner)\s+(?:(?:moi|une?|des|l['’])\s*)?(?:image|illustration|dessin|visuel|logo)\b/.test(t))return{kind:'prepare',mode:'generate',prompt:text.trim()};
 if(/^(?:retouche|transforme|modifie|remplace|change|supprime|enleve|retire|ajoute|efface|floute|detoure|eclaircis|ameliore|recadre|mets)\b/.test(t)&&/\b(?:photo|image|fond|arriere.plan|decor|objet|visage)\b/.test(t))return{kind:'prepare',mode:'edit',prompt:text.trim(),index:/\bphoto\s+(\d+)\b/.test(t)?Number(t.match(/\bphoto\s+(\d+)\b/)[1])-1:null};
 return null;
}
export function imageDraft(raw){
 if(raw==null)return null;
 if(!raw||raw.schema!==1||typeof raw.key!=='string'||!/^[\da-f-]{36}$/i.test(raw.key)||!['generate','edit'].includes(raw.mode)||typeof raw.prompt!=='string'||!raw.prompt.trim()||raw.prompt.length>1800||typeof raw.projectId!=='string'||raw.projectId.length>80||!(raw.photoId===null||typeof raw.photoId==='string'&&raw.photoId.length<=80)||typeof raw.attempted!=='boolean'||!(raw.sourceHash===null||typeof raw.sourceHash==='string'&&/^[a-f0-9]{64}$/.test(raw.sourceHash)))throw Error('Demande d’image incompatible. Conserve ta sauvegarde.');
 if(raw.mode==='edit'&&(!raw.photoId||!raw.sourceHash))throw Error('Source de retouche manquante.');
 return structuredClone(raw);
}
export function imageEstimate(rows,mode){
 const times=rows.filter(r=>r.status==='ready'&&r.mode===mode&&r.model===IMAGE_MODEL&&Number.isFinite(r.elapsed_ms)&&r.elapsed_ms>0).slice(0,20).map(r=>r.elapsed_ms).sort((a,b)=>a-b);
 if(times.length<3)return null;
 return{samples:times.length,lowSeconds:Math.max(1,Math.floor(times[Math.floor((times.length-1)*.1)]/1000)),highSeconds:Math.ceil(times[Math.ceil((times.length-1)*.9)]/1000)};
}
export async function imageHash(value){const bytes=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');}

import {STUDY_CASES,STUDY_SUITE,FAMILIES,FAMILY_NAMES,studyCase,studyVerdict,studyMessages} from '/aster-study-cases.js?v=A106';
import {learningState,recallLessons} from '/noyau-learning.js?v=A91';
export const STUDY_KEY='aster.study.v1';
export const STUDY_LIMITS=Object.freeze({sessions:20,bytes:2097152,sessionBytes:131072,items:12,calls:24,starts:6,stepMs:90000,loadMs:480000});
const copy=x=>structuredClone(x),bytes=x=>new TextEncoder().encode(JSON.stringify(x)).length;
const str=(v,max)=>typeof v==='string'&&v.length<=max, num=(v,max)=>Number.isFinite(v)&&v>=0&&v<=max;
const integer=(v,max)=>Number.isSafeInteger(v)&&v>=0&&v<=max, date=v=>str(v,40)&&Number.isFinite(Date.parse(v));
export function studyCommand(text){
 const t=text.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const m=t.match(/^(?:etudie|etudier|entraine[- ]?toi|mode etudiant)(?:\s+(?:pendant|environ))?\s+(\d{1,3})\s*(?:minutes?|min)(?:\s+(.+))?[.!]?$/);
 if(m&&m[2]&&!/image|photo|retouche|visuel|client|presentation|redaction|texte/.test(m[2]))return null; // An unknown subject stays a conversation, never a mislabeled client curriculum.
 if(m){const minutes=Number(m[1]);if(minutes<1||minutes>30)throw Error('Choisis entre 1 et 30 minutes. Une séance s’arrête plus tôt si ses exercices sont terminés.');return{kind:'start',minutes,goal:text.trim(),focus:/image|photo|retouche|visuel/.test(m[2]||'')?'images':'clients'};}
 if(/^(?:reprends?|continue|continuer)(?:\s+(?:l['’]?)?(?:etude|apprentissage|seance))[.!\s]*$/.test(t))return{kind:'resume'};
 if(/^(?:bilan|termine|arrete|stop)(?:\s+(?:l['’]?)?(?:etude|apprentissage|seance))[.!\s]*$/.test(t))return{kind:'finish'};
 return null;
}
export function validateStudy(s){
 const fail=()=>{throw Error('Séance d’étude incompatible. Conserve sa sauvegarde.');};
 if(!s||s.schema!==1||s.suite!==STUDY_SUITE||!str(s.id,80)||!s.id||!date(s.at)||!date(s.updatedAt)||!str(s.goal,1800)||!['clients','images'].includes(s.focus)||!['study','evaluation'].includes(s.kind)||!str(s.model,200)||!s.model||!str(s.modelRevision,100)||!s.modelRevision||!integer(s.minutes,30)||s.minutes<1||!num(s.activeMs,s.minutes*60000)||!integer(s.starts,STUDY_LIMITS.starts)||!integer(s.calls,STUDY_LIMITS.calls)||!['ready','running','paused','waiting','review','graded'].includes(s.status)||!str(s.reason,300)||!Array.isArray(s.items)||s.items.length>12||!s.items.length||!Array.isArray(s.questions)||s.questions.length>2||!Array.isArray(s.errors)||s.errors.length>12||!Array.isArray(s.retained)||s.retained.length>6)fail();
 learningState(s.memory);const ids=new Set();let attempts=0;
 for(const r of s.items){
  const c=studyCase(r.caseId);
  if(!r||!str(r.id,100)||ids.has(r.id)||!['study','without','with'].includes(r.phase)||(s.kind==='study')!==(c.split==='study')||(s.kind==='study')!==(r.phase==='study')||!['pending','running','done','skipped'].includes(r.status)||!Array.isArray(r.attempts)||r.attempts.length>(r.phase==='study'?2:1))fail();
  ids.add(r.id);attempts+=r.attempts.length;
  for(const a of r.attempts){if(!a||!['running','answer','interrupted'].includes(a.status)||!str(a.text,800)||!integer(a.tokens,64)||!num(a.wallMs,STUDY_LIMITS.stepMs+5000)||!date(a.at)||typeof a.correct!=='boolean'||!Array.isArray(a.methodIds)||a.methodIds.length>2||a.methodIds.some(id=>!s.memory.lessons.some(m=>m.id===id)))fail();if(a.status==='answer'&&a.correct!==studyVerdict(r.caseId,a.text,a.tokens))fail();if(a.status!=='answer'&&(a.text||a.correct||a.tokens))fail();}
  if(r.status==='done'&&r.attempts.at(-1)?.status!=='answer'||r.status==='running'&&r.attempts.at(-1)?.status!=='running')fail();
 }
 if(s.calls!==attempts)fail();
 for(const q of s.questions)if(!q||!ids.has(q.rowId)||!str(q.text,400)||!['pending','answered'].includes(q.status)||!str(q.answer,800))fail();
 for(const e of s.errors)if(!e||!date(e.at)||!str(e.reason,300))fail();
 for(const m of s.retained)if(!m||!FAMILIES.includes(m.family)||!str(m.id,100)||!date(m.at))fail();
 if(s.reservation!==null&&(!s.reservation||!['load','case'].includes(s.reservation.kind)||!num(s.reservation.ms,s.minutes*60000-s.activeMs)||s.reservation.kind==='case'&&!ids.has(s.reservation.rowId)))fail();
 if(s.grade!==null&&(!s.grade||!integer(s.grade.score,5)||s.grade.score<1||!str(s.grade.comment,800)||!date(s.grade.at)))fail();
 if(s.reviewDraft!==undefined&&(!s.reviewDraft||!['','1','2','3','4','5'].includes(s.reviewDraft.score)||!str(s.reviewDraft.comment,800)))fail();
 if(s.methodDrafts!==undefined&&(!Array.isArray(s.methodDrafts)||s.methodDrafts.length>6||new Set(s.methodDrafts.map(m=>m.family)).size!==s.methodDrafts.length||s.methodDrafts.some(m=>!m||!FAMILIES.includes(m.family)||!str(m.text,400))))fail();
 if(s.status==='graded'&&!s.grade||s.status==='waiting'&&!s.questions.some(q=>q.status==='pending'))fail();
 if(bytes(s)>STUDY_LIMITS.sessionBytes)fail();return copy(s);
}
export function studyState(raw){
 if(raw==null)return{schema:1,revision:0,sessions:[]};
 if(raw.schema!==1||!integer(raw.revision,Number.MAX_SAFE_INTEGER)||!Array.isArray(raw.sessions)||raw.sessions.length>STUDY_LIMITS.sessions||bytes(raw)>STUDY_LIMITS.bytes)throw Error('Mémoire d’étude pleine ou incompatible. Sauvegarde-la avant d’ajouter une séance.');
 const ids=new Set();for(const s of raw.sessions){validateStudy(s);if(ids.has(s.id))throw Error('Séance en double.');ids.add(s.id);}return copy(raw);
}
export function newStudy(raw,command,model,memory,id,at=new Date().toISOString()){
 const state=studyState(raw),mem=learningState(memory);
 if(state.sessions.length>=STUDY_LIMITS.sessions)throw Error('20 séances conservées. Exporte-les avant un retrait explicite. Rien n’a été effacé.');
 if(state.sessions.some(s=>!['review','graded'].includes(s.status)))throw Error('Reprends ou termine d’abord la séance précédente.');
 const seen=new Set(state.sessions.flatMap(s=>s.items.filter(r=>r.attempts.length).map(r=>r.caseId)));
 const failures=Object.fromEntries(FAMILIES.map(f=>[f,0]));
 for(const s of state.sessions)for(const r of s.items)if(r.attempts[0]?.status==='answer'&&!r.attempts[0].correct)failures[studyCase(r.caseId).family]++;
 const order=[...FAMILIES].sort((a,b)=>((command.focus==='images'&&b==='tools'?100:0)+failures[b])-((command.focus==='images'&&a==='tools'?100:0)+failures[a]));
 const candidates=STUDY_CASES.filter(c=>!seen.has(c.id)), selected=[];
 // Unseen comparison comes first when a retained method can actually be tested.
 for(const f of order){const c=candidates.find(c=>c.split==='evaluation'&&c.family===f);if(c&&recallLessons(mem,'demandes client présentation textes '+FAMILY_NAMES[c.family]).length)selected.push(c);}
 const kind=selected.length?'evaluation':'study';
 if(kind==='study')for(let round=0;round<6&&selected.length<12;round++)for(const f of order){const c=candidates.filter(c=>c.split==='study'&&c.family===f)[round];if(c&&selected.length<12)selected.push(c);}
 if(!selected.length)throw Error('Tous les exercices disponibles ont déjà été étudiés. Aucun calcul répétitif lancé : il faut ajouter de nouveaux cas utiles.');
 const items=selected.slice(0,kind==='evaluation'?6:12).flatMap(c=>(kind==='evaluation'?['without','with']:['study']).map(phase=>({id:c.id+'-'+phase,caseId:c.id,phase,status:'pending',attempts:[]})));
 return validateStudy({schema:1,suite:STUDY_SUITE,id,at,updatedAt:at,goal:command.goal,focus:command.focus,kind,model:model.id,modelRevision:model.revision,minutes:command.minutes,activeMs:0,starts:0,calls:0,status:'ready',reason:'',memory:mem,items,questions:[],errors:[],retained:[],reservation:null,grade:null});
}
export function recoverStudy(raw){const s=validateStudy(raw);if(s.reservation){s.activeMs=Math.min(s.minutes*60000,s.activeMs+s.reservation.ms);s.reservation=null;for(const r of s.items)if(r.status==='running'){r.attempts.at(-1).status='interrupted';r.status=r.attempts.length<(r.phase==='study'?2:1)?'pending':'skipped';}s.reason='Reprise après interruption : budget réservé compté par prudence.';}if(s.status==='running')s.status='paused';return validateStudy(s);}
export function nextStudyItem(s){return s.items.find(r=>r.status==='pending'&&r.attempts.length<(r.phase==='study'?2:1))||null;}
export function itemMethods(s,r){return r.phase==='without'?[]:recallLessons(s.memory,'demandes client présentation textes '+studyCase(r.caseId).title);}
export function studyPacket(s,r){return{caseId:r.caseId,methods:itemMethods(s,r),correction:r.phase==='study'&&r.attempts.some(a=>a.status==='answer'&&!a.correct)};}
export function beginStudyItem(raw,rowId,ms,at=new Date().toISOString()){
 const s=validateStudy(raw),r=s.items.find(r=>r.id===rowId);
 if(s.status!=='running'||s.reservation||!r||r!==nextStudyItem(s)||s.calls>=24||ms<=0||ms>s.minutes*60000-s.activeMs)throw Error('Budget ou étape d’étude indisponible.');
 studyMessages(studyPacket(s,r));r.status='running';r.attempts.push({status:'running',text:'',tokens:0,wallMs:0,at,correct:false,methodIds:itemMethods(s,r).map(m=>m.id)});s.calls++;s.reservation={kind:'case',rowId,ms};return validateStudy(s);
}
export function finishStudyItem(raw,result){
 const s=validateStudy(raw),r=s.items.find(r=>r.id===s.reservation?.rowId),a=r?.attempts.at(-1);
 if(!a||a.status!=='running'||!str(result.answer,800)||!integer(result.outputTokens,64)||!num(result.elapsedMs,95000))throw Error('Réponse d’exercice invalide.');
 Object.assign(a,{status:'answer',text:result.answer,tokens:result.outputTokens,wallMs:result.elapsedMs,correct:studyVerdict(r.caseId,result.answer,result.outputTokens)});s.reservation=null;
 r.status=!a.correct&&r.phase==='study'&&r.attempts.length<2?'pending':'done';
 if(r.phase==='study'&&r.status==='done'&&!a.correct&&s.questions.length<2){s.questions.push({rowId:r.id,text:'Je n’ai pas appliqué la correction de « '+studyCase(r.caseId).title+' ». Veux-tu que je passe aux autres exercices, ou que je termine le bilan ?',status:'pending',answer:''});s.status='waiting';}
 return validateStudy(s);
}
export function studyCandidates(raw){const s=validateStudy(raw),fs=new Set(s.items.filter(r=>r.phase==='study'&&r.attempts.some(a=>a.status==='answer'&&!a.correct)).map(r=>studyCase(r.caseId).family));return[...fs].map(f=>({family:f,question:'demandes client présentation textes '+FAMILY_NAMES[f],answer:studyCase(s.items.find(r=>studyCase(r.caseId).family===f).caseId).rule,sourceCaseIds:s.items.filter(r=>studyCase(r.caseId).family===f).map(r=>r.caseId)}));}
export function studySummary(raw){
 const s=validateStudy(raw),study=s.items.filter(r=>r.phase==='study'),first=study.map(r=>r.attempts[0]).filter(a=>a?.status==='answer'),guided=study.filter(r=>r.attempts.length>1&&r.attempts[0].status==='answer').map(r=>r.attempts[1]).filter(a=>a.status==='answer');
 const pairs=[];for(const r of s.items.filter(r=>r.phase==='without')){const other=s.items.find(x=>x.caseId===r.caseId&&x.phase==='with');if(r.status==='done'&&other?.status==='done')pairs.push({without:r.attempts[0].correct,with:other.attempts[0].correct});}
 return{kind:s.kind,attempted:s.items.filter(r=>r.attempts.length).length,total:s.items.length,first:first.length,correct:first.filter(a=>a.correct).length,guided:guided.length,guidedCorrect:guided.filter(a=>a.correct).length,pairs:pairs.length,without:pairs.filter(p=>p.without).length,with:pairs.filter(p=>p.with).length,regressions:pairs.filter(p=>p.without&&!p.with).length,activeSeconds:Math.round(s.activeMs/1000),methods:studyCandidates(s).length,weightsTrained:false};
}
export function studyReport(raw){const s=validateStudy(raw),r=studySummary(s);return ['ASTER — BILAN D’ÉTUDE',s.goal,'Date : '+s.at,'État : '+s.status+' — '+s.reason,'Modèle : '+s.model+' / '+s.modelRevision,'Temps actif : '+r.activeSeconds+' s / '+s.minutes+' min maximum','Exercices traités : '+r.attempted+'/'+r.total,s.kind==='study'?'Premiers essais exacts : '+r.correct+'/'+r.first+' ; essais guidés exacts : '+r.guidedCorrect+'/'+r.guided:'Comparaisons complètes : '+r.pairs+' ; sans méthode : '+r.without+' ; avec méthode : '+r.with+' ; régressions : '+r.regressions,'Exercices synthétiques. Un second essai guidé n’est pas un apprentissage prouvé. Les comparaisons restent indicatives. Aucun poids entraîné.',...s.items.flatMap(i=>['\n'+studyCase(i.caseId).title+' — '+i.phase,studyCase(i.caseId).task,...i.attempts.map((a,n)=>'Essai '+(n+1)+' ['+a.status+'] : '+a.text+' — '+(a.correct?'exact':'non validé')+' — méthodes : '+a.methodIds.join(', ')),i.attempts.some(a=>a.status==='answer')?'Corrigé : '+studyCase(i.caseId).expected:'Non traité.']),...s.questions.map(q=>'Question : '+q.text+'\nRéponse : '+q.answer),s.grade?'Note de Fabien : '+s.grade.score+'/5\n'+s.grade.comment:'Pas encore noté.'].join('\n');}

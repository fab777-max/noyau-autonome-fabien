import {PROJECT_KEY,projectState} from '/noyau-project-core.js?v=A100';
import {LEARNING_KEY,learningState,retainLesson,recordContextUse} from '/noyau-learning.js?v=A91';
// Compare revisions inside the same transaction as the write. Also used during recovery.
export async function commitProject(db,expected,transform,{lesson=null,usedIds=null,signal=null}={}){
 let next,learned;
 await new Promise((resolve,reject)=>{
  const tx=db.transaction('settings','readwrite'),store=tx.objectStore('settings');let raw,rawLearning,pending=2;
  tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error||Error('Enregistrement interrompu ; état précédent conservé.'));
  const ready=()=>{if(--pending)return;try{
   signal?.throwIfAborted();const current=projectState(raw);
   if(current.revision!==expected)throw Error('Projet modifié dans un autre onglet ou restauré. Actualise avant de continuer.');
   next=projectState(transform(current));next.revision=current.revision+1;
   if(!Number.isSafeInteger(next.revision))throw Error('Compteur de projet invalide.');
   store.put(next,PROJECT_KEY);
   if(lesson||usedIds){learned=learningState(rawLearning);if(lesson)learned=retainLesson(learned,lesson.question,lesson.answer,lesson.id);if(usedIds)learned=recordContextUse(learned,usedIds);store.put(learned,LEARNING_KEY);}
  }catch(e){tx.abort();reject(e);}};
  store.get(PROJECT_KEY).onsuccess=e=>{raw=e.target.result;ready();};
  store.get(LEARNING_KEY).onsuccess=e=>{rawLearning=e.target.result;ready();};
 });
 const actual=await new Promise((resolve,reject)=>{const tx=db.transaction('settings','readonly'),store=tx.objectStore('settings'),result={};store.get(PROJECT_KEY).onsuccess=e=>{result.project=e.target.result;};store.get(LEARNING_KEY).onsuccess=e=>{result.learning=e.target.result;};tx.oncomplete=()=>resolve(result);tx.onerror=tx.onabort=()=>reject(tx.error||Error('Relecture interrompue.'));});
 if(JSON.stringify(actual.project)!==JSON.stringify(next)||(learned&&JSON.stringify(actual.learning)!==JSON.stringify(learned)))throw Error('Enregistrement non confirmé à la relecture. Actualise avant toute reprise.');
 return next;
}

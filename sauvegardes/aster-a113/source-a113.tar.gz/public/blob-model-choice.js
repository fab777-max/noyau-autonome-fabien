export const MODEL_CHOICE_KEY='noyau.llm.model-choice.v1';
export function modelChoice(url,saved,workerName){
 if(workerName==='noyau-model:standard')return 'standard';
 if(workerName==='noyau-model:compact')return 'compact';
 const explicit=new URL(url,'https://noyau.invalid').searchParams.get('llm');
 return (explicit==='compact'||explicit==='standard')?explicit:saved==='standard'?'standard':'compact';
}
export function workerModelURL(choice){return '/blob-assistant-worker.js?v=A113&llm='+(choice==='compact'?'compact':'standard');}
export function workerModelOptions(choice){return {type:'module',name:'noyau-model:'+(choice==='compact'?'compact':'standard')};}

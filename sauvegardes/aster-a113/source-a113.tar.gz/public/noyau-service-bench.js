import {SERVICE_SUITE,SERVICE_CASES,serviceVerdict,serviceSummary} from '/noyau-service-cases.js?v=A92';
import {ENGINE_PROTOCOL} from '/blob-llm-evidence.js?v=A91';
import {profileOK,copyActual} from '/blob-pilot-plan.js?v=A83';
export const SERVICE_KEY='noyau-service-bench-v1';
const clone=x=>JSON.parse(JSON.stringify(x));
const iso=n=>new Date(n).toISOString();
export function createServiceBench({model,revision,read,write,reserve,makeWorker,canRun,render,now=()=>Date.now(),environment=()=>({}),setTimer=setTimeout,clearTimer=clearTimeout}){
 let state={schema:SERVICE_SUITE,model,revision,current:null,history:[]},running=false,ending=false,campaignOwned=false,worker=null,unlock=null,epoch=0,phase='IDLE',notice='Aucune mesure métier. Les 12 cas sont fictifs.',saveQueue=Promise.resolve(),storageFailure=false,timers=[],firstTokenAt=null,context=null;
 let confirmed=clone(state);
 const view=()=>render({active:running,notice,state:clone(confirmed),summary:serviceSummary(confirmed.current),storageFailure});
 const valid=s=>{if(!s)return {schema:SERVICE_SUITE,model,revision,current:null,history:[]};if(s.schema!==SERVICE_SUITE||s.model!==model||s.revision!==revision||!Array.isArray(s.history)||s.history.length>8||s.current&&(!Array.isArray(s.current.receipts)||s.current.receipts.length>SERVICE_CASES.length))throw Error('Bilan local incompatible ; exporte la sauvegarde.');return clone(s);};
 const persist=()=>{const snapshot=clone(state);saveQueue=saveQueue.then(async()=>{await write(snapshot);confirmed=clone(snapshot);});return saveQueue;};
 const free=()=>{for(const t of timers)clearTimer(t);timers=[];worker?.terminate();worker=null;unlock?.();unlock=null;};
 const presentError=e=>String(e?.message||e).slice(0,180);
 async function end(reason,message){
  if(!running||ending)return;ending=true;epoch++;worker?.terminate();worker=null;for(const t of timers)clearTimer(t);timers=[];
  try{
   await saveQueue;
   if(campaignOwned&&state.current){const c=state.current;if(c.inflight)c.receipts.push({caseId:c.inflight.caseId,kind:'INTERRUPTED',reason,at:iso(now()),elapsedMs:now()-c.inflight.startedAt});c.inflight=null;c.status=reason;c.finishedAt=iso(now());await persist();}
   notice=message;
  }catch(e){storageFailure=true;state=clone(confirmed);notice='Sauvegarde du bilan non confirmée : '+presentError(e)+'. Aucun autre calcul lancé.';}
  finally{free();running=false;ending=false;phase='IDLE';view();}
 }
 async function init(){try{state=valid(await read());confirmed=clone(state);notice=state.current?(state.current.status==='RUNNING'?'La mesure précédente a été interrompue. Son dernier résultat n’est pas confirmé. Une nouvelle mesure doit être lancée explicitement.':'Bilan conservé. Consulte les réponses avant de lancer une nouvelle mesure.'):'Aucune mesure métier. Les 12 cas sont fictifs.';}catch(e){notice=presentError(e);storageFailure=true;}view();}
 async function start(fresh=false){
  if(running||!canRun())return false;running=true;ending=false;campaignOwned=false;storageFailure=false;saveQueue=Promise.resolve();const token=++epoch;phase='RESERVE';view();
  const current=()=>running&&!ending&&epoch===token;
  try{
   const release=await reserve();if(!current()){release?.();return false;}if(!release)throw Error('Un autre onglet utilise le modèle.');unlock=release;
   const saved=valid(await read());if(!current())return false;state=saved;confirmed=clone(state);
   if(state.current){
    if(!fresh)throw Error('Ce bilan existe déjà. Utilise Nouvelle mesure pour archiver et recommencer volontairement.');
    if(state.history.length>=8)throw Error('Neuf mesures sont conservées. Exporte le bilan ; aucun historique ne sera effacé automatiquement.');
    const prior=clone(state.current);if(prior.status==='RUNNING'){prior.status='INTERRUPTED';prior.unconfirmedInflight=prior.inflight;prior.inflight=null;}state.history.push(prior);
   }
   state.current={id:iso(now()),startedAt:iso(now()),status:'RUNNING',profile:'safe-64',model,revision,environment:environment(),loadMs:null,actual:null,inflight:null,receipts:[],limits:{wallMs:300000,caseMs:90000,maxOutputTokens:64},noAutomaticDownload:true};campaignOwned=true;
   await persist();if(!current())return false;
   timers.push(setTimer(()=>end('TIME_LIMIT','Limite de 5 minutes atteinte. Les résultats terminés sont conservés ; aucune reprise automatique.'),300000));
   worker=makeWorker();const own=worker,nonce=String(now())+':'+token;let acknowledged=false,ready=false,caseTimer=null,helloTimer=null;
   const next=async()=>{
    if(!current())return;const c=state.current,test=SERVICE_CASES[c.receipts.length];
    if(!test){await end('COMPLETE','Mesure terminée. Compare chaque réponse : ces cas fictifs ne certifient pas un service prêt à vendre.');return;}
    phase='SAVING';c.inflight={caseId:test.id,startedAt:now()};await persist();if(!current())return;
    firstTokenAt=null;context=null;phase='EVALUATE';notice='Cas '+(c.receipts.length+1)+' / '+SERVICE_CASES.length+' · '+test.title;view();
    caseTimer=setTimer(()=>end('TECHNICAL_ERROR','Réponse trop longue : mesure arrêtée, sans nouvel essai automatique.'),90000);timers.push(caseTimer);
    own.postMessage({type:'EVALUATE',caseId:test.id});
   };
   own.onerror=own.onmessageerror=()=>{if(current())return end('TECHNICAL_ERROR','Moteur interrompu. Les résultats terminés sont conservés.');};
   own.onmessage=async({data:p})=>{if(!current()||own!==worker)return;try{
    if(p.type==='HELLO_ACK'){
     if(acknowledged||p.nonce!==nonce)return;
     if(p.protocol!==ENGINE_PROTOCOL||p.model!==model||p.revision!==revision)throw Error('Identité du moteur non confirmée.');
     if(p.serviceSuite!==SERVICE_SUITE)throw Error('Moteur métier non actualisé : rouvre la mise à jour A92.');
     acknowledged=true;clearTimer(helloTimer);phase='LOAD';notice='Lecture du modèle déjà installé. Budget total : 5 minutes, chargement compris.';view();own.postMessage({type:'LOAD',profile:'safe-64',probe:true});
    }else if(p.type==='READY'){
     if(!acknowledged||ready||phase!=='LOAD'||p.model!==model||p.revision!==revision||p.profile!=='safe-64'||!profileOK('safe-64',p.actual)||!Number.isFinite(p.loadWallMs)||p.loadWallMs<0)throw Error('Configuration du modèle non confirmée.');
     ready=true;state.current.actual=copyActual(p.actual);state.current.loadMs=p.loadWallMs;await next();
    }else if(p.type==='TECHNICAL'&&phase==='EVALUATE'&&p.event==='FIRST_TOKEN'&&firstTokenAt===null){firstTokenAt=now();
    }else if(p.type==='CONTEXT'&&phase==='EVALUATE'){context={inputTokens:p.inputTokens,budget:p.budget,droppedTurns:p.droppedTurns,droppedEvidence:p.droppedEvidence};
    }else if(p.type==='EVAL_RESULT'){
     if(phase==='SAVING')return;
     const c=state.current,test=c.inflight;
     if(!ready||phase!=='EVALUATE'||!test||p.caseId!==test.caseId||p.model!==model||p.revision!==revision||typeof p.answer!=='string'||p.answer.length>4000||!Number.isInteger(p.outputTokens)||p.outputTokens<1||p.outputTokens>64||!Number.isFinite(p.elapsedMs)||p.elapsedMs<0||firstTokenAt===null||!context||!Number.isInteger(context.inputTokens)||context.inputTokens<1||context.budget!==416||context.inputTokens>context.budget||context.droppedTurns!==0||context.droppedEvidence!==0)throw Error('Réponse ou preuve de génération non confirmée.');
     phase='SAVING';clearTimer(caseTimer);
     c.receipts.push({caseId:test.caseId,kind:'ANSWER',answer:p.answer,correct:serviceVerdict(test.caseId,p.answer,p.outputTokens),at:iso(now()),outputTokens:p.outputTokens,generationMs:p.elapsedMs,wallMs:now()-test.startedAt,firstTokenMs:firstTokenAt-test.startedAt,context});c.inflight=null;
     await persist();if(!current())return;view();await next();
    }else if(p.type==='DOWNLOAD'||p.type==='PREPARED')throw Error('Téléchargement inattendu ; banc arrêté.');
    else if(p.type==='ERROR')throw Error(p.message||'Erreur du moteur.');
   }catch(e){if(current())await end('TECHNICAL_ERROR','Arrêt : '+presentError(e)+' Aucun redémarrage automatique.');}};
   phase='HELLO';notice='Connexion au moteur installé…';view();helloTimer=setTimer(()=>end('TECHNICAL_ERROR','Le moteur ne répond pas. Mesure arrêtée.'),20000);timers.push(helloTimer);own.postMessage({type:'HELLO',nonce});return true;
  }catch(e){if(current()){if(campaignOwned)await end('TECHNICAL_ERROR','Arrêt : '+presentError(e));else{free();running=false;phase='IDLE';notice=presentError(e);view();}}return false;}
 }
 return {init,start,stop:(reason='USER')=>end(reason,reason==='HIDDEN'?'Page masquée : mesure arrêtée et résultats conservés.':'Mesure arrêtée. Aucun redémarrage automatique.'),active:()=>running,report:()=>({...clone(confirmed),summary:serviceSummary(confirmed.current),storageFailure,notice,realDeviceClaimed:false}),refresh:view};
}

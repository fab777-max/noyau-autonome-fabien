// Bounded, explicit photo adjustments. This is an editor, not a vision model.
export const PHOTO_EDIT_SCHEMA=1;
const keys=['schema','brightness','contrast','monochrome','rotation','crop'];
const normal=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’'–-]/g,' ').replace(/\s+/g,' ').trim().replace(/[.!?]+$/,'').trim();
export function photoEdit(raw){
  if(raw==null)return{schema:1,brightness:0,contrast:0,monochrome:false,rotation:0,crop:'none'};
  if(typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).some(k=>!keys.includes(k))||keys.some(k=>!Object.hasOwn(raw,k))||raw.schema!==1||!Number.isInteger(raw.brightness)||Math.abs(raw.brightness)>30||!Number.isInteger(raw.contrast)||Math.abs(raw.contrast)>30||typeof raw.monochrome!=='boolean'||![0,90,180,270].includes(raw.rotation)||!['none','square'].includes(raw.crop))throw Error('Réglages photo invalides. La copie importée est conservée.');
  return {schema:1,brightness:raw.brightness,contrast:raw.contrast,monochrome:raw.monochrome,rotation:raw.rotation,crop:raw.crop};
}
export const hasPhotoEdit=p=>{const e=photoEdit(p.edit);return !!(e.brightness||e.contrast||e.monochrome||e.rotation||e.crop!=='none');};
export function photoEditLabel(photo){
  const e=photoEdit(photo.edit),parts=[];
  if(e.brightness)parts.push(e.brightness>0?'plus claire':'plus sombre');
  if(e.contrast)parts.push(e.contrast>0?'contraste renforcé':'contraste adouci');
  if(e.monochrome)parts.push('noir et blanc');if(e.rotation)parts.push('rotation '+e.rotation+'°');if(e.crop==='square')parts.push('carré centré');
  return parts.length?parts.join(' · '):'copie importée';
}
export function photoCommand(text){
  let s=normal(text).replace(/^(?:peux tu|tu peux) (?:me )?/,'').replace(/,?\s+(?:s il te plait|stp)$/,'').trim(),index=null;
  const number=/\bphoto\s+(\d+)\b/.exec(s);if(number){index=Number(number[1])-1;s=s.replace(/\bphoto\s+\d+\b/,'photo');}
  // Never execute only the first part of a compound request.
  const patterns=[
    ['light',/^(?:eclaircis|eclaircir)(?:\s+(?:la|ma|cette))?\s+(?:photo|image)$/],
    ['dark',/^(?:assombris|assombrir)(?:\s+(?:la|ma|cette))?\s+(?:photo|image)$/],
    ['enhance',/^(?:ameliore|ameliorer)(?:\s+(?:la|ma|cette))?\s+(?:photo|image)$/],
    ['contrast',/^augmente le contraste(?: de (?:la |ma |cette )?(?:photo|image))?$/],
    ['soft',/^(?:reduis|diminue) le contraste(?: de (?:la |ma |cette )?(?:photo|image))?$/],
    ['mono',/^(?:mets|passe|mettre)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) en noir et blanc$/],
    ['color',/^(?:mets|remets|passe)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) en couleur$/],
    ['square',/^(?:recadre|recadrer)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) (?:au|en) carre$/],
    ['whole',/^(?:garde|remets|affiche)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) entiere$/],
    ['right',/^(?:tourne|tourner)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) a droite$/],
    ['left',/^(?:tourne|tourner)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) a gauche$/],
    ['reset',/^(?:retablis|remets|restaure)(?:\s+(?:la|ma|cette))?\s+(?:photo|image) d origine$/],
    ['reset',/^annule (?:la|les) retouches?(?: de (?:la |ma |cette )?(?:photo|image))?$/]
  ];
  const found=patterns.find(([,p])=>p.test(s));
  if(found)return{operation:found[0],index};
  // Catch unsupported editing requests before they can be stored as project facts.
  if(/^(?:(?:je veux|je voudrais) )?(?:retouche|retoucher|transforme|transformer|modifie|modifier|ameliore|ameliorer|eclaircis|eclaircir|assombris|recadre|recadrer|tourne|tourner|supprime|supprimer|enleve|enlever|retire|retirer|change|changer|remplace|remplacer|ajoute|ajouter|cree|creer|genere|generer|mets|mettre|passe|efface|floute|detoure)\b/.test(s)&&/\b(?:photo|image|fond|arriere plan|decor|objet|logo|dessin|visage)\b/.test(s))return{operation:'unsupported',index};
  return null;
}
export function adjustedPhoto(photo,operation){
  const p=structuredClone(photo),e=photoEdit(p.edit);
  if(operation==='reset'){delete p.edit;return p;}
  switch(operation){
    case'light':e.brightness=18;break;
    case'dark':e.brightness=-18;break;
    case'enhance':e.brightness=10;e.contrast=8;break;
    case'contrast':e.contrast=18;break;
    case'soft':e.contrast=-18;break;
    case'mono':e.monochrome=true;break;
    case'color':e.monochrome=false;break;
    case'square':e.crop='square';break;
    case'whole':e.crop='none';break;
    case'right':e.rotation=(e.rotation+90)%360;break;
    case'left':e.rotation=(e.rotation+270)%360;break;
    default:throw Error('Retouche non prise en charge.');
  }
  p.edit=photoEdit(e);if(!hasPhotoEdit(p))delete p.edit;return p;
}
export function applyPhotoCommand(raw,command,text,at=new Date().toISOString()){
  if(command.operation==='unsupported')throw Error('Je peux éclaircir, assombrir, recadrer au carré, tourner ou passer une photo en noir et blanc. Changer le décor ou supprimer un objet par IA n’est pas disponible ici.');
  const d=structuredClone(raw),index=command.index??0,p=d.photos[index];
  if(!p)throw Error(d.photos.length?'Cette photo n’existe pas. Indique son numéro affiché.':'Ajoute une photo, puis renvoie ta demande de retouche.');
  const updated=adjustedPhoto(p,command.operation);
  if(JSON.stringify(photoEdit(p.edit))===JSON.stringify(photoEdit(updated.edit)))return{dossier:d,index,changed:false};
  if(!d.studio||d.studio.messages.length>118)throw Error('Conversation pleine. Sauvegarde ce projet avant de continuer.');
  d.photos[index]=updated;d.factsConfirmed=false;d.validatedAt=null;d.updatedAt=at;d.studio.draft='';
  d.studio.messages.push({role:'user',text,at},{role:'assistant',text:'Photo '+(index+1)+' : '+photoEditLabel(updated)+'. Les réglages sont enregistrés. Vérifie le rendu ci-dessous avant de récupérer la photo. La copie importée reste conservée.',at});
  return{dossier:d,index,changed:true};
}

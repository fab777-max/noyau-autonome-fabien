/* A57: additive, bounded local memory. Never writes the canonical brain. */
(function(){
  'use strict';
  const NAME='blob-a44-device',VERSION=3,LIMITS={strategies:128,strategy_archive:128,proofs:32,run_summaries:64},MAX_BYTES=4096;
  const bounded=v=>new TextEncoder().encode(JSON.stringify(v)).length<=MAX_BYTES;
  const stamp=r=>Number(r.lastUsedAt||r.updatedAt||r.createdAt||r.observedAt)||0;
  function open(){return new Promise((resolve,reject)=>{
    if(!window.indexedDB){reject(Error('INDEXEDDB_ABSENT'));return;}
    const req=indexedDB.open(NAME,VERSION);let failed=false;
    req.onupgradeneeded=()=>{const db=req.result;for(const [name,key] of [['settings',null],['proofs','proofHash'],['strategies','key'],['strategy_archive','key'],['run_summaries','runId']])if(!db.objectStoreNames.contains(name))db.createObjectStore(name,key?{keyPath:key}:undefined);};
    req.onblocked=()=>{failed=true;reject(Error('MEMORY_OTHER_TAB_OPEN'));};req.onerror=()=>reject(req.error||Error('INDEXEDDB_FAILED'));
    req.onsuccess=()=>{if(failed){req.result.close();return;}req.result.onversionchange=()=>req.result.close();resolve(req.result);};
  });}
  function setting(db,key,value){return new Promise((resolve,reject)=>{
    const tx=db.transaction('settings',value===undefined?'readonly':'readwrite');let result;
    const req=value===undefined?tx.objectStore('settings').get(key):tx.objectStore('settings').put(value,key);
    req.onsuccess=()=>{result=req.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('MEMORY_ABORTED'));
  });}
  function all(db,names){return new Promise((resolve,reject)=>{
    const tx=db.transaction(names,'readonly'),result={};for(const name of names)tx.objectStore(name).getAll().onsuccess=e=>{result[name]=e.target.result||[];};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);
  });}
  function lookup(db,key){return new Promise((resolve,reject)=>{
    const tx=db.transaction(['strategies','strategy_archive'],'readonly');let active=null,archive=null;
    tx.objectStore('strategies').get(key).onsuccess=e=>{active=e.target.result||null;};tx.objectStore('strategy_archive').get(key).onsuccess=e=>{archive=e.target.result||null;};tx.oncomplete=()=>resolve(active||(archive?.archiveReason==="FRESH_VALIDATION_NO_ADVANTAGE"?null:archive));tx.onerror=()=>reject(tx.error);
  });}
  function maintain(db){return new Promise((resolve,reject)=>{
    const names=Object.keys(LIMITS),tx=db.transaction([...names,'settings'],'readwrite'),data={};let reads=names.length;
    const finish=()=>{
      const now=Date.now(),active=data.strategies,archive=new Map(data.strategy_archive.map(r=>[r.key,r]));
      active.sort((a,b)=>(Number(b.validationGain)||0)-(Number(a.validationGain)||0)||stamp(b)-stamp(a));let kept=0,moved=0,removed=0;
      for(const r of active){const stale=stamp(r)>0&&now-stamp(r)>30*86400000;if(kept<LIMITS.strategies&&!stale&&bounded(r)){kept++;continue;}
        const archived={...r,archivedAt:now,archiveReason:stale?'INACTIVE_30_DAYS':'ACTIVE_LIMIT'};if(bounded(archived)){archive.set(r.key,archived);moved++;}tx.objectStore('strategies').delete(r.key);}
      const sorted=[...archive.values()].sort((a,b)=>stamp(b)-stamp(a));for(let i=0;i<sorted.length;i++){const r=sorted[i];if(i<LIMITS.strategy_archive&&bounded(r))tx.objectStore('strategy_archive').put(r);else{tx.objectStore('strategy_archive').delete(r.key);removed++;}}
      for(const name of ['proofs','run_summaries']){const records=data[name].sort((a,b)=>stamp(b)-stamp(a)),key=name==='proofs'?'proofHash':'runId';for(let i=0;i<records.length;i++)if(i>=LIMITS[name]||!bounded(records[i])){tx.objectStore(name).delete(records[i][key]);removed++;}}
      tx.objectStore('settings').put({at:now,moved,removed,automatic:true},'lastMaintenance');
    };
    for(const name of names)tx.objectStore(name).getAll().onsuccess=e=>{data[name]=e.target.result||[];if(--reads===0)finish();};tx.oncomplete=()=>resolve({ok:true});tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('MEMORY_ABORTED'));
  });}
  function proof(db,record){if(!bounded(record))return Promise.reject(Error('LOCAL_PROOF_TOO_LARGE'));return new Promise((resolve,reject)=>{
    const tx=db.transaction('proofs','readwrite'),store=tx.objectStore('proofs');store.put(record);store.getAll().onsuccess=e=>{const records=(e.target.result||[]).sort((a,b)=>stamp(b)-stamp(a));for(const old of records.slice(LIMITS.proofs))store.delete(old.proofHash);};tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
  });}
  function archive(db,key,reason){return new Promise((resolve,reject)=>{
    const tx=db.transaction(['strategies','strategy_archive'],'readwrite'),store=tx.objectStore('strategies');store.get(key).onsuccess=e=>{const old=e.target.result;if(!old)return;const r={...old,archivedAt:Date.now(),archiveReason:reason};if(bounded(r))tx.objectStore('strategy_archive').put(r);store.delete(key);};tx.oncomplete=()=>maintain(db).then(resolve,reject);tx.onerror=()=>reject(tx.error);
  });}
  function strategy(db,record){if(!bounded(record))return Promise.reject(Error('LOCAL_STRATEGY_TOO_LARGE'));return new Promise((resolve,reject)=>{
    const tx=db.transaction(['strategies','strategy_archive'],'readwrite');tx.objectStore('strategies').put(record);tx.objectStore('strategy_archive').delete(record.key);tx.oncomplete=()=>maintain(db).then(resolve,reject);tx.onerror=()=>reject(tx.error);
  });}
  function summary(db,record){
    const value={...record,observedAt:Date.now(),clientDeclaredDurations:true,credits:0};
    if(!record.runId||!bounded(value))return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('run_summaries','readwrite'),store=tx.objectStore('run_summaries');store.put(value);
      store.getAll().onsuccess=e=>{const records=(e.target.result||[]).sort((a,b)=>stamp(b)-stamp(a));for(const old of records.slice(LIMITS.run_summaries))store.delete(old.runId);};
      tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
    });
  }
  async function info(db){const data=await all(db,Object.keys(LIMITS));let bytes=0;for(const rows of Object.values(data))for(const r of rows)bytes+=new TextEncoder().encode(JSON.stringify(r)).length;
    return {limits:LIMITS,strategies:data.strategies.length,archives:data.strategy_archive.length,proofs:data.proofs.length,runs:data.run_summaries.length,recordBytes:bytes,recentProofs:data.proofs.sort((a,b)=>stamp(b)-stamp(a)).slice(0,3),recentRuns:data.run_summaries.sort((a,b)=>stamp(b)-stamp(a)).slice(0,3),maintenance:await setting(db,'lastMaintenance')};
  }
  async function exportMemory(db){const records=await all(db,Object.keys(LIMITS));return {schema:'blob-local-memory-export-v1',exportedAt:new Date().toISOString(),databaseVersion:VERSION,limits:LIMITS,canonicalBrainIncluded:false,creditsSpendable:false,records};}
  async function importMemory(db,payload){
    if(!payload||payload.schema!=='blob-local-memory-export-v1'||payload.canonicalBrainIncluded!==false||payload.creditsSpendable!==false||!payload.records)throw Error('MEMORY_EXPORT_INVALID');
    if(new TextEncoder().encode(JSON.stringify(payload)).length>2097152)throw Error('MEMORY_IMPORT_TOO_LARGE');
    const candidates=[];
    for(const name of ['strategies','strategy_archive']){
      const rows=payload.records[name];if(!Array.isArray(rows)||rows.length>128)throw Error('MEMORY_IMPORT_BOUNDS');
      for(const r of rows){
        if(!r||!bounded(r)||typeof r.key!=='string'||r.key.length>240||typeof r.slug!=='string'||!/^[-a-z0-9]{1,120}$/.test(r.slug)||typeof r.source!=='string'||!(/^[a-f0-9]{64}$/i.test(r.source)||r.source==='builtin-core-v172')||r.key!==r.slug+':'+r.source||!Number.isInteger(r.mask)||r.mask<0||r.mask>31)throw Error('MEMORY_STRATEGY_INVALID');
        if(r.archiveReason==='FRESH_VALIDATION_NO_ADVANTAGE')continue;
        candidates.push({key:r.key,slug:r.slug,source:r.source,mask:r.mask,validationGain:0,createdAt:Date.now(),archivedAt:Date.now(),archiveReason:'IMPORTED_UNVERIFIED',requiresServerValidation:true});
      }
    }
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(['strategies','strategy_archive'],'readwrite');let inserted=0;const seen=new Set();
      tx.objectStore('strategy_archive').getAll().onsuccess=e=>{let available=Math.max(0,LIMITS.strategy_archive-(e.target.result||[]).length);
      for(const r of candidates){if(seen.has(r.key))continue;seen.add(r.key);let active,archive,n=2;const finish=()=>{if(--n===0&&!active&&!archive&&available>0){tx.objectStore('strategy_archive').put(r);inserted++;available--;}};
        tx.objectStore('strategies').get(r.key).onsuccess=e=>{active=e.target.result;finish()};tx.objectStore('strategy_archive').get(r.key).onsuccess=e=>{archive=e.target.result;finish()};
      }
      };
      tx.oncomplete=()=>resolve({inserted,proofsImported:0,summariesImported:0,canonicalBrainWritten:false});tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('MEMORY_ABORTED'));
    });
  }
  window.BlobLocalMemory={open,setting,maintain,lookup,proof,archive,strategy,summary,info,exportMemory,importMemory,limits:LIMITS};
})();

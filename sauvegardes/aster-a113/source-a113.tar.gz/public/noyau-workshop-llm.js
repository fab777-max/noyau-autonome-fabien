import {MODEL,MODEL_MODE,cacheReport} from '/blob-assistant-model.js?v=A93';
import {workerModelURL,workerModelOptions} from '/blob-model-choice.js?v=A100';
import {reserveEngine} from '/blob-local-pilot.js?v=A91';
import {ENGINE_PROTOCOL} from '/blob-llm-evidence.js?v=A91';
import {captionPrompt} from '/noyau-workshop-core.js?v=A105';
export async function composeLocalCaption(facts,{signal,onProgress=()=>{}}={}) {
  if (document.hidden || signal?.aborted) throw Error('Page masquée ou tâche annulée.');
  const prompt = captionPrompt(facts);
  if (!(await cacheReport()).complete) throw Error('Modèle absent ou incomplet. Installe-le depuis le Blob ; cet atelier ne télécharge aucun poids.');
  const release = await reserveEngine();
  if (!release) throw Error('Un autre onglet utilise le modèle. Mets-le en pause.');
  let worker;
  try {
    signal?.throwIfAborted();
    worker = new Worker(workerModelURL(MODEL_MODE),workerModelOptions(MODEL_MODE));
    return await new Promise((resolve,reject) => {
      let finished=false,ack=false,ready=false,timer,firstTokenMs=null;
      const start=performance.now(),nonce=crypto.randomUUID();
      const done=(error,result)=>{if(finished)return;finished=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve(result);};
      const abort=()=>done(Error('Proposition interrompue. Aucun redémarrage automatique.'));
      const deadline=(ms,label)=>{clearTimeout(timer);timer=setTimeout(()=>done(Error(label)),ms);};
      signal?.addEventListener('abort',abort,{once:true});
      worker.onerror=worker.onmessageerror=()=>done(Error('Moteur interrompu. Dossier conservé.'));
      worker.onmessage=({data:p})=>{try {
        if(finished)return;
        if(p.type==='HELLO_ACK'){
          if(ack || p.nonce!==nonce)return;
          if(p.protocol!==ENGINE_PROTOCOL || p.model!==MODEL.id || p.revision!==MODEL.revision)throw Error('Version du moteur incompatible. Rouvre le site à jour.');
          ack=true;onProgress('Chargement des poids déjà installés dans cet appareil…');deadline(480000,'Chargement trop long ; tâche arrêtée.');worker.postMessage({type:'LOAD',profile:'safe-64'});
        }else if(p.type==='READY'){
          if(!ack || ready || p.model!==MODEL.id || p.revision!==MODEL.revision)throw Error('Modèle non confirmé.');
          ready=true;onProgress('Rédaction d’une proposition locale…');deadline(90000,'Rédaction trop longue ; tâche arrêtée.');worker.postMessage({type:'COMPOSE',prompt});
        }else if(p.type==='STAGE')onProgress(String(p.label||'Calcul local').slice(0,200));
        else if(p.type==='TECHNICAL'&&p.event==='FIRST_TOKEN'&&firstTokenMs===null)firstTokenMs=performance.now()-start;
        else if(p.type==='COMPOSED'){
          if(!ready || typeof p.answer!=='string' || !p.answer.trim() || p.answer.length>1800)throw Error('Proposition vide ou invalide.');
          done(null,{text:p.answer.trim(),model:MODEL.id,revision:MODEL.revision,wallMs:Math.round(performance.now()-start),firstTokenMs,outputTokens:p.outputTokens,verifiedFacts:false});
        }else if(p.type==='ERROR')throw Error(p.message==='DIALOGUE_CONTEXT_TOO_LONG'?'Les faits complets ne tiennent pas dans le contexte du modèle. Raccourcis-les explicitement ou utilise les textes composés ; aucune information n’a été coupée.':String(p.message||'Calcul interrompu').slice(0,200));
      }catch(e){done(e);}};
      deadline(20000,'Moteur sans réponse.');worker.postMessage({type:'HELLO',nonce});
    });
  } finally { worker?.terminate(); release(); }
}

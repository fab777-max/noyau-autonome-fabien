const REVISION='A113-local-only-1',CACHE='noyau-shell-'+REVISION,ASSETS=["/comparaison.html","/aster-comparison-core.js","/aster-comparison-ui.js","/aster-work-evidence.js","/aster-work-budget.js","/aster-work-core.js","/aster-work-pipeline.js","/aster-conversation-learning.js","/aster-conversation-core.js","/aster-conversation-runner.js","/aster-conversation-ui.js","/noyau-dialogue-store.js","/aster-image-core.js","/aster-image-ui.js","/aster-training-data.js","/aster-study-cases.js","/aster-study-core.js","/aster-study-store.js","/aster-study-runner.js","/aster-study-ui.js","/aster-photo-core.js","/aster-writing-core.js","/aster-writing-runner.js","/aster-studio.js","/aster-studio-core.js","/aster-studio.css","/espace-local.html","/aster-request-core.js","/noyau-research-core.js","/noyau-research-store.js","/noyau-research-runner.js","/noyau-research-ui.js","/noyau-documents-core.js","/noyau-documents-store.js","/noyau-documents-ui.js","/aster-identity.js","/noyau-project-core.js","/noyau-project-store.js","/noyau-project-runner.js","/noyau-project-ui.js","/noyau-home.css","/atelier.html","/noyau-workshop.css","/noyau-workshop.js","/noyau-workshop-core.js","/noyau-workshop-store.js","/noyau-workshop-render.js","/noyau-workshop-llm.js","/noyau-backup.js","/noyau-backup-ui.js","/noyau-service-cases.js","/noyau-service-bench.js","/noyau-learning.js","/noyau-local-map.js","/blob-isometric.js","/vendor/starnet/map.js","/vendor/starnet/worldrenderer.js","/blob-answer-review.js", "/blob-assistant-adapter.js", "/blob-assistant-core.js", "/blob-assistant-model.js", "/blob-assistant-worker.js", "/blob-context-budget.js", "/blob-cooperative-decode.js", "/blob-dialogue-core.js", "/blob-grounding-core.js", "/blob-llm-evidence.js", "/blob-local-actions.js", "/blob-local-memory.js", "/blob-local-pilot.js", "/blob-model-choice.js", "/blob-model-compact.js", "/blob-model-manifest.js", "/blob-personal-core.js", "/blob-pilot-cycle.js", "/blob-pilot-plan.js", "/blob-reasoning-graph.js", "/blob-response-pipeline.js", "/noyau-local-offline.js", "/noyau-local.js", "/vendor/wllama/index.js", "/vendor/wllama/wllama.wasm", "/manifest.webmanifest", "/noyau-icon-180.png", "/noyau-icon-192.png", "/noyau-icon-512.png"];
self.addEventListener('install',e=>e.waitUntil(self.skipWaiting()));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
let shellPreparation=null;
// Stop stalled transfers, while allowing slow transfers that keep making progress.
async function fetchShellAsset(url,consume,onProgress=()=>{}){
 const controller=new AbortController();let timer,received=0,announced=0,lastNotice=0;
 const arm=()=>{clearTimeout(timer);timer=setTimeout(()=>controller.abort(),45000);};arm();
 try{
  const response=await fetch(url,{cache:'no-store',credentials:'same-origin',signal:controller.signal});
  if(!response.ok)throw Error('SHELL_ASSET');arm();
  if(!response.body)return await consume(response);
  const stream=response.body.pipeThrough(new TransformStream({transform(chunk,output){
   arm();received+=chunk.byteLength;
   if(received-announced>=1048576||Date.now()-lastNotice>=1000){onProgress(received);announced=received;lastNotice=Date.now();}
   output.enqueue(chunk);
  }}));
  return await consume(new Response(stream,{status:response.status,statusText:response.statusText,headers:response.headers}));
 }finally{clearTimeout(timer);controller.abort();}
}
async function prepareShell(url,progress=()=>{}){
 const cache=await caches.open(CACHE),previous=await cache.match('/');
 let html=previous?await previous.text():'';
 if(!html.includes('A113-LOCAL-ONLY')){
  html=await fetchShellAsset(url,r=>r.text());
  if(!html.includes('A113-LOCAL-ONLY'))throw Error('SHELL_NOT_APP');
 }
 let completed=0;
 for(const path of ASSETS){
  const saved=await cache.match(path);
  if(!(saved?.ok&&(!saved.headers.get('content-type')?.includes('text/html')||['/atelier.html','/espace-local.html','/comparaison.html'].includes(path)))){
   await fetchShellAsset(path,async response=>{if(response.headers.get('content-type')?.includes('text/html')&&!['/atelier.html','/espace-local.html','/comparaison.html'].includes(path))throw Error('SHELL_ASSET');if(['/atelier.html','/espace-local.html','/comparaison.html'].includes(path)&&!(await response.clone().text()).includes('A113-LOCAL-ONLY'))throw Error('SHELL_NOT_WORKSHOP');await cache.put(path,response);},receivedBytes=>progress({completed,total:ASSETS.length,receivedBytes}));
  }
  progress({completed:++completed,total:ASSETS.length});
 }
 await cache.put('/',new Response(html,{headers:{'content-type':'text/html; charset=utf-8'}}));
 // Preserve model and previous shell caches; no user data deletion.
}
self.addEventListener('message',e=>{
 if(e.data?.type!=='CACHE_SHELL')return;
 e.waitUntil((async()=>{try{
  const url=new URL(e.data.url);if(url.origin!==self.location.origin||url.pathname!=='/')return;
  if(!shellPreparation)shellPreparation=prepareShell(url,p=>{try{e.source?.postMessage({type:'SHELL_PROGRESS',revision:REVISION,...p});}catch{}}).finally(()=>{shellPreparation=null;});
  await shellPreparation;
  e.source?.postMessage({type:'SHELL_READY',revision:REVISION,ok:true});
  if(e.data.revision===REVISION){const maintenance=await cleanOldShells(e.source?.id).catch(()=>({status:'FAILED',removed:0}));e.source?.postMessage({type:'MAINTENANCE_DONE',revision:REVISION,...maintenance});}
 }catch{e.source?.postMessage({type:'SHELL_READY',revision:REVISION,ok:false});}})());
});

// Serve assets from a complete local shell; API traffic keeps its own policy.
// Fall back on transport failures and temporary hosting errors, never on an auth denial.
async function savedShellAsset(path){
 const names=[CACHE]; // Never reopen the retired server UI as a fallback.
 for(const name of names){const cache=await caches.open(name);if(!await cache.match('/'))continue;const saved=await cache.match(path);if(saved?.ok)return saved;}
 return null;
}
async function serveShell(request,path){
 const local=await savedShellAsset(path);if(local)return path==='/blob-assistant-worker.js'?new Response(local.body,{status:local.status,statusText:local.statusText,headers:local.headers}):local;
 let response;
 try{response=await fetch(request,path==='/'?{cache:'no-store'}:undefined);}
 catch(error){const saved=await savedShellAsset(path);if(saved)return saved;throw error;}
 if(response.status===429||response.status>=500){const saved=await savedShellAsset(path);if(saved)return saved;}
 return response;
}
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
 if(u.pathname!=='/'&&!ASSETS.includes(u.pathname))return;
 e.respondWith(serveShell(e.request,u.pathname));
});
// Only obsolete application shells on this origin are disposable. Never touch
// IndexedDB, model caches, resumable model chunks, other apps or future releases.
async function cleanOldShells(sourceId){
 const cache=await caches.open(CACHE),root=await cache.match('/');
 if(!root||!(await root.text()).includes('A113-LOCAL-ONLY'))return {status:'INCOMPLETE',removed:0};
 for(const path of ASSETS){const r=await cache.match(path);if(!r?.ok||(r.headers.get('content-type')?.includes('text/html')&&!['/atelier.html','/espace-local.html','/comparaison.html'].includes(path)))return {status:'INCOMPLETE',removed:0};}
 const clients=await self.clients.matchAll({type:'window',includeUncontrolled:true});
 if(!sourceId||clients.some(c=>c.id!==sourceId))return {status:'OTHER_TAB',removed:0};
 const here=/^A(\d+)-local-only-(\d+)$/.exec(REVISION);let removed=0;
 for(const name of await caches.keys()){
  const old=/^noyau-shell-A(\d+)-(?:local-only|local-focus)-(\d+)$/.exec(name);
  if(name!==CACHE&&old&&(+old[1]<+here[1]||(+old[1]===+here[1]&&+old[2]<+here[2]))){if(await caches.delete(name))removed++;}
 }
 const result={status:'DONE',removed,at:new Date().toISOString(),modelsPreserved:true,memoryPreserved:true};
 await cache.put('/_noyau-maintenance.json',new Response(JSON.stringify(result),{headers:{'content-type':'application/json'}}));
 return result;
}

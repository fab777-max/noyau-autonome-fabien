// A72.1: exercise the existing response pipeline, including durable checkpoint replay.
// The only callers are synthetic, allowlisted pilot cases. No personal data or network.
import {runAnswerPipeline} from '/blob-response-pipeline.js?v=A113';
export async function runPilotCycle({text,messages,model,generate,checkpoint},pipeline=runAnswerPipeline){
 let saved=null,calls=0;
 const data={text,kind:'CHAT',mode:'direct',context:{history:[]}};
 const io={model,generate:async(m,n,label)=>{calls++;return generate(m,Math.min(n,48),label);},save:async(value,label)=>{
  // The caller returns the value read back from durable storage, not the input object.
  saved=await checkpoint(value,label);
  if(!saved?.answer?.identity||JSON.stringify(saved)!==JSON.stringify(value))throw Error('PILOT_CHECKPOINT_READBACK');
  return true;
 }};
 const first=await pipeline(data,messages,io);
 if(saved?.answer?.final!==first.answer)throw Error('PILOT_FINAL_NOT_DURABLE');
 const replay=await pipeline({...data,checkpoint:saved},messages,{...io,generate:async()=>{throw Error('PILOT_REPLAY_GENERATED');}});
 if(replay.review?.reusedFinal!==true||replay.answer!==first.answer)throw Error('PILOT_REPLAY_MISMATCH');
 return {answer:first.answer,cycleReadback:true,reusedFinal:true,generationCalls:calls};
}
import {WORKSHOP_KEY,workshopState,putDossier} from '/noyau-workshop-core.js?v=A105';
export async function saveDossier(db,state,dossier,remove=false) {
  const operation=()=>new Promise((resolve,reject)=>{
    const tx=db.transaction('settings','readwrite');let next,error;
    const store=tx.objectStore('settings');
    store.get(WORKSHOP_KEY).onsuccess=e=>{try {
      const current=workshopState(e.target.result);
      if(current.revision!==state.revision)throw Error('Ce dossier a changé dans un autre onglet. Exporte ton brouillon, puis rouvre l’atelier pour éviter un écrasement.');
      next=remove?workshopState({...current,revision:current.revision+1,dossiers:current.dossiers.filter(d=>d.id!==dossier.id)}):putDossier(current,dossier);
      store.put(next,WORKSHOP_KEY);
    }catch(e){error=e;tx.abort();}};
    tx.oncomplete=()=>resolve(next);tx.onerror=tx.onabort=()=>reject(error||tx.error||Error('Dossier non enregistré.'));
  });
  return globalThis.navigator?.locks?.request ? navigator.locks.request('noyau-data-maintenance',{mode:'shared'},operation) : operation();
}

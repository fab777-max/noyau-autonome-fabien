import {DOCUMENTS_KEY,excerptLabel} from '/noyau-documents-core.js?v=A100';
import {RESEARCH_KEY,RESEARCH_DRAFT_KEY,researchState,researchDrafts,addResearch,researchProgress,reviewResearch,removeResearch,researchReport,researchHandoff} from '/noyau-research-core.js?v=A100';
import {commitResearch} from '/noyau-research-store.js?v=A100';
import {runResearchQueue} from '/noyau-research-runner.js?v=A100';
const $=id=>document.getElementById(id),memory=window.BlobLocalMemory;
const node=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
let db=null,state=researchState(),drafts=researchDrafts(),selected=null,busy=false,outsideBusy=false,controller=null,dirty=false;
const chosen=()=>state.dossiers.find(d=>d.id===selected),blocked=()=>busy||outsideBusy||!db;
const notice=text=>{$('researchState').textContent=text;};
function controls(){
 for(const id of ['researchTitle','researchQuestions','researchCreate','researchSelect','researchRun','researchRefresh','researchExport','researchHandoff','researchRemove'])$(id).disabled=blocked();
 for(const e of document.querySelectorAll('[data-research-control]'))e.disabled=blocked();
 $('researchPause').hidden=!controller;$('researchPause').disabled=!controller;
}
function persistDrafts(){const text=JSON.stringify(researchDrafts(drafts));localStorage.setItem(RESEARCH_DRAFT_KEY,text);if(localStorage.getItem(RESEARCH_DRAFT_KEY)!==text)throw Error('Brouillon non confirmé.');dirty=false;}
function draftChanged(){dirty=true;try{persistDrafts();}catch{notice('Brouillon non sauvegardé. Copie tes champs avant de fermer ; les résultats déjà enregistrés sont conservés.');}}
document.addEventListener('noyau-workspace-state',e=>{outsideBusy=e.detail.busy===true;controls();});
const pause=()=>controller?.abort();
window.NoyauResearchWork={active:()=>!!controller,stop:pause};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});window.addEventListener('pagehide',pause);
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
for(const id of ['researchTitle','researchQuestions'])$(id).addEventListener('input',()=>{drafts.creation={title:$('researchTitle').value,questions:$('researchQuestions').value};draftChanged();});
function control(e){e.dataset.researchControl='';return e;}
function button(text,handler){const e=control(node('button',text));e.type='button';e.className='secondary';e.onclick=handler;return e;}
function render(){
 const select=$('researchSelect');select.replaceChildren();for(const d of state.dossiers){const o=node('option',d.title);o.value=d.id;select.append(o);}if(!chosen())selected=state.dossiers.at(-1)?.id||null;select.value=selected||'';
 const d=chosen();$('researchSaved').hidden=!state.dossiers.length;$('researchWork').hidden=!d;$('researchCount').textContent=state.dossiers.length+'/6 dossiers conservés, inclus dans la sauvegarde complète.';
 const list=$('researchResults');list.replaceChildren();if(!d){controls();return;}
 const progress=researchProgress(d);$('researchHeading').textContent=d.title;
 $('researchProgress').textContent=progress.done+'/'+progress.total+' recherches préparées · '+progress.reviewed+' relues · '+progress.withoutMatches+' sans correspondance. '+d.corpus.documents.length+' document(s) figé(s) à la création.';
 $('researchRun').hidden=progress.done===progress.total;$('researchRun').textContent=progress.done?'Reprendre les questions restantes':'Lancer la recherche';
 for(const [i,q] of d.questions.entries()){
  const box=node('details');box.className='research-result';box.append(node('summary',(i+1)+'. '+q.text+' — '+(q.status==='pending'?'en attente':q.review?'avis enregistré':'à relire')));
  if(q.status==='pending'){box.append(node('p','Cette question n’a pas encore été traitée.'));list.append(box);continue;}
  box.append(node('p',q.excerpts.length?'Jusqu’à trois passages contenant tes mots. Ils peuvent être partiels ou hors sujet.':'Aucun passage trouvé avec ces mots. Cela ne prouve pas que l’information est absente.'));
  for(const ref of q.excerpts){const article=node('article');article.className='document-result';article.append(node('strong',excerptLabel(ref)),node('blockquote',ref.text),button('Joindre cet extrait au projet',async()=>{
   if(blocked())return;try{if(!window.NoyauProjectWork?.attachSource)throw Error('Les projets ne sont pas disponibles.');if(await window.NoyauProjectWork.attachSource(ref)){$('projectPanel').open=true;notice('Extrait joint. Le lancement du modèle reste manuel dans le projet.');}else notice('Extrait non joint. Consulte le message du projet.');}catch(e){notice(e.message);}
  }));box.append(article);}
  const key=d.id+':'+q.id,baseAt=q.review?.at||'',draft=drafts.reviews[key]?.baseAt===baseAt?drafts.reviews[key]:null;
  const verdict=control(node('select'));verdict.id='research-verdict-'+q.id;
  for(const [value,text] of [['','Choisir après lecture'],['useful','Ces extraits sont utiles'],['unclear','À approfondir'],['irrelevant','Ces extraits sont hors sujet']]){const option=node('option',text);option.value=value;verdict.append(option);}verdict.value=draft?.verdict??q.review?.verdict??'';
  const opinion=node('label','Ton avis sur cette question');opinion.htmlFor=verdict.id;
  const note=control(node('textarea'));note.id='research-note-'+q.id;note.rows=3;note.maxLength=600;note.value=draft?.note??q.review?.note??'';note.placeholder='Tes conclusions, réserves ou informations encore nécessaires.';
  const label=node('label','Ta note · facultative, 600 caractères');label.htmlFor=note.id;
  const saveDraft=()=>{drafts.reviews[key]={verdict:verdict.value,note:note.value,baseAt};draftChanged();};verdict.addEventListener('change',saveDraft);note.addEventListener('input',saveDraft);
  box.append(opinion,verdict,label,note,button('Enregistrer mon avis',async()=>{
   if(blocked())return;const input={verdict:verdict.value,note:note.value};
   if(await edit(raw=>reviewResearch(raw,d.id,q.id,input))){delete drafts.reviews[key];draftChanged();render();if(!dirty)notice('Avis conservé. Il sera distingué des extraits dans le compte rendu.');}
  }));list.append(box);
 }
 controls();
}
async function reload(){state=researchState(await memory.setting(db,RESEARCH_KEY));render();}
async function edit(transform){
 if(blocked())return false;busy=true;controls();
 try{await window.NoyauLocalMaintenance.run(async()=>{state=await commitResearch(db,state.revision,transform);});render();return true;}
 catch(e){notice(e.message+' Les résultats déjà confirmés et les champs saisis restent conservés.');return false;}
 finally{busy=false;controls();}
}
async function start(input=null){
 if(blocked()||document.hidden)return;
 if(!navigator.locks?.request){notice('Le verrou entre onglets est indisponible. La recherche simple reste accessible ; aucun dossier n’a été lancé.');return;}
 busy=true;controller=new AbortController();const own=controller;controls();
 let ending='Recherche mise en pause. Reprise par le bouton.';
 try{
  await window.NoyauLocalMaintenance.run(async()=>{
   if(own.signal.aborted||document.hidden)return;
   if(input){
    const corpus=await memory.setting(db,DOCUMENTS_KEY);if(own.signal.aborted||document.hidden)return;
    const id=crypto.randomUUID();state=await commitResearch(db,state.revision,raw=>addResearch(raw,input,corpus,id));selected=id;
    drafts.creation={title:'',questions:''};$('researchTitle').value='';$('researchQuestions').value='';$('researchNew').open=false;draftChanged();render();
   }else if(researchState(await memory.setting(db,RESEARCH_KEY)).revision!==state.revision)throw Error('Dossier modifié ou restauré depuis son affichage. Actualise avant de reprendre.');
   if(!chosen())throw Error('Choisis un dossier à reprendre.');
   const result=await runResearchQueue(state,selected,{signal:own.signal,visible:()=>!document.hidden,save:(revision,transform)=>commitResearch(db,revision,transform),onProgress:next=>{state=next;render();const p=researchProgress(chosen());notice(p.done+'/'+p.total+' recherches enregistrées.');}});
   state=result.state;ending=result.status==='complete'?'Dossier préparé. Relis les extraits, ajoute ton avis puis exporte le compte rendu.':result.status==='limited'?'Séance de 30 secondes terminée. Résultats confirmés conservés ; reprends les questions restantes.':'Recherche mise en pause. Les questions déjà enregistrées ne seront pas refaites.';
  });
 }catch(e){ending=e.message+' Aucun nouvel essai automatique. Actualise pour relire le dernier point confirmé.';}
 finally{controller=null;busy=false;render();notice(ending+(dirty?' Un brouillon n’a pas pu être sauvegardé ; copie les champs restants avant de fermer.':''));controls();}
}
$('researchCreate').onclick=()=>start({title:$('researchTitle').value,questions:$('researchQuestions').value});
$('researchRun').onclick=()=>start();$('researchPause').onclick=pause;
$('researchSelect').onchange=()=>{if(blocked())return;selected=$('researchSelect').value;render();};
$('researchRefresh').onclick=async()=>{if(blocked())return;try{await reload();notice('Dossiers relus. Aucun traitement lancé.');}catch(e){notice(e.message);}};
$('researchExport').onclick=()=>{
 if(blocked()||!chosen())return;
 try{const text=researchReport(chosen()),url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'})),a=node('a');a.href=url;a.download='Aster-recherche-'+chosen().id.replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,80)+'.txt';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);notice('Compte rendu préparé. Enregistre-le dans Fichiers. Il contient les extraits et avis enregistrés. Les avis encore en brouillon ne figurent pas dans ce compte rendu.');}catch(e){notice(e.message);}
};
$('researchHandoff').onclick=()=>{
 if(blocked()||!chosen())return;
 try{const text=researchHandoff(chosen()),key='noyau-request-draft-v1',previous=localStorage.getItem(key);if(previous&&previous!==text&&!confirm('Remplacer le brouillon non envoyé dans Avec l’agent ?'))return;localStorage.setItem(key,text);if(localStorage.getItem(key)!==text)throw Error('Résumé non confirmé.');location.assign('/demandes.html');}catch(e){notice(e.message);}
};
$('researchRemove').onclick=async()=>{
 if(blocked()||!chosen())return;const id=selected;if(!confirm('Retirer ce dossier et sa copie de recherche ? Exporte-le ou garde une sauvegarde complète avant. Les documents importés d’origine sont conservés.'))return;
 if(await edit(raw=>removeResearch(raw,id))){for(const key of Object.keys(drafts.reviews))if(key.startsWith(id+':'))delete drafts.reviews[key];draftChanged();if(!dirty)notice('Dossier retiré. Documents d’origine conservés.');}
};
(async()=>{try{db=await memory.open();drafts=researchDrafts(JSON.parse(localStorage.getItem(RESEARCH_DRAFT_KEY)||'null'));await reload();$('researchTitle').value=drafts.creation.title;$('researchQuestions').value=drafts.creation.questions;$('researchNew').open=!!drafts.creation.title||!state.dossiers.length;notice('Prépare plusieurs recherches dans tes documents. La réouverture ne lance aucun travail.');}catch(e){db=null;notice(e.message);}controls();})();

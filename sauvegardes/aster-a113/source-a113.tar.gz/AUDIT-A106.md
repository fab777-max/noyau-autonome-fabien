# A106 — Mode étudiant borné et mémoire vérifiable

17 octobre 2026. Base examinée : A105, source `9c2deee42d3066786318b7970b8efcbb0fb24df1`, version native 20. Même site privé, même origine et même modèle installé. La preuve de publication est le résultat natif Sites associé au commit qui contient cet audit.

## Résultat livré

La conversation comprend « Étudie 5 minutes sur les demandes client », jusqu’à 30 minutes, « Reprends l’étude » et « Termine l’étude ». Elle ouvre une séance locale, conserve les essais et leurs corrections, présente un bilan téléchargeable et permet à Fabien de noter le travail de 1 à 5. Il n’y a ni nouvel onglet ni bouton de campagne technique sur l’accueil.

Le programme initial contient 60 cas fictifs écrits pour l’application : 36 exercices et 24 cas distincts de comparaison. Six familles : faits, incertitude, nombres, sources, ordre des étapes et choix d’un outil réellement disponible. La demande sur les images donne la priorité au choix d’outil ; elle n’entraîne pas un moteur d’image. Le thème libre n’est pas un moteur de recherche : les exercices proviennent de ce programme fini.

Un premier essai ne reçoit pas le corrigé. Une erreur peut donner lieu à un second essai explicitement guidé. Les scores restent séparés. Après deux échecs sur un exercice, la séance peut demander de continuer les autres exercices ou de terminer ; au plus deux questions sont posées. Ce sont des questions prévues par le programme, pas une conversation pédagogique illimitée.

Les méthodes proposées viennent des règles des corrigés. Aucune sortie du modèle n’est automatiquement apprise. Après une note et une relecture, Fabien peut modifier puis accepter une méthode. Une séance ultérieure utilise des cas non encore traités, sans puis avec les méthodes rappelées. Le bilan conserve dénominateurs, régressions, identifiants des méthodes, modèle et révision. Quelques cas ne prouvent pas une amélioration générale ; une réponse guidée ne prouve pas un apprentissage.

## Sécurité d’exécution et continuité

- Chaque séance est limitée à 12 étapes, 24 appels au modèle, six démarrages, 1 à 30 minutes actives au total et deux essais par exercice d’étude. Une comparaison n’a qu’un essai par condition. Le temps de chargement consomme le budget. La séance finit plus tôt si le travail disponible est terminé : pas de calcul pour remplir la durée.
- Un Worker charge une fois le modèle déjà en cache, dans la même réservation de moteur que les autres travaux. Aucun téléchargement ni appel payant. Le protocole, le modèle, sa révision et les paramètres réellement chargés sont vérifiés. Contexte 1 024, batch 64, un thread, 64 jetons de sortie maximum, température zéro, cache de conversation désactivé pour isoler les essais. Les pauses coopératives visent 25 ms de calcul / 50 ms de pause ; un appel natif déjà lancé n’est pas préemptible.
- Début et résultat de chaque étape sont enregistrés puis relus avant la suivante. Révisions monotones et verrou de maintenance protègent contre les autres onglets et les restaurations. Une sauvegarde qui échoue empêche le calcul suivant. Au retour après un arrêt brutal, le budget réservé est compté prudemment et l’essai reste marqué interrompu.
- Page masquée, sortie de page, pause, délai dépassé ou erreur : arrêt du Worker et reprise manuelle. Aucun redémarrage à l’ouverture. Les étapes terminées ne sont pas rejouées. Il ne s’agit pas d’un service iOS en arrière-plan.
- Note, commentaire et modifications des méthodes sont sauvegardés comme brouillons. Une écriture non confirmée bloque la suite et garde l’avertissement. L’acceptation d’une méthode et sa provenance sont atomiques ; une règle différente sur une même question normalisée n’écrase pas silencieusement la précédente.
- La sauvegarde complète et la copie de retour incluent les séances. Même une ancienne sauvegarde sans étude invalide les révisions de l’interface ouverte. Une mémoire d’étude incompatible n’empêche pas d’ouvrir les projets existants.

## Mémoire et usage dans un projet réel

La nouvelle mémoire d’étude est bornée à 20 séances, 128 Kio par séance et 2 Mio au total. Les méthodes conservent la limite existante de 64 ; six familles au maximum peuvent être retenues depuis une séance. Les instantanés sont figés, pas synchronisés rétroactivement. Aucun ancien historique n’est supprimé automatiquement. Les preuves JSON servent à l’inspection ; seule la sauvegarde complète constitue le chemin de restauration de l’étude.

Le rédacteur du studio rappelle désormais au plus deux méthodes validées pour un nouveau travail. Les faits restent obligatoires. Une méthode qui ferait dépasser le budget de caractères est omise entièrement et signalée ; aucune coupe silencieuse. Le contrôle réel en jetons peut encore refuser un contexte trop long. Un travail déjà terminé garde son contexte et est réutilisé sans nouveau calcul. Les propositions ne remplacent les textes qu’après adoption par Fabien et nouvelle validation de la livraison.

Limites non résolues : croissance de l’ancien dialogue, sauvegarde globale limitée à 40 Mio, import privé de dossier limité à 8 Mio, absence de retrait explicite des séances dans cette première interface. Lorsque les cas nouveaux ou une limite sont épuisés, le lancement s’arrête avec une explication. Ne pas promettre un entraînement permanent ou un nettoyage de toute la mémoire.

## Preuves de contrôle

| Suite | Résultat | Périmètre |
|---|---:|---|
| `qa/a106-study.json` | 26 / 26 | Cas, scores, reprises, limites, transactions, mémoire, sauvegardes, runner et protocole Worker |
| `qa/a106-studio.json` | 56 / 56 | Commandes, notes, brouillons, méthodes, conservation des projets, rédaction, retouches et exports |
| `qa/a106-writing.json` | 25 / 25 | Rédaction bornée, contexte, interruptions, mémoire facultative, sauvegardes |
| `qa/a106-shell.json` | 4 / 4 | Actifs hors ligne, installation interrompue et conservation du cache modèle |

Total : 111 contrôles logiciels, aucun échec. Modules et gestionnaires réels ; DOM, IndexedDB, visibilité et inférence simulés. Les PNG utilisent le canvas natif Node. Pas de validation Safari, d’iPhone physique, de qualité du modèle installé, de température, de batterie ni de fonctionnement réel pendant 30 minutes. Le build du paquet est effectué par le workflow Sites ; une publication réussie ne remplace pas ces mesures.

## Ce que cette version ne prouve pas

La mémoire de règles peut aider certaines tâches, mais les poids du modèle ne sont pas entraînés. Plus de temps n’ajoute pas automatiquement les capacités d’un grand modèle. Les retouches A105 restent des transformations déterministes de pixels ; aucune génération d’image, vidéo, exécution distribuée ou contribution de puissance des visiteurs n’est connectée. Aucun abonnement commercial, revenu, client ou gain de qualité n’est établi par cette livraison.

Recherche primaire consultée le 17 octobre 2026 : [Reflexion](https://arxiv.org/abs/2303.11366) décrit une approche avec retour d’expérience et mémoire sans mise à jour des poids ; [Scaling LLM Test-Time Compute](https://arxiv.org/abs/2408.03314) montre des gains dépendant de la tâche et du budget, sans équivalence universelle à un grand modèle ; [Qwen-Image-Edit-2511](https://huggingface.co/Qwen/Qwen-Image-Edit-2511) est un moteur d’image distinct, non connecté au site. Ces publications justifient de mesurer une boucle de correction ; elles ne démontrent pas les performances d’Aster.

## Prochaine mesure utile

Sur l’iPhone 17 Pro Max, commencer par une séance de cinq minutes, lire les réponses et noter le bilan. Accepter seulement une règle utile, puis comparer un cas nouveau. Vérifier une pause/reprise et une sauvegarde complète. Passer ensuite à 15 puis 30 minutes si le comportement est stable. Pour l’offre client : produire un pack avec une vraie photo autorisée, mesurer la qualité finale et le temps de correction humain. Une amélioration démontrée sur ce travail compte davantage que le nombre de séances.

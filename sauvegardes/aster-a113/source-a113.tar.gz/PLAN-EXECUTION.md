> A106 — 17 octobre 2026 : premier mode étudiant livré dans la conversation, avec budget de 1 à 30 minutes, exercices fictifs bornés, corrections, bilan à noter et méthodes retenues uniquement après relecture. Comparaisons sur cas nouveaux, mémoire d’étude bornée et sauvegardée, méthodes facultatives désormais rappelées par les nouveaux travaux du rédacteur. 111 contrôles logiciels passent. Cette livraison partielle de P4 n’entraîne aucun poids et ne démontre pas encore un gain de qualité sur iPhone. Voir `AUDIT-A106.md` et `CONTINUITY.md`. Les 80 actions du plan d’étude restent une feuille de route, pas 80 fonctions terminées. P1, les longues sessions réelles et la validation d’une offre client restent ouverts.

> A105 — 17 octobre 2026 : retouches photo simples par message et PNG de la photo seule ajoutés. 49 scénarios de studio et 4 contrôles hors ligne passent. Audit détaillé dans `AUDIT-A105.md` : aucune vision générative ni mise à jour des poids ; la mémoire de méthodes n’est pas injectée par le rédacteur du studio. Prochain résultat : valider un vrai pack sur iPhone et mesurer les corrections. Un moteur d’image réellement accessible reste nécessaire pour changer un décor. P1 et les limites d’archivage restent ouverts.

> A104 — 17 octobre 2026 : le modèle local installé peut désormais rédiger trois propositions dans la conversation principale, une étape après l’autre avec points enregistrés, reprise manuelle et réutilisation des résultats terminés. Les projets restent bornés ; les méthodes identiques ne remplissent plus deux places de contexte. 61 contrôles logiciels passent, sans mesure du modèle réel ni essai iPhone. Cette livraison partielle de P4/P5-A ne remplace ni P1 (sauvegarde >40 Mio), ni la recette sur appareil, ni P5-B (agent hébergé). Prochain résultat utile : un pack réel relu et récupéré sur iPhone, puis mesure du temps de correction. Détails et limites dans l’entrée A104 de `CONTINUITY.md`.

> Mise à jour du 17 octobre 2026 — décision de Fabien : remplacer les trois onglets et les longs formulaires par une conversation, puis finaliser une première prestation montrable. A103 livre le parcours borné photos → présentation dans le même écran, avec sauvegarde de projet. Il ne livre pas le moteur général P5B ni une boutique publique. Les recommandations historiques de trois onglets ci-dessous sont remplacées par cette décision. Voir `CONTINUITY.md` pour les preuves et limites.

# Aster — plan de réalisation de la V1

Décision de travail : 15 octobre 2026. Cible : iPhone 17 Pro Max. Ce plan reprend l’audit A100 et la demande de Fabien de prendre les décisions techniques utiles sans le solliciter à chaque étape.

## Résultat à livrer

Un atelier privé utilisable de bout en bout : ouvrir un dossier, fournir un brief et des photos autorisées, retrouver ses sources, préparer trois textes et deux visuels, relire, récupérer un ZIP et une fiche imprimable, puis reprendre le dossier après interruption. La carte et les trois entrées Discuter / Créer / Avec l’agent restent en place.

L’offre initiale envisagée est un pack de présentation d’une réalisation pour artisan ou petite entreprise. C’est une hypothèse à tester avec des utilisateurs, pas une preuve de demande ni une promesse de revenu. Les premiers clients peuvent recevoir les fichiers produits après relecture ; un portail public, un abonnement et une facturation automatisée ne sont pas nécessaires à ce pilote.

Une V1 est terminée lorsque les critères ci-dessous sont satisfaits. L’apprentissage général autonome, l’entraînement des poids, la vidéo générative et l’exécution illimitée sur un iPhone verrouillé ne constituent pas des critères de cette V1.

## État vérifié et premier lot

Base réconciliée : source A100 `edb50a0a6e38fed9aff5734fe68a883b24630584`, version native Sites 15, même origine privée. Les anciens comptes rendus A92/A93 ne décrivent plus tout le produit actuel.

A101 corrige :
- F1 : l’entrée de l’atelier garde tous les champs, y compris les réserves après le caractère 420. Une entrée trop longue est refusée explicitement ; aucune coupe silencieuse. Validation de taille avant création du Worker ; refus du budget en jetons expliqué, sans relance.
- F4 : les exports complets et la copie de retour utilisent une sérialisation compacte validée avant création du Blob. Le fichier près de 40 Mio passe le même validateur que la restauration. Taille réelle visible à la préparation.
- La qualification ciblée est dans `qa/a101-reliability.json` (12) et `qa/a101-recovery-regressions.json` (10). DOM, Worker et IndexedDB sont simulés ; aucun modèle réel ou iPhone testé. Les 58 dépendances hors ligne sont présentes.

La limite globale de 40 Mio (F3), la vérification du sens des faits (F2) et l’unification des dossiers restent ouvertes. Ne pas les annoncer résolues par A101. Les tests A100 restent une preuve historique séparée.

## Ordre d’exécution et critères de sortie

### P1 — Continuité et archivage, prochain chantier

Dépendance : A101. Conserver schémas, clés et caches existants.

Travail :
1. Ajouter un manifest de sauvegarde fractionnée : identifiant, version, liste des parties, taille UTF-8 et empreinte SHA-256. Conserver l’import de sauvegardes A92/A93.
2. Traiter par lots bornés les gros historiques, sans doubler plusieurs fois leur taille en mémoire ; aucune suppression implicite. Importer toutes les parties dans une zone temporaire avant remplacement transactionnel et copie de retour.
3. Afficher dans les réglages stockage estimé, protection persistante obtenue ou non, et distinction entre données locales, copie proposée et copie relue. Une demande `persist()` ne garantit pas la survie du stockage.
4. Ajouter un résumé de reprise issu des états réels : dossier actif, dernier point confirmé, résultat disponible, prochaine action, problème éventuel. Aucun LLM pour inventer ce résumé.

Sortie : sauvegarde synthétique supérieure à 40 Mio exportée et restaurée ; parties manquantes, doublonnées, modifiées ou de deux archives différentes refusées avant écriture ; interruption et quota ne remplacent rien partiellement ; ancien onglet ne peut écraser les données restaurées. Réouverture ne relance ni modèle ni téléchargement. Validation physique d’un petit export/import sur iPhone avant qualification générale.

Preuves : jeux synthétiques versionnés, empreintes avant/après, journal de restauration, test de retour arrière. Ne pas utiliser de mémoire privée du téléphone sans export volontaire.

### P2 — Un dossier de travail commun

Dépendance : contrat d’archivage défini en P1.

Travail : créer un identifiant de travail qui référence les dossiers atelier, documents, recherches, projets et demandes existants, avec migration additive réversible. Aucune duplication automatique des photos/corpus. Un résumé et une action principale conduisent de « brief à compléter » à « sources », « brouillon », « à relire », « fichiers prêts ». Un état en échec affiche une reprise utile.

Sortie : même dossier retrouvé après fermeture ; liens orphelins détectés et récupérables ; import d’anciens dossiers ; changements d’onglet sans ressaisie ; carte branchée sur les événements réels, sans faux calcul ni boutons de test supplémentaires.

### P3 — Livrable client complet et faits traçables

Dépendance : P2.

Travail : associer prix, quantité, unité, date, statut, réserve et source à des champs explicites ; afficher les données manquantes et contradictions. Garder le brief d’origine et les corrections. Comparer proposition et faits en vis-à-vis. Choisir la photo de couverture, permettre le recadrage et contrôler les textes longs dans les deux visuels. Ajouter une liste des fichiers et des faits approuvés au pack.

Sortie : cinq dossiers synthétiques produisent un ZIP dont chaque entrée est ouverte ; PNG de dimensions attendues ; fiche imprimable sans coupure critique ; textes éditables ; faits importants identiques au brief validé. Les cas « 120 euros devenu 120 ans », délai non confirmé, acompte absent, nom et lieu inventés sont refusés ou clairement soumis à correction. Un filtre de nombres seul n’est jamais qualifié de vérification factuelle. Toute modification de faits ou texte annule l’approbation correspondante.

### P4 — Qualité du modèle et mémoire utile

Dépendance : parcours P3 stable. Le modèle local demeure facultatif.

Travail : réutiliser les 12 cas existants ; établir 30 briefs avec références, dont 10 réservés hors réglage des prompts. Comparer gabarits, modèle sans méthode mémorisée et modèle avec méthode validée. Inclure fautes, négations, champs absents, montants proches, dates ambiguës, sources contradictoires et texte contenant de fausses consignes. Mesurer résultat final, corrections, durée humaine et ressources ; ne pas compter les jetons comme un progrès.

Objectifs à mesurer, pas résultats acquis : zéro invention critique dans les 10 cas réservés ; au moins 90 % des champs correctement extraits ou signalés inconnus/contradictoires ; quatre packs sur cinq livrables après relecture ; réduction médiane du temps humain de 30 % sur les mêmes tâches comparées. Ce petit échantillon ne garantit pas l’absence d’erreurs futures.

Une méthode mémorisée contient situation, action, provenance, exemple réussi et contre-exemple. Ne la retenir que si elle aide sur des cas nouveaux sans régression critique. Conserver refus et erreurs. Cela réutilise de l’expérience ; cela n’entraîne pas les poids de Qwen. Si le LLM fait perdre du temps, garder les gabarits pour cette tâche.

### P5 — Relais agent et travail long

Volet A, réalisable avec le registre actuel : contexte sélectionné, aperçu avant partage, références et périmètre des pièces, journal d’étapes, résultat partiel durable, idempotence et réservation prolongeable de façon bornée. À chaque reprise, relire l’état réel et le commit, puis continuer la première tâche non validée. Deux agents ne doivent pas appliquer le même travail.

Volet B, conditionnel : pilotage direct depuis le site. Identifier un hôte d’exécution disponible ; vérifier l’éligibilité et l’authentification avant toute inférence. Isoler la copie de code ; limiter droits, durée et dépenses ; conserver thread, commits, preuves et possibilité de retour. L’hôte exécute, le téléphone commande et affiche. Ne pas lancer de serveur payant ou exposer une clé au navigateur.

Sortie : une mission réelle dépassant 30 minutes avec interruption contrôlée et reprise, sans double effet ; jeton expiré ou ancien agent refusé ; résultat partiel consultable ; publication identifiée séparément de la génération. L’annulation du registre n’est pas un arrêt distant tant qu’un canal de contrôle effectif n’existe pas.

Sans hôte qualifié, garder le passage explicite par ChatGPT. Le formulaire seul ne lance pas Codex. L’usage du forfait dans une application distante/commerciale nécessite de vérifier la voie autorisée ; la documentation actuelle pour applications open source/locales ne vaut pas autorisation de revente.

### P6 — Qualification sur appareil et pilote utile

Dépendance : P1–P4. P5-B n’est pas requis pour un pack produit et relu manuellement.

Préparer une seule fiche de recette, sans campagne de tests envahissante sur l’accueil : même point d’entrée Safari ou icône ; dossier réel ; fermeture/reprise ; un essai hors ligne après installation complète ; sauvegarde dans Fichiers et relecture ; export ZIP/images/fiche ; signalement d’un échec. Puis session visible d’au plus une heure, interrompable, uniquement avec une file de tâches utiles. Vérifier absence de calcul lorsque la file est vide.

Sortie technique : les fichiers s’ouvrent sur l’iPhone 17 Pro Max, aucun échec critique de récupération, pas de nouveau transfert des poids quand le cache complet est conservé, résultat repris sans double génération. Mesurer durée et batterie, recueillir l’observation de chauffe ; ne pas inventer une télémétrie indisponible.

Sortie pilote : trois prestations candidates préparées, puis cinq dossiers consentis évalués ; mesurer temps, retouches et satisfaction. Fixer une offre et un tarif seulement après mesure. Aucun client contacté ni publication publique dans ce chantier sans demande explicite.

## Définition commune de « terminé »

Pour chaque lot : source identifiée → reproduction du problème → correction ciblée → essais adaptés → résultat inspectable → version privée publiée lorsque pertinente → compte rendu et prochaine étape enregistrés. Ne pas transformer une compilation ou une suite simulée en preuve de qualité sur iPhone. Ne pas recommencer tout l’audit à chaque reprise.

La V1 est prête au pilote quand P1–P4 et la recette appareil de P6 passent. Le mode agent directement sur le site est prêt uniquement après P5-B. La commercialisation est une décision supplémentaire fondée sur les retours pilotes.

## Décisions à prendre sans multiplier les questions

Choix par défaut : même site privé, Aster, trois entrées et carte ; même modèle installé ; bibliothèque déjà présente avant nouvelle dépendance ; gabarits avant génération payante ; aucune suppression de données pour résoudre un quota ; travaux découpés avec preuve à chaque étape. Continuer les corrections réversibles autorisées. Réserver l’intervention de Fabien aux comptes qu’il doit authentifier, à un engagement payant ou public, et aux validations réellement impossibles à faire hors de son téléphone.

Ne pas ajouter maintenant : nouveau nom de domaine, nouvelle plateforme, énorme corpus, second LLM, moteur vidéo, réseau d’agents public ou apprentissage automatique des réponses non relues. Réexaminer une option seulement si elle résout un blocage mesuré d’un lot.

## Reprise pour le prochain agent

Lire `AGENTS.md`, ce fichier et `CONTINUITY.md`. Réconcilier version native et HEAD. Consulter les derniers rapports A101. Commencer P1 par le contrat de sauvegarde fractionnée et un test export/import >40 Mio ; préserver les formats précédents. Ne jamais annoncer que le téléphone ou sa mémoire ont été inspectés à distance.

## Références consultées le 15 octobre 2026

- WebKit, politique de stockage (10 août 2023) : https://webkit.org/blog/14403/updates-to-storage-policy/ — quotas, éviction, stockage persistant demandé mais non garanti.
- OpenAI, usage du forfait : https://developers.openai.com/siwc/token-sharing-open-source — voie documentée pour applications open source et locales ; formulaire d’intérêt pour une application payante/distante.
- OpenAI, app-server : https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server — authentification, exécution, état de fin et reprise de thread.
- OpenAI, limites de la préversion : https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations — contexte côté application, outils/modalités limités ; génération d’images non couverte par cette voie.

Les deux derniers points cadrent une intégration future ; aucun hôte ni forfait n’a été activé ou testé par A101.
